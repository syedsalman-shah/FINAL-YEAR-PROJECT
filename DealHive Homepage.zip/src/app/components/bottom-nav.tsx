import { Home, Search, Calendar, Bookmark, User } from "lucide-react";
import { useNavigate, useLocation } from "react-router";

type NavItem = "home" | "search" | "plan" | "saved" | "profile";

export function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  const getActiveItem = (): NavItem => {
    const path = location.pathname;
    if (path === "/" || path === "/home") return "home";
    if (path.startsWith("/search")) return "search";
    if (path.startsWith("/plan")) return "plan";
    if (path.startsWith("/saved")) return "saved";
    if (path.startsWith("/profile")) return "profile";
    return "home";
  };

  const currentActive = getActiveItem();

  const navItems = [
    { id: "home" as NavItem, icon: Home, label: "Home", path: "/" },
    { id: "search" as NavItem, icon: Search, label: "Search", path: "/search" },
    { id: "plan" as NavItem, icon: Calendar, label: "Planner", path: "/plan" },
    { id: "saved" as NavItem, icon: Bookmark, label: "Saved", path: "/saved" },
    { id: "profile" as NavItem, icon: User, label: "Profile", path: "/profile" },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-lg safe-area-padding-bottom">
      <div className="grid grid-cols-5 h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentActive === item.id;

          return (
            <button
              key={item.id}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center justify-center gap-1 transition-all active:bg-gray-50 ${
                isActive ? "text-primary" : "text-gray-400"
              }`}
            >
              <div className="relative">
                <Icon className={`w-6 h-6 ${isActive ? "scale-110" : ""} transition-transform`} />
                {isActive && (
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-primary rounded-full" />
                )}
              </div>
              <span className={`text-[10px] font-medium ${isActive ? "font-semibold" : ""}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
