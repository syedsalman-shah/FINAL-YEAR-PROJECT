import { createBrowserRouter } from "react-router";
import { HomePage } from "./pages/HomePage";
import { SearchPage } from "./pages/SearchPage";
import { PlannerPage } from "./pages/PlannerPage";
import { SavedPage } from "./pages/SavedPage";
import { ProfilePage } from "./pages/ProfilePage";
import { BusinessProfilePage } from "./pages/BusinessProfilePage";
import { UploadDealPage } from "./pages/UploadDealPage";
import { VerifyBusinessPage } from "./pages/VerifyBusinessPage";
import { DealDetailPage } from "./pages/DealDetailPage";
import { EditProfilePage } from "./pages/EditProfilePage";
import { PreferencesPage } from "./pages/PreferencesPage";
import { NotificationsPage } from "./pages/NotificationsPage";
import { PrivacySettingsPage } from "./pages/PrivacySettingsPage";
import { SavedLocationsPage } from "./pages/SavedLocationsPage";
import { AchievementsPage } from "./pages/AchievementsPage";
import { WebsiteSettingsPage } from "./pages/WebsiteSettingsPage";
import { HelpSupportPage } from "./pages/HelpSupportPage";
import { MapViewPage } from "./pages/MapViewPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: HomePage,
  },
  {
    path: "/search",
    Component: SearchPage,
  },
  {
    path: "/plan",
    Component: PlannerPage,
  },
  {
    path: "/saved",
    Component: SavedPage,
  },
  {
    path: "/profile",
    Component: ProfilePage,
  },
  {
    path: "/map",
    Component: MapViewPage,
  },
  {
    path: "/profile/edit",
    Component: EditProfilePage,
  },
  {
    path: "/profile/preferences",
    Component: PreferencesPage,
  },
  {
    path: "/profile/notifications",
    Component: NotificationsPage,
  },
  {
    path: "/profile/privacy",
    Component: PrivacySettingsPage,
  },
  {
    path: "/profile/achievements",
    Component: AchievementsPage,
  },
  {
    path: "/profile/website-settings",
    Component: WebsiteSettingsPage,
  },
  {
    path: "/profile/help-support",
    Component: HelpSupportPage,
  },
  {
    path: "/business/:id",
    Component: BusinessProfilePage,
  },
  {
    path: "/upload-deal",
    Component: UploadDealPage,
  },
  {
    path: "/verify-business",
    Component: VerifyBusinessPage,
  },
  {
    path: "/deal/:id",
    Component: DealDetailPage,
  },
  {
    path: "/saved-locations",
    Component: SavedLocationsPage,
  },
  {
    path: "*",
    Component: HomePage, // Fallback to home for 404s
  },
]);
