import { useState } from "react";
import { DesktopHeader } from "../components/desktop-header";
import { Button } from "../components/ui/button";
import { Label } from "../components/ui/label";
import { Switch } from "../components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Checkbox } from "../components/ui/checkbox";
import { ArrowLeft, MapPin, Filter, Bell } from "lucide-react";
import { useNavigate } from "react-router";

export function PreferencesPage() {
  const navigate = useNavigate();
  const [defaultLocation, setDefaultLocation] = useState("islamabad");
  const [searchRadius, setSearchRadius] = useState("5");
  const [dealAlerts, setDealAlerts] = useState(true);
  const [priceAlerts, setPriceAlerts] = useState(true);
  const [autoSave, setAutoSave] = useState(false);

  const [selectedCategories, setSelectedCategories] = useState([
    "fast-food",
    "pizza",
  ]);

  const categories = [
    { id: "fast-food", label: "Fast Food", icon: "🍔" },
    { id: "pizza", label: "Pizza & Italian", icon: "🍕" },
    { id: "coffee", label: "Coffee & Cafe", icon: "☕" },
    { id: "asian", label: "Asian Cuisine", icon: "🍜" },
    { id: "desi", label: "Desi Food", icon: "🥘" },
    { id: "healthy", label: "Healthy & Salads", icon: "🥗" },
    { id: "desserts", label: "Desserts & Sweets", icon: "🍰" },
    { id: "sushi", label: "Sushi & Japanese", icon: "🍣" },
  ];

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId)
        ? prev.filter((id) => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <DesktopHeader />

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate("/profile")}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl mb-1">Preferences</h1>
            <p className="text-muted-foreground">
              Customize your deal discovery experience
            </p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Location Preferences */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="w-5 h-5 text-primary" />
              <h2 className="text-xl">Location Preferences</h2>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="location">Default Location</Label>
                <Select value={defaultLocation} onValueChange={setDefaultLocation}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="islamabad">Islamabad</SelectItem>
                    <SelectItem value="f6">F-6 Sector, Islamabad</SelectItem>
                    <SelectItem value="f7">F-7 Sector, Islamabad</SelectItem>
                    <SelectItem value="f8">F-8 Sector, Islamabad</SelectItem>
                    <SelectItem value="g9">G-9 Sector, Islamabad</SelectItem>
                    <SelectItem value="bluarea">Blue Area, Islamabad</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="radius">Search Radius</Label>
                <Select value={searchRadius} onValueChange={setSearchRadius}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select radius" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 km</SelectItem>
                    <SelectItem value="3">3 km</SelectItem>
                    <SelectItem value="5">5 km</SelectItem>
                    <SelectItem value="10">10 km</SelectItem>
                    <SelectItem value="20">20 km</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div>
                  <p className="font-medium">Use Current Location</p>
                  <p className="text-sm text-muted-foreground">
                    Automatically detect my location
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
            </div>
          </div>

          {/* Category Preferences */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <Filter className="w-5 h-5 text-primary" />
              <h2 className="text-xl">Favorite Categories</h2>
            </div>

            <p className="text-sm text-muted-foreground mb-4">
              Select categories you're interested in to get personalized deal
              recommendations
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {categories.map((category) => (
                <div
                  key={category.id}
                  className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <Checkbox
                    id={category.id}
                    checked={selectedCategories.includes(category.id)}
                    onCheckedChange={() => toggleCategory(category.id)}
                  />
                  <Label
                    htmlFor={category.id}
                    className="flex items-center gap-2 cursor-pointer flex-1"
                  >
                    <span className="text-xl">{category.icon}</span>
                    <span>{category.label}</span>
                  </Label>
                </div>
              ))}
            </div>
          </div>

          {/* Deal Alerts */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <Bell className="w-5 h-5 text-primary" />
              <h2 className="text-xl">Deal Alerts</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">New Deals in Favorite Categories</p>
                  <p className="text-sm text-muted-foreground">
                    Get notified when new deals match your interests
                  </p>
                </div>
                <Switch checked={dealAlerts} onCheckedChange={setDealAlerts} />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Price Drop Alerts</p>
                  <p className="text-sm text-muted-foreground">
                    Notify me when saved deals get better discounts
                  </p>
                </div>
                <Switch checked={priceAlerts} onCheckedChange={setPriceAlerts} />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Auto-Save Deals</p>
                  <p className="text-sm text-muted-foreground">
                    Automatically save deals from favorite categories
                  </p>
                </div>
                <Switch checked={autoSave} onCheckedChange={setAutoSave} />
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => navigate("/profile")}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={() => navigate("/profile")}
              className="flex-1 bg-primary hover:bg-primary/90"
            >
              Save Preferences
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
