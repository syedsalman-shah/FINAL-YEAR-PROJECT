export interface Deal {
  id: string;
  businessName: string;
  dealTitle: string;
  description: string;
  dealImage: string;
  images?: string[];
  category?: string;
  originalPrice?: number;
  dealPrice?: number;
  discount?: number;
  distance?: string;
  location?: string;
  verified?: boolean;
  rating?: number;
  reviews?: number;
  validUntil?: string;
  terms?: string;
  phone?: string;
  instagram?: string;
  website?: string;
  hours?: string;
  // Geographic coordinates for map pins
  coordinates?: {
    lat: number;
    lng: number;
  };
}
