import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { getAllDeals, Deal } from "../data/mockDeals";

interface SavedDeal extends Deal {
  savedAt: Date;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: "deal" | "price_drop" | "expiring" | "achievement" | "system";
  read: boolean;
  timestamp: Date;
  dealId?: string;
}

interface UserProfile {
  name: string;
  email: string;
  phone: string;
  avatar: string;
  bio: string;
  location: string;
}

type UserRole = "user" | "business" | null;

interface AppState {
  // User
  userProfile: UserProfile;
  updateUserProfile: (profile: Partial<UserProfile>) => void;

  // User Role
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  hasCompletedOnboarding: boolean;
  completeOnboarding: () => void;

  // Location
  selectedLocation: string;
  setSelectedLocation: (location: string) => void;

  // Saved Deals
  savedDeals: SavedDeal[];
  toggleSaveDeal: (deal: Deal) => void;
  isSaved: (dealId: string) => boolean;

  // Planner
  plannerDeals: Deal[];
  addToPlan: (deal: Deal) => void;
  removeFromPlan: (dealId: string) => void;
  isInPlan: (dealId: string) => boolean;
  clearPlan: () => void;

  // Notifications
  notifications: Notification[];
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
  unreadCount: number;

  // Search
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  searchHistory: string[];
  addToSearchHistory: (query: string) => void;
  clearSearchHistory: () => void;

  // Settings
  preferences: {
    emailNotifications: boolean;
    pushNotifications: boolean;
    dealAlerts: boolean;
    priceDrops: boolean;
    savedDeals: boolean;
    nearbyDeals: boolean;
    weeklyDigest: boolean;
  };
  updatePreferences: (prefs: Partial<AppState["preferences"]>) => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

const STORAGE_KEYS = {
  SAVED_DEALS: "dealhive_saved_deals",
  PLANNER_DEALS: "dealhive_planner_deals",
  NOTIFICATIONS: "dealhive_notifications",
  USER_PROFILE: "dealhive_user_profile",
  SEARCH_HISTORY: "dealhive_search_history",
  PREFERENCES: "dealhive_preferences",
  LOCATION: "dealhive_location",
  USER_ROLE: "dealhive_user_role",
  ONBOARDING_COMPLETED: "dealhive_onboarding_completed",
};

const defaultUserProfile: UserProfile = {
  name: "Ahmed Khan",
  email: "ahmed.khan@example.com",
  phone: "+92 300 1234567",
  avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop",
  bio: "Food lover and deal hunter in Islamabad",
  location: "F-7, Islamabad",
};

const defaultPreferences = {
  emailNotifications: true,
  pushNotifications: true,
  dealAlerts: true,
  priceDrops: true,
  savedDeals: true,
  nearbyDeals: false,
  weeklyDigest: true,
};

export function AppProvider({ children }: { children: ReactNode }) {
  // Initialize state from localStorage
  const [savedDeals, setSavedDeals] = useState<SavedDeal[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.SAVED_DEALS);
    return stored ? JSON.parse(stored, (key, value) => {
      if (key === 'savedAt') return new Date(value);
      return value;
    }) : [];
  });

  const [plannerDeals, setPlannerDeals] = useState<Deal[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.PLANNER_DEALS);
    return stored ? JSON.parse(stored) : [];
  });

  const [notifications, setNotifications] = useState<Notification[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (stored) {
      return JSON.parse(stored, (key, value) => {
        if (key === 'timestamp') return new Date(value);
        return value;
      });
    }
    // Default notifications
    return [
      {
        id: "1",
        title: "Welcome to Deal Hive!",
        message: "Start exploring amazing deals near you",
        type: "system",
        read: false,
        timestamp: new Date(),
      },
      {
        id: "2",
        title: "🔥 Hot Deal Alert",
        message: "Burger Lab: Buy 1 Get 1 Free - Ends Tonight!",
        type: "deal",
        read: false,
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
        dealId: "1",
      },
    ];
  });

  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    return stored ? JSON.parse(stored) : defaultUserProfile;
  });

  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.SEARCH_HISTORY);
    return stored ? JSON.parse(stored) : [];
  });

  const [preferences, setPreferences] = useState(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.PREFERENCES);
    return stored ? JSON.parse(stored) : defaultPreferences;
  });

  const [selectedLocation, setSelectedLocationState] = useState<string>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.LOCATION);
    return stored || "Islamabad";
  });

  const [searchQuery, setSearchQuery] = useState("");

  // User Role
  const [userRole, setUserRole] = useState<UserRole>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.USER_ROLE);
    return stored ? (stored as UserRole) : null;
  });
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.ONBOARDING_COMPLETED);
    return stored ? stored === "true" : false;
  });

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SAVED_DEALS, JSON.stringify(savedDeals));
  }, [savedDeals]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PLANNER_DEALS, JSON.stringify(plannerDeals));
  }, [plannerDeals]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(userProfile));
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SEARCH_HISTORY, JSON.stringify(searchHistory));
  }, [searchHistory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PREFERENCES, JSON.stringify(preferences));
  }, [preferences]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOCATION, selectedLocation);
  }, [selectedLocation]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER_ROLE, userRole || "");
  }, [userRole]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ONBOARDING_COMPLETED, hasCompletedOnboarding.toString());
  }, [hasCompletedOnboarding]);

  // User Profile
  const updateUserProfile = (profile: Partial<UserProfile>) => {
    setUserProfile((prev) => ({ ...prev, ...profile }));
  };

  // Location
  const setSelectedLocation = (location: string) => {
    setSelectedLocationState(location);
  };

  // Saved Deals
  const toggleSaveDeal = (deal: Deal) => {
    setSavedDeals((prev) => {
      const existing = prev.find((d) => d.id === deal.id);
      if (existing) {
        // Remove from saved
        return prev.filter((d) => d.id !== deal.id);
      } else {
        // Add to saved
        const savedDeal: SavedDeal = { ...deal, savedAt: new Date() };
        
        // Add notification
        if (preferences.savedDeals) {
          const newNotification: Notification = {
            id: Date.now().toString(),
            title: "Deal Saved",
            message: `${deal.businessName}: ${deal.dealTitle}`,
            type: "deal",
            read: false,
            timestamp: new Date(),
            dealId: deal.id,
          };
          setNotifications((prev) => [newNotification, ...prev]);
        }
        
        return [savedDeal, ...prev];
      }
    });
  };

  const isSaved = (dealId: string) => {
    return savedDeals.some((d) => d.id === dealId);
  };

  // Planner
  const addToPlan = (deal: Deal) => {
    setPlannerDeals((prev) => {
      if (prev.some((d) => d.id === deal.id)) return prev;
      
      // Add notification
      const newNotification: Notification = {
        id: Date.now().toString(),
        title: "Added to Shopping Plan",
        message: `${deal.businessName} added to your route`,
        type: "system",
        read: false,
        timestamp: new Date(),
        dealId: deal.id,
      };
      setNotifications((notifs) => [newNotification, ...notifs]);
      
      return [...prev, deal];
    });
  };

  const removeFromPlan = (dealId: string) => {
    setPlannerDeals((prev) => prev.filter((d) => d.id !== dealId));
  };

  const isInPlan = (dealId: string) => {
    return plannerDeals.some((d) => d.id === dealId);
  };

  const clearPlan = () => {
    setPlannerDeals([]);
  };

  // Notifications
  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  // Search
  const addToSearchHistory = (query: string) => {
    if (!query.trim()) return;
    setSearchHistory((prev) => {
      const filtered = prev.filter((q) => q !== query);
      return [query, ...filtered].slice(0, 10); // Keep last 10
    });
  };

  const clearSearchHistory = () => {
    setSearchHistory([]);
  };

  // Preferences
  const updatePreferences = (prefs: Partial<AppState["preferences"]>) => {
    setPreferences((prev) => ({ ...prev, ...prefs }));
  };

  // User Role
  const completeOnboarding = () => {
    setHasCompletedOnboarding(true);
  };

  const value: AppState = {
    userProfile,
    updateUserProfile,
    userRole,
    setUserRole,
    hasCompletedOnboarding,
    completeOnboarding,
    selectedLocation,
    setSelectedLocation,
    savedDeals,
    toggleSaveDeal,
    isSaved,
    plannerDeals,
    addToPlan,
    removeFromPlan,
    isInPlan,
    clearPlan,
    notifications,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    unreadCount,
    searchQuery,
    setSearchQuery,
    searchHistory,
    addToSearchHistory,
    clearSearchHistory,
    preferences,
    updatePreferences,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}