import { ArrowLeft, Search, Bell, Menu, X } from "lucide-react";
import { useNavigate, useLocation } from "react-router";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "./ui/sheet";
import { LocationSelector } from "./location-selector";
import { useApp } from "../context/AppContext";

interface MobileHeaderProps {
  title?: string;
  showBack?: boolean;
  showSearch?: boolean;
  showNotifications?: boolean;
  showMenu?: boolean;
  onSearchClick?: () => void;
}

export function MobileHeader({
  title,
  showBack = false,
  showSearch = false,
  showNotifications = false,
  showMenu = false,
  onSearchClick,
}: MobileHeaderProps) {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user } = useApp();

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Left Side */}
          <div className="flex items-center gap-3 flex-1">
            {showBack ? (
              <button
                onClick={() => navigate(-1)}
                className="p-2 -ml-2 active:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-6 h-6 text-foreground" />
              </button>
            ) : showMenu ? (
              <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
                <SheetTrigger asChild>
                  <button className="p-2 -ml-2 active:bg-gray-100 rounded-full transition-colors">
                    <Menu className="w-6 h-6 text-foreground" />
                  </button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[280px] p-0">
                  <div className="flex flex-col h-full">
                    {/* Menu Header */}
                    <div className="p-6 border-b border-gray-200">
                      <h2 className="text-2xl font-bold text-primary">Deal Hive</h2>
                      <p className="text-xs text-muted-foreground mt-1">
                        Smart Savings, Trusted Deals
                      </p>
                    </div>

                    {/* Menu Items */}
                    <div className="flex-1 overflow-y-auto py-4">
                      <nav className="space-y-1 px-3">
                        <button
                          onClick={() => {
                            navigate("/");
                            setIsMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-50 active:bg-gray-100 transition-colors"
                        >
                          <span className="text-base font-medium">Home</span>
                        </button>
                        <button
                          onClick={() => {
                            navigate("/search");
                            setIsMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-50 active:bg-gray-100 transition-colors"
                        >
                          <span className="text-base font-medium">Search Deals</span>
                        </button>
                        <button
                          onClick={() => {
                            navigate("/plan");
                            setIsMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-50 active:bg-gray-100 transition-colors"
                        >
                          <span className="text-base font-medium">AI Planner</span>
                        </button>
                        <button
                          onClick={() => {
                            navigate("/saved");
                            setIsMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-50 active:bg-gray-100 transition-colors"
                        >
                          <span className="text-base font-medium">Saved Deals</span>
                        </button>
                        <button
                          onClick={() => {
                            navigate("/profile");
                            setIsMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-50 active:bg-gray-100 transition-colors"
                        >
                          <span className="text-base font-medium">Profile</span>
                        </button>
                      </nav>

                      <div className="h-px bg-gray-200 my-4 mx-3" />

                      <nav className="space-y-1 px-3">
                        <button
                          onClick={() => {
                            navigate("/upload-deal");
                            setIsMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-50 active:bg-gray-100 transition-colors"
                        >
                          <span className="text-base font-medium">Upload Deal</span>
                        </button>
                        <button
                          onClick={() => {
                            navigate("/verify-business");
                            setIsMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-50 active:bg-gray-100 transition-colors"
                        >
                          <span className="text-base font-medium">Verify Business</span>
                        </button>
                      </nav>
                    </div>

                    {/* Location Selector */}
                    <div className="p-4 border-t border-gray-200">
                      <LocationSelector />
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            ) : null}

            {/* Title or Logo */}
            {title ? (
              <h1 className="text-lg font-semibold text-foreground truncate">
                {title}
              </h1>
            ) : (
              <button onClick={() => navigate("/")} className="flex flex-col">
                <h1 className="text-xl font-bold text-primary">Deal Hive</h1>
                <p className="text-[10px] text-muted-foreground leading-none">
                  Smart Savings
                </p>
              </button>
            )}
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center gap-2">
            {showSearch && (
              <button
                onClick={onSearchClick || (() => navigate("/search"))}
                className="p-2 active:bg-gray-100 rounded-full transition-colors"
              >
                <Search className="w-5 h-5 text-foreground" />
              </button>
            )}
            {showNotifications && (
              <button
                onClick={() => navigate("/profile/notifications")}
                className="p-2 active:bg-gray-100 rounded-full transition-colors relative"
              >
                <Bell className="w-5 h-5 text-foreground" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-accent rounded-full" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}