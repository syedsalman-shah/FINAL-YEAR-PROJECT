import { useState } from "react";
import { Map, List, Filter, SlidersHorizontal, X } from "lucide-react";
import { ResponsiveHeader } from "../components/responsive-header";
import { BottomNav } from "../components/bottom-nav";
import { DealMap } from "../components/deal-map";
import { DealListItem } from "../components/deal-list-item";
import { LocationSelector } from "../components/location-selector";
import { getAllDeals } from "../data/mockDeals";
import { useApp } from "../context/AppContext";

type ViewMode = "map" | "list" | "split";
type CategoryFilter = "all" | "fast-food" | "pizza" | "coffee" | "sushi" | "healthy" | "desserts" | "asian" | "desi";

export function MapViewPage() {
  const { selectedLocation, setSelectedLocation } = useApp();
  const [viewMode, setViewMode] = useState<ViewMode>("map");
  const [selectedDealId, setSelectedDealId] = useState<string | undefined>();
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>("all");
  const [showVerifiedOnly, setShowVerifiedOnly] = useState(false);
  const [minDiscount, setMinDiscount] = useState(0);

  const allDeals = getAllDeals();

  // Apply filters
  const filteredDeals = allDeals.filter((deal) => {
    // Category filter
    if (categoryFilter !== "all") {
      const categoryMap: Record<CategoryFilter, string> = {
        "all": "",
        "fast-food": "Fast Food",
        "pizza": "Pizza",
        "coffee": "Coffee",
        "sushi": "Sushi",
        "healthy": "Healthy",
        "desserts": "Desserts",
        "asian": "Asian",
        "desi": "Desi Food",
      };
      if (deal.category !== categoryMap[categoryFilter]) return false;
    }

    // Verified filter
    if (showVerifiedOnly && !deal.verified) return false;

    // Minimum discount filter
    if (minDiscount > 0 && deal.discount) {
      if (deal.discount < minDiscount) return false;
    }

    return true;
  });

  const activeFilterCount = [
    categoryFilter !== "all",
    showVerifiedOnly,
    minDiscount > 0,
  ].filter(Boolean).length;

  const resetFilters = () => {
    setCategoryFilter("all");
    setShowVerifiedOnly(false);
    setMinDiscount(0);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      <ResponsiveHeader title="Map View" showBack showSearch />

      <div className="max-w-7xl mx-auto">
        {/* View Mode Toggle & Filters */}
        <div className="sticky top-0 lg:top-[73px] z-40 bg-white border-b border-gray-200 px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between gap-3">
            {/* View Mode Buttons */}
            <div className="flex items-center gap-2 bg-gray-100 rounded-xl p-1">
              <button
                onClick={() => setViewMode("map")}
                className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  viewMode === "map"
                    ? "bg-white text-primary shadow-sm"
                    : "text-gray-600 hover:text-foreground"
                }`}
              >
                <Map className="w-4 h-4 sm:mr-2 sm:inline hidden" />
                <span>Map</span>
              </button>
              <button
                onClick={() => setViewMode("split")}
                className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  viewMode === "split"
                    ? "bg-white text-primary shadow-sm"
                    : "text-gray-600 hover:text-foreground"
                }`}
              >
                <span>Split</span>
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  viewMode === "list"
                    ? "bg-white text-primary shadow-sm"
                    : "text-gray-600 hover:text-foreground"
                }`}
              >
                <List className="w-4 h-4 sm:mr-2 sm:inline hidden" />
                <span>List</span>
              </button>
            </div>

            {/* Filter Button */}
            <button
              onClick={() => setIsFilterOpen(!isFilterOpen)}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors relative"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span className="text-sm font-medium hidden sm:inline">Filter</span>
              {activeFilterCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-accent text-white text-xs rounded-full flex items-center justify-center font-semibold">
                  {activeFilterCount}
                </span>
              )}
            </button>
          </div>

          {/* Filter Panel */}
          {isFilterOpen && (
            <div className="mt-4 p-4 bg-gray-50 rounded-xl animate-in fade-in slide-in-from-top-2 duration-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-foreground">Filters</h3>
                <button
                  onClick={() => setIsFilterOpen(false)}
                  className="p-1 hover:bg-gray-200 rounded-full transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Category */}
                <div>
                  <label className="block text-xs font-medium text-foreground mb-2">
                    Category
                  </label>
                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value as CategoryFilter)}
                    className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    <option value="all">All Categories</option>
                    <option value="fast-food">🍔 Fast Food</option>
                    <option value="pizza">🍕 Pizza</option>
                    <option value="coffee">☕ Coffee</option>
                    <option value="sushi">🍣 Sushi</option>
                    <option value="healthy">🥗 Healthy</option>
                    <option value="desserts">🍰 Desserts</option>
                    <option value="asian">🍜 Asian</option>
                    <option value="desi">🥘 Desi Food</option>
                  </select>
                </div>

                {/* Min Discount */}
                <div>
                  <label className="block text-xs font-medium text-foreground mb-2">
                    Minimum Discount
                  </label>
                  <select
                    value={minDiscount}
                    onChange={(e) => setMinDiscount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    <option value={0}>Any Discount</option>
                    <option value={10}>10% or more</option>
                    <option value={20}>20% or more</option>
                    <option value={30}>30% or more</option>
                    <option value={50}>50% or more</option>
                  </select>
                </div>

                {/* Location */}
                <div>
                  <label className="block text-xs font-medium text-foreground mb-2">
                    Location
                  </label>
                  <LocationSelector value={selectedLocation} onChange={setSelectedLocation} />
                </div>
              </div>

              {/* Verified Only */}
              <div className="mt-4 pt-4 border-t border-gray-200">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showVerifiedOnly}
                    onChange={(e) => setShowVerifiedOnly(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                  />
                  <span className="text-sm font-medium text-foreground">Verified Businesses Only</span>
                </label>
              </div>

              {/* Reset */}
              {activeFilterCount > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <button
                    onClick={resetFilters}
                    className="w-full sm:w-auto px-4 py-2 text-sm font-medium text-primary hover:bg-primary/10 rounded-lg transition-colors"
                  >
                    Reset All Filters ({activeFilterCount})
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Results Count */}
          <div className="mt-4">
            <p className="text-sm text-muted-foreground">
              Showing {filteredDeals.length} {filteredDeals.length === 1 ? "deal" : "deals"} in {selectedLocation}
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6">
          {viewMode === "map" && (
            <DealMap
              deals={filteredDeals}
              selectedDealId={selectedDealId}
              onDealSelect={setSelectedDealId}
              height="calc(100vh - 280px)"
            />
          )}

          {viewMode === "list" && (
            <div className="space-y-3 sm:space-y-4">
              {filteredDeals.map((deal) => (
                <DealListItem key={deal.id} {...deal} />
              ))}
            </div>
          )}

          {viewMode === "split" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Map Side */}
              <div className="lg:sticky lg:top-[200px] h-fit">
                <DealMap
                  deals={filteredDeals}
                  selectedDealId={selectedDealId}
                  onDealSelect={setSelectedDealId}
                  height="500px"
                />
              </div>

              {/* List Side */}
              <div className="space-y-3 sm:space-y-4">
                {filteredDeals.map((deal) => (
                  <div
                    key={deal.id}
                    onClick={() => setSelectedDealId(deal.id)}
                    className={`transition-all ${
                      selectedDealId === deal.id ? "ring-2 ring-primary rounded-2xl" : ""
                    }`}
                  >
                    <DealListItem {...deal} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Empty State */}
          {filteredDeals.length === 0 && (
            <div className="text-center py-12">
              <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                <Map className="w-10 h-10 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">No Deals Found</h3>
              <p className="text-sm text-muted-foreground mb-6">
                Try adjusting your filters or search in a different area
              </p>
              <button
                onClick={resetFilters}
                className="px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 transition-colors"
              >
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
