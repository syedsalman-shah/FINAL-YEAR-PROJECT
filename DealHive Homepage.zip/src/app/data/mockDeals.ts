// Re-export everything from dealsData for backwards compatibility
export { type Deal } from "./dealTypes";
export { getAllDeals, getDealById, getDealsByCategory, searchDeals, DEALS_DATA as MOCK_DEALS } from "./dealsData";
