import { Bookmark, Filter, Grid3x3, List, X, SlidersHorizontal } from "lucide-react";
import { useState } from "react";
import { DealCard } from "../components/deal-card";
import { DealListItem } from "../components/deal-list-item";
import { ResponsiveHeader } from "../components/responsive-header";
import { BottomNav } from "../components/bottom-nav";
import { LocationSelector } from "../components/location-selector";
import { useNavigate } from "react-router";
import { useApp } from "../context/AppContext";

type ViewMode = "grid" | "list";
type SortOption = "recent" | "discount" | "price" | "distance";
type CategoryFilter = "all" | "fast-food" | "pizza" | "coffee" | "sushi" | "healthy" | "desserts" | "asian" | "desi";
type PriceFilter = "all" | "0-500" | "500-1000" | "1000-2000" | "2000+";

export function SavedPage() {
  const navigate = useNavigate();
  const { savedDeals, selectedLocation, setSelectedLocation } = useApp();
  const [viewMode, setViewMode] = useState<ViewMode>("list");
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // Filter states
  const [sortBy, setSortBy] = useState<SortOption>("recent");
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>("all");
  const [priceFilter, setPriceFilter] = useState<PriceFilter>("all");
  const [showVerifiedOnly, setShowVerifiedOnly] = useState(false);

  // Apply filters
  const filteredDeals = savedDeals
    .filter((deal) => {
      // Category filter
      if (categoryFilter !== "all") {
        const categoryMap: Record<CategoryFilter, string> = {
          "all": "",
          "fast-food": "Fast Food",
          "pizza": "Pizza",
          "coffee": "Coffee",
          "sushi": "Sushi",
          "healthy": "Healthy",
          "desserts": "Desserts",
          "asian": "Asian",
          "desi": "Desi Food",
        };
        if (deal.category !== categoryMap[categoryFilter]) return false;
      }

      // Price filter
      if (priceFilter !== "all") {
        const price = deal.dealPrice || 0;
        if (priceFilter === "0-500" && (price < 0 || price > 500)) return false;
        if (priceFilter === "500-1000" && (price < 500 || price > 1000)) return false;
        if (priceFilter === "1000-2000" && (price < 1000 || price > 2000)) return false;
        if (priceFilter === "2000+" && price < 2000) return false;
      }

      // Verified filter
      if (showVerifiedOnly && !deal.verified) return false;

      return true;
    })
    .sort((a, b) => {
      // Sorting logic
      if (sortBy === "discount") {
        const discountA = a.originalPrice && a.dealPrice ? 
          ((a.originalPrice - a.dealPrice) / a.originalPrice) * 100 : 0;
        const discountB = b.originalPrice && b.dealPrice ? 
          ((b.originalPrice - b.dealPrice) / b.originalPrice) * 100 : 0;
        return discountB - discountA;
      }
      if (sortBy === "price") {
        return (a.dealPrice || 0) - (b.dealPrice || 0);
      }
      if (sortBy === "distance") {
        const distA = parseFloat(a.distance?.replace(" km", "") || "999");
        const distB = parseFloat(b.distance?.replace(" km", "") || "999");
        return distA - distB;
      }
      return 0; // "recent" is default order
    });

  const activeFilterCount = [
    categoryFilter !== "all",
    priceFilter !== "all",
    showVerifiedOnly,
    selectedLocation !== "Islamabad",
  ].filter(Boolean).length;

  const resetFilters = () => {
    setCategoryFilter("all");
    setPriceFilter("all");
    setSortBy("recent");
    setShowVerifiedOnly(false);
    setSelectedLocation("Islamabad");
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      <ResponsiveHeader title="Saved Deals" showBack showSearch />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
              Saved Deals
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground">
              {filteredDeals.length} {filteredDeals.length === 1 ? "deal" : "deals"} saved for later
            </p>
          </div>

          {/* Desktop Controls */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              onClick={() => setIsFilterOpen(!isFilterOpen)}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors relative"
            >
              <Filter className="w-4 h-4" />
              <span className="text-sm font-medium">Filter</span>
              {activeFilterCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-accent text-white text-xs rounded-full flex items-center justify-center font-semibold">
                  {activeFilterCount}
                </span>
              )}
            </button>
            <div className="flex items-center gap-1 bg-white border border-gray-200 rounded-xl p-1">
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === "list" ? "bg-primary text-white" : "text-muted-foreground hover:bg-gray-100"
                }`}
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === "grid" ? "bg-primary text-white" : "text-muted-foreground hover:bg-gray-100"
                }`}
              >
                <Grid3x3 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Filter Toggle */}
        <div className="sm:hidden flex items-center gap-3 mb-4">
          <button
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white border border-gray-200 rounded-xl active:bg-gray-50 transition-colors relative"
          >
            <SlidersHorizontal className="w-5 h-5" />
            <span className="text-sm font-medium">Filters & Sort</span>
            {activeFilterCount > 0 && (
              <span className="absolute -top-1 -right-1 w-6 h-6 bg-accent text-white text-xs rounded-full flex items-center justify-center font-semibold">
                {activeFilterCount}
              </span>
            )}
          </button>
          <div className="flex items-center gap-1 bg-white border border-gray-200 rounded-xl p-1">
            <button
              onClick={() => setViewMode("list")}
              className={`p-2.5 rounded-lg transition-colors ${
                viewMode === "list" ? "bg-primary text-white" : "text-muted-foreground active:bg-gray-100"
              }`}
            >
              <List className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode("grid")}
              className={`p-2.5 rounded-lg transition-colors ${
                viewMode === "grid" ? "bg-primary text-white" : "text-muted-foreground active:bg-gray-100"
              }`}
            >
              <Grid3x3 className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Panel */}
        {isFilterOpen && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4 sm:p-6 mb-6 animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-foreground">Filters & Sorting</h3>
              <button
                onClick={() => setIsFilterOpen(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors lg:hidden"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Location Filter */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  Location
                </label>
                <LocationSelector value={selectedLocation} onChange={setSelectedLocation} />
              </div>

              {/* Sort By */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  Sort By
                </label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortOption)}
                  className="w-full px-4 py-2.5 bg-secondary border border-gray-200 rounded-xl text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                >
                  <option value="recent">Recently Saved</option>
                  <option value="discount">Highest Discount</option>
                  <option value="price">Lowest Price</option>
                  <option value="distance">Nearest First</option>
                </select>
              </div>

              {/* Category Filter */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  Category
                </label>
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value as CategoryFilter)}
                  className="w-full px-4 py-2.5 bg-secondary border border-gray-200 rounded-xl text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                >
                  <option value="all">All Categories</option>
                  <option value="fast-food">🍔 Fast Food</option>
                  <option value="pizza">🍕 Pizza</option>
                  <option value="coffee">☕ Coffee</option>
                  <option value="sushi">🍣 Sushi</option>
                  <option value="healthy">🥗 Healthy</option>
                  <option value="desserts">🍰 Desserts</option>
                  <option value="asian">🍜 Asian</option>
                  <option value="desi">🥘 Desi Food</option>
                </select>
              </div>

              {/* Price Range */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  Price Range
                </label>
                <select
                  value={priceFilter}
                  onChange={(e) => setPriceFilter(e.target.value as PriceFilter)}
                  className="w-full px-4 py-2.5 bg-secondary border border-gray-200 rounded-xl text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                >
                  <option value="all">All Prices</option>
                  <option value="0-500">₨0 - ₨500</option>
                  <option value="500-1000">₨500 - ₨1,000</option>
                  <option value="1000-2000">₨1,000 - ₨2,000</option>
                  <option value="2000+">₨2,000+</option>
                </select>
              </div>
            </div>

            {/* Verified Only Toggle */}
            <div className="mt-6 pt-6 border-t border-gray-200">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showVerifiedOnly}
                  onChange={(e) => setShowVerifiedOnly(e.target.checked)}
                  className="w-5 h-5 rounded border-gray-300 text-primary focus:ring-primary"
                />
                <div>
                  <span className="text-sm font-medium text-foreground">Verified Businesses Only</span>
                  <p className="text-xs text-muted-foreground">Show only deals from verified sellers</p>
                </div>
              </label>
            </div>

            {/* Reset Button */}
            {activeFilterCount > 0 && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <button
                  onClick={resetFilters}
                  className="w-full sm:w-auto px-6 py-2.5 text-sm font-medium text-primary hover:bg-primary/10 rounded-xl transition-colors"
                >
                  Reset All Filters ({activeFilterCount})
                </button>
              </div>
            )}
          </div>
        )}

        {/* Active Filters Display */}
        {activeFilterCount > 0 && !isFilterOpen && (
          <div className="flex flex-wrap items-center gap-2 mb-6">
            <span className="text-xs sm:text-sm text-muted-foreground">Active filters:</span>
            {selectedLocation !== "Islamabad" && (
              <button
                onClick={() => setSelectedLocation("Islamabad")}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 text-primary rounded-lg text-xs sm:text-sm font-medium hover:bg-primary/20 transition-colors"
              >
                {selectedLocation}
                <X className="w-3 h-3" />
              </button>
            )}
            {categoryFilter !== "all" && (
              <button
                onClick={() => setCategoryFilter("all")}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 text-primary rounded-lg text-xs sm:text-sm font-medium hover:bg-primary/20 transition-colors"
              >
                {categoryFilter.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ")}
                <X className="w-3 h-3" />
              </button>
            )}
            {priceFilter !== "all" && (
              <button
                onClick={() => setPriceFilter("all")}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 text-primary rounded-lg text-xs sm:text-sm font-medium hover:bg-primary/20 transition-colors"
              >
                ₨{priceFilter}
                <X className="w-3 h-3" />
              </button>
            )}
            {showVerifiedOnly && (
              <button
                onClick={() => setShowVerifiedOnly(false)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 text-primary rounded-lg text-xs sm:text-sm font-medium hover:bg-primary/20 transition-colors"
              >
                Verified Only
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        )}

        {/* Deals Grid/List */}
        {filteredDeals.length > 0 ? (
          <div className={
            viewMode === "grid"
              ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4"
              : "space-y-3 sm:space-y-4"
          }>
            {filteredDeals.map((deal, index) =>
              viewMode === "grid" ? (
                <DealCard key={deal.id || index} {...deal} />
              ) : (
                <DealListItem key={deal.id || index} {...deal} />
              )
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 sm:py-24">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gray-200 rounded-full flex items-center justify-center mb-6">
              <Bookmark className="w-10 h-10 sm:w-12 sm:h-12 text-gray-400" />
            </div>
            <h2 className="text-xl sm:text-2xl font-semibold text-foreground mb-3">
              {savedDeals.length === 0 ? "No Saved Deals Yet" : "No Deals Match Your Filters"}
            </h2>
            <p className="text-sm sm:text-base text-muted-foreground text-center max-w-md mb-8 px-4">
              {savedDeals.length === 0
                ? "Start saving your favorite deals to access them quickly later. Click the bookmark icon on any deal to save it."
                : "Try adjusting your filters to see more deals."}
            </p>
            {savedDeals.length === 0 ? (
              <button
                onClick={() => navigate("/")}
                className="px-6 sm:px-8 py-3 bg-accent text-white rounded-xl hover:bg-accent/90 active:bg-accent/80 transition-colors font-semibold"
              >
                Explore Deals
              </button>
            ) : (
              <button
                onClick={resetFilters}
                className="px-6 sm:px-8 py-3 bg-primary text-white rounded-xl hover:bg-primary/90 active:bg-primary/80 transition-colors font-semibold"
              >
                Clear All Filters
              </button>
            )}
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}