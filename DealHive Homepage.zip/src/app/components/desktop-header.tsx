import { Home, Search, Calendar, Bookmark, User } from "lucide-react";
import { useNavigate, useLocation } from "react-router";
import { LocationSelector } from "./location-selector";

type NavItem = "home" | "search" | "plan" | "saved" | "profile";

export function DesktopHeader() {
  const navigate = useNavigate();
  const location = useLocation();

  const getActiveItem = (): NavItem => {
    const path = location.pathname;
    if (path === "/" || path === "/home") return "home";
    if (path === "/search") return "search";
    if (path === "/plan") return "plan";
    if (path === "/saved") return "saved";
    if (path === "/profile") return "profile";
    return "home";
  };

  const currentActive = getActiveItem();

  const navItems = [
    { id: "home" as NavItem, icon: Home, label: "Home", path: "/" },
    { id: "search" as NavItem, icon: Search, label: "Search Deals", path: "/search" },
    { id: "plan" as NavItem, icon: Calendar, label: "AI Shopping Planner", path: "/plan" },
    { id: "saved" as NavItem, icon: Bookmark, label: "Saved Deals", path: "/saved" },
  ];

  const handleNavClick = (path: string) => {
    navigate(path);
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-8">
            <button onClick={() => navigate("/")} className="flex flex-col">
              <h1 className="text-2xl font-bold text-primary">Deal Hive</h1>
              <p className="text-xs text-muted-foreground">Smart Savings, Trusted Deals</p>
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex items-center gap-1 flex-1 justify-center">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentActive === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.path)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    isActive
                      ? "bg-secondary text-primary font-semibold"
                      : "text-muted-foreground hover:bg-gray-50"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-sm">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Side Actions */}
          <div className="flex items-center gap-4">
            {/* Location Selector */}
            <LocationSelector />

            {/* Profile Button */}
            <button
              onClick={() => navigate("/profile")}
              className={`p-2 rounded-lg transition-colors ${
                currentActive === "profile"
                  ? "bg-primary text-white"
                  : "bg-gray-100 text-foreground hover:bg-gray-200"
              }`}
            >
              <User className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}