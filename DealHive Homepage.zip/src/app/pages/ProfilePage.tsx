import { ChevronRight, User, Settings, Bell, HelpCircle, LogOut, MapPin, Heart, Calendar, Shield, Award, Store, Plus } from "lucide-react";
import { useNavigate } from "react-router";
import { ResponsiveHeader } from "../components/responsive-header";
import { BottomNav } from "../components/bottom-nav";

export function ProfilePage() {
  const navigate = useNavigate();

  const menuSections = [
    {
      title: "For Business Owners",
      items: [
        {
          icon: Store,
          label: "Business Dashboard",
          description: "Manage your business and deals",
          action: () => navigate("/upload-deal"),
        },
        {
          icon: Shield,
          label: "Verify Your Business",
          description: "Increase trust and visibility",
          action: () => navigate("/verify-business"),
        },
      ],
    },
    {
      title: "Account",
      items: [
        {
          icon: User,
          label: "Edit Profile",
          description: "Update your personal information",
          action: () => navigate("/profile/edit"),
        },
        {
          icon: MapPin,
          label: "Saved Locations",
          description: "Manage your favorite locations",
          action: () => navigate("/saved-locations"),
        },
        {
          icon: Heart,
          label: "Preferences",
          description: "Customize your deal recommendations",
          action: () => navigate("/profile/preferences"),
        },
      ],
    },
    {
      title: "Activity",
      items: [
        {
          icon: Calendar,
          label: "My Shopping Plans",
          description: "View your AI-generated shopping routes",
          action: () => navigate("/plan"),
        },
        {
          icon: Award,
          label: "Achievements",
          description: "Track your savings and milestones",
          action: () => navigate("/profile/achievements"),
        },
      ],
    },
    {
      title: "Settings",
      items: [
        {
          icon: Bell,
          label: "Notifications",
          description: "Manage notification settings",
          action: () => navigate("/profile/notifications"),
        },
        {
          icon: Shield,
          label: "Privacy & Security",
          description: "Control your privacy settings",
          action: () => navigate("/profile/privacy"),
        },
        {
          icon: Settings,
          label: "Website Settings",
          description: "Website preferences and settings",
          action: () => navigate("/profile/website-settings"),
        },
      ],
    },
    {
      title: "Support",
      items: [
        {
          icon: HelpCircle,
          label: "Help & Support",
          description: "Get help and contact support",
          action: () => navigate("/profile/help-support"),
        },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      <ResponsiveHeader title="Profile" showMenu />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Mobile Profile Header */}
        <div className="lg:hidden bg-gradient-to-br from-primary to-primary/90 rounded-2xl p-6 mb-6 text-white">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-white/20 rounded-full flex items-center justify-center">
              <User className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
            </div>
            <div className="flex-1">
              <h2 className="text-lg sm:text-xl font-semibold mb-1">Guest User</h2>
              <p className="text-sm text-white/80">guest@dealhive.pk</p>
            </div>
          </div>
          <button className="w-full px-4 py-3 bg-white text-primary rounded-xl font-semibold active:bg-gray-100 transition-colors">
            Sign In
          </button>
        </div>

        {/* Mobile Stats */}
        <div className="lg:hidden grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white rounded-xl p-4 text-center shadow-sm border border-gray-100">
            <div className="text-2xl font-bold text-primary mb-1">12</div>
            <div className="text-xs text-muted-foreground">Saved</div>
          </div>
          <div className="bg-white rounded-xl p-4 text-center shadow-sm border border-gray-100">
            <div className="text-2xl font-bold text-accent mb-1">₨8.4k</div>
            <div className="text-xs text-muted-foreground">Saved</div>
          </div>
          <div className="bg-white rounded-xl p-4 text-center shadow-sm border border-gray-100">
            <div className="text-2xl font-bold text-primary mb-1">5</div>
            <div className="text-xs text-muted-foreground">Routes</div>
          </div>
        </div>

        {/* Desktop Layout */}
        <div className="hidden lg:grid lg:grid-cols-3 gap-8">
          {/* Left Column - Profile Info */}
          <div className="col-span-1">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sticky top-24">
              {/* Profile Header */}
              <div className="text-center mb-6">
                <div className="w-24 h-24 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User className="w-12 h-12 text-white" />
                </div>
                <h2 className="text-xl font-semibold text-foreground mb-1">Guest User</h2>
                <p className="text-sm text-muted-foreground mb-4">guest@dealhive.pk</p>
                <button className="w-full px-4 py-2 bg-accent text-white rounded-lg hover:bg-accent/90 transition-colors font-medium">
                  Sign In
                </button>
              </div>

              {/* Stats */}
              <div className="border-t border-gray-200 pt-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-sm text-muted-foreground">Saved Deals</span>
                    <span className="text-lg font-bold text-primary">12</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-sm text-muted-foreground">Total Saved</span>
                    <span className="text-lg font-bold text-accent">₨8,450</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-sm text-muted-foreground">Routes Planned</span>
                    <span className="text-lg font-bold text-primary">5</span>
                  </div>
                </div>
              </div>

              {/* Trust Badge */}
              <div className="mt-6 p-4 bg-gradient-to-br from-primary/10 to-primary/5 rounded-lg border border-primary/20">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-5 h-5 text-primary" />
                  <span className="font-semibold text-primary">Verified Member</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Your account is protected with Deal Hive security
                </p>
              </div>
            </div>
          </div>

          {/* Right Column - Menu Sections (Desktop) */}
          <div className="col-span-2">
            <div className="space-y-6">
              {menuSections.map((section, sectionIndex) => (
                <div key={sectionIndex}>
                  <h3 className="text-lg font-semibold text-foreground mb-3">{section.title}</h3>
                  <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                    {section.items.map((item, itemIndex) => {
                      const Icon = item.icon;
                      return (
                        <button
                          key={itemIndex}
                          onClick={item.action}
                          className="w-full flex items-center gap-4 px-6 py-4 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-b-0"
                        >
                          <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                            <Icon className="w-6 h-6 text-primary" />
                          </div>
                          <div className="flex-1 text-left">
                            <p className="font-semibold text-foreground mb-1">{item.label}</p>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          </div>
                          <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              {/* Logout Button */}
              <button className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-white rounded-2xl text-red-600 hover:bg-red-50 transition-colors shadow-sm border border-gray-100">
                <LogOut className="w-5 h-5" />
                <span className="font-semibold">Log Out</span>
              </button>

              {/* Website Info */}
              <div className="text-center py-4">
                <p className="text-sm text-muted-foreground">
                  Deal Hive v1.0.0 - Made with ❤️ in Pakistan
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Serving Islamabad
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Menu Sections */}
        <div className="lg:hidden space-y-6">
          {menuSections.map((section, sectionIndex) => (
            <div key={sectionIndex}>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3 px-1">
                {section.title}
              </h3>
              <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                {section.items.map((item, itemIndex) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={itemIndex}
                      onClick={item.action}
                      className="w-full flex items-center gap-3 sm:gap-4 px-4 py-4 active:bg-gray-50 transition-colors border-b border-gray-100 last:border-b-0"
                    >
                      <div className="w-10 h-10 sm:w-12 sm:h-12 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                        <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <p className="font-semibold text-sm sm:text-base text-foreground mb-0.5">
                          {item.label}
                        </p>
                        <p className="text-xs sm:text-sm text-muted-foreground truncate">
                          {item.description}
                        </p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Logout Button - Mobile */}
          <button className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-white rounded-2xl text-red-600 active:bg-red-50 transition-colors shadow-sm border border-gray-100">
            <LogOut className="w-5 h-5" />
            <span className="font-semibold">Log Out</span>
          </button>

          {/* Website Info - Mobile */}
          <div className="text-center py-4">
            <p className="text-xs text-muted-foreground">
              Deal Hive v1.0.0 - Made with ❤️ in Pakistan
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Serving Islamabad
            </p>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}