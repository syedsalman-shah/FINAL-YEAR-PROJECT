import { Sparkles, Mic, Clock, Route, MapPin, RefreshCw, Save } from "lucide-react";
import { RouteStop } from "./route-stop";
import { DesktopHeader } from "./desktop-header";
import { useState } from "react";

interface AIPlannerProps {
  onBack?: () => void;
}

export function AIPlanner({ onBack }: AIPlannerProps) {
  const [inputValue, setInputValue] = useState("");
  const [showPlan, setShowPlan] = useState(true); // Start with plan visible for demo

  const exampleQueries = [
    "Buy sneakers and lunch in Bahria",
    "Salon haircut + shoe shopping",
    "Family dinner + kids clothes",
    "Electronics shopping + coffee break",
    "Grocery shopping + bakery items",
  ];

  const handlePlanClick = () => {
    setShowPlan(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <DesktopHeader />

      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary to-primary/90 text-white py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            {/* Title Section */}
            <div className="text-center mb-8">
              <div className="flex items-center justify-center gap-3 mb-3">
                <h1 className="text-4xl font-bold">Plan Your Shopping Day</h1>
                <Sparkles className="w-8 h-8 text-yellow-300" fill="currentColor" />
              </div>
              <p className="text-lg text-white/90">
                Tell us what you need and our AI will optimize your route for maximum savings
              </p>
            </div>

            {/* Input Section */}
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <div className="flex gap-3 mb-4">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="e.g., I need shoes, belt, and want to eat something in Saddar around 5pm"
                  className="flex-1 px-4 py-3 bg-gray-50 rounded-lg text-foreground placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-primary"
                />
                <button className="p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <Mic className="w-6 h-6 text-primary" />
                </button>
              </div>
              <button
                onClick={handlePlanClick}
                className="w-full bg-accent text-white py-4 rounded-lg font-semibold hover:bg-accent/90 transition-colors text-lg"
              >
                Plan My Shopping Day
              </button>
            </div>

            {/* Example Queries */}
            <div className="mt-6 text-center">
              <p className="text-sm text-white/80 mb-3">Try these examples:</p>
              <div className="flex flex-wrap gap-2 justify-center">
                {exampleQueries.map((query, index) => (
                  <button
                    key={index}
                    onClick={() => setInputValue(query)}
                    className="px-4 py-2 bg-white/10 rounded-full text-sm border border-white/20 hover:bg-white/20 transition-colors backdrop-blur-sm"
                  >
                    {query}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Optimized Plan Section */}
      {showPlan && (
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="grid grid-cols-3 gap-8">
            {/* Left Column - Route Stops */}
            <div className="col-span-2">
              {/* Plan Summary */}
              <div className="mb-6">
                <div className="bg-gradient-to-br from-primary to-primary/80 text-white rounded-2xl p-6 shadow-md">
                  <div className="flex items-center gap-3 mb-4">
                    <Sparkles className="w-6 h-6 text-yellow-300" fill="currentColor" />
                    <h2 className="text-2xl font-semibold">Your Optimized Shopping Plan</h2>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5" />
                      <span>Total time: ~2.5 hours</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Route className="w-5 h-5" />
                      <span>3 stops • 1.2 km walking</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Route Stops */}
              <div className="space-y-4">
                <RouteStop
                  number={1}
                  icon="🥾"
                  shopName="Shoe Planet"
                  deal="40% off Nike Air Max (verified)"
                  location="Shop 12, Saddar Market"
                  walkingTime="2 mins from start"
                  verified={true}
                />

                <RouteStop
                  number={2}
                  icon="🍔"
                  shopName="Burger House"
                  deal="Buy 1 Get 1 Free (on your route)"
                  walkingTime="5 mins from Stop 1"
                  suggestion={true}
                  suggestionNote="You didn't ask for food but this is on your way!"
                />

                <RouteStop
                  number={3}
                  icon="👔"
                  shopName="Belt & Co."
                  deal="Buy belt get wallet free"
                  location="Shop 45, Saddar Plaza"
                  walkingTime="3 mins from Stop 2"
                  verified={true}
                />
              </div>

              {/* Bottom Actions */}
              <div className="mt-6 flex gap-4">
                <button className="flex-1 flex items-center justify-center gap-2 py-4 bg-white border-2 border-gray-200 text-foreground rounded-xl hover:bg-gray-50 transition-colors shadow-sm">
                  <RefreshCw className="w-5 h-5" />
                  <span className="font-semibold">Optimize Again</span>
                </button>
                <button className="flex-1 flex items-center justify-center gap-2 py-4 bg-primary text-white rounded-xl hover:bg-primary/90 transition-colors shadow-sm">
                  <Save className="w-5 h-5" />
                  <span className="font-semibold">Save This Plan</span>
                </button>
              </div>
            </div>

            {/* Right Column - Map Preview */}
            <div className="col-span-1">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 sticky top-24">
                <div className="flex items-center gap-2 mb-4">
                  <MapPin className="w-5 h-5 text-primary" />
                  <h3 className="font-semibold">Route Preview</h3>
                </div>
                
                {/* Map Placeholder */}
                <div className="relative bg-gradient-to-br from-secondary to-gray-100 rounded-lg h-96 overflow-hidden">
                  {/* Simplified Map Visual */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <svg width="100%" height="100%" viewBox="0 0 300 400" className="opacity-40">
                      {/* Road lines */}
                      <line x1="150" y1="80" x2="150" y2="320" stroke="#2d8659" strokeWidth="3" strokeDasharray="8,8" />
                      
                      {/* Stop markers */}
                      <circle cx="150" cy="100" r="12" fill="#2d8659" />
                      <text x="150" y="107" fontSize="16" fill="white" textAnchor="middle" fontWeight="bold">1</text>
                      
                      <circle cx="150" cy="200" r="12" fill="#ff6b35" />
                      <text x="150" y="207" fontSize="16" fill="white" textAnchor="middle" fontWeight="bold">2</text>
                      
                      <circle cx="150" cy="300" r="12" fill="#2d8659" />
                      <text x="150" y="307" fontSize="16" fill="white" textAnchor="middle" fontWeight="bold">3</text>
                    </svg>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <MapPin className="w-16 h-16 text-primary/30 mx-auto mb-3" />
                      <p className="text-sm text-muted-foreground">Interactive map preview</p>
                      <p className="text-xs text-muted-foreground mt-1">Route optimized for walking</p>
                    </div>
                  </div>
                </div>

                {/* Route Stats */}
                <div className="mt-6 space-y-3">
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-sm text-muted-foreground">Total Distance</span>
                    <span className="font-semibold text-primary">1.2 km</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-sm text-muted-foreground">Estimated Time</span>
                    <span className="font-semibold text-primary">2.5 hours</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-sm text-muted-foreground">Total Savings</span>
                    <span className="font-semibold text-accent">PKR 3,450</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
