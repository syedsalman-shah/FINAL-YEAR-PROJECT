import { useState } from "react";
import { Deal } from "../data/dealTypes";
import { MapPin, Navigation, BadgeCheck, Clock, ZoomIn, ZoomOut, Maximize2 } from "lucide-react";
import { useNavigate } from "react-router";

interface DealMapProps {
  deals: Deal[];
  selectedDealId?: string;
  onDealSelect?: (dealId: string) => void;
  height?: string;
  showControls?: boolean;
}

export function DealMap({ 
  deals, 
  selectedDealId, 
  onDealSelect,
  height = "400px",
  showControls = true 
}: DealMapProps) {
  const navigate = useNavigate();
  const [selectedMarker, setSelectedMarker] = useState<string | null>(null);

  // Filter deals with valid coordinates
  const dealsWithCoords = deals.filter(deal => deal.coordinates);

  // Calculate bounds for the map
  const bounds = dealsWithCoords.length > 0 ? {
    minLat: Math.min(...dealsWithCoords.map(d => d.coordinates!.lat)),
    maxLat: Math.max(...dealsWithCoords.map(d => d.coordinates!.lat)),
    minLng: Math.min(...dealsWithCoords.map(d => d.coordinates!.lng)),
    maxLng: Math.max(...dealsWithCoords.map(d => d.coordinates!.lng)),
  } : { minLat: 33.6, maxLat: 33.8, minLng: 72.9, maxLng: 73.2 };

  const centerLat = (bounds.minLat + bounds.maxLat) / 2;
  const centerLng = (bounds.minLng + bounds.maxLng) / 2;

  const handleViewDeal = (dealId: string) => {
    navigate(`/deal/${dealId}`);
  };

  const handleGetDirections = (deal: Deal) => {
    if (deal.coordinates) {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${deal.coordinates.lat},${deal.coordinates.lng}`;
      window.open(url, '_blank');
    }
  };

  const handleMarkerClick = (dealId: string) => {
    setSelectedMarker(dealId);
    onDealSelect?.(dealId);
  };

  const handleOpenInGoogleMaps = () => {
    // Open Google Maps with all markers
    const url = `https://www.google.com/maps/@${centerLat},${centerLng},13z`;
    window.open(url, '_blank');
  };

  // Convert coordinates to pixel positions (simplified projection)
  const coordToPixel = (lat: number, lng: number) => {
    const latRange = bounds.maxLat - bounds.minLat || 0.2;
    const lngRange = bounds.maxLng - bounds.minLng || 0.3;
    const padding = 0.1; // 10% padding

    const x = ((lng - bounds.minLng) / lngRange) * (1 - 2 * padding) + padding;
    const y = ((bounds.maxLat - lat) / latRange) * (1 - 2 * padding) + padding;

    return {
      left: `${x * 100}%`,
      top: `${y * 100}%`,
    };
  };

  const selectedDeal = dealsWithCoords.find(d => d.id === (selectedMarker || selectedDealId));

  return (
    <div className="relative">
      {/* Map Container with Google Maps Embed */}
      <div 
        className="relative overflow-hidden rounded-2xl bg-gray-100 border-2 border-gray-200"
        style={{ height }}
      >
        {/* Google Maps Static Image as Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-green-50 via-white to-blue-50">
          {/* Grid overlay for map-like appearance */}
          <div className="absolute inset-0 opacity-10">
            <svg width="100%" height="100%">
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="gray" strokeWidth="0.5"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>

          {/* Street-like pattern */}
          <div className="absolute inset-0">
            <div className="absolute top-1/4 left-0 right-0 h-px bg-gray-300 opacity-30"></div>
            <div className="absolute top-1/2 left-0 right-0 h-px bg-gray-300 opacity-30"></div>
            <div className="absolute top-3/4 left-0 right-0 h-px bg-gray-300 opacity-30"></div>
            <div className="absolute left-1/4 top-0 bottom-0 w-px bg-gray-300 opacity-30"></div>
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gray-300 opacity-30"></div>
            <div className="absolute left-3/4 top-0 bottom-0 w-px bg-gray-300 opacity-30"></div>
          </div>

          {/* Map Label */}
          <div className="absolute top-4 left-4 px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-lg shadow-sm border border-gray-200">
            <p className="text-xs font-semibold text-gray-700">Islamabad, Pakistan</p>
          </div>
        </div>

        {/* Deal Markers */}
        {dealsWithCoords.map((deal) => {
          const position = coordToPixel(deal.coordinates!.lat, deal.coordinates!.lng);
          const isSelected = deal.id === (selectedMarker || selectedDealId);
          const color = isSelected ? "#ff6b35" : deal.verified ? "#2d8659" : "#6b7280";

          return (
            <button
              key={deal.id}
              className="absolute transform -translate-x-1/2 -translate-y-full transition-all duration-200 hover:scale-110 cursor-pointer group z-10"
              style={position}
              onClick={() => handleMarkerClick(deal.id)}
              title={deal.businessName}
            >
              {/* Pin SVG */}
              <svg 
                width="32" 
                height="42" 
                viewBox="0 0 32 42" 
                className={`drop-shadow-lg ${isSelected ? 'animate-bounce' : ''}`}
              >
                <path 
                  d="M16 0C7.163 0 0 7.163 0 16c0 12 16 26 16 26s16-14 16-26c0-8.837-7.163-16-16-16z" 
                  fill={color}
                  stroke="white" 
                  strokeWidth="2"
                />
                <circle cx="16" cy="16" r="6" fill="white"/>
              </svg>

              {/* Tooltip on hover */}
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                <div className="bg-gray-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                  {deal.businessName}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Deal Card */}
      {selectedDeal && (
        <div className="absolute bottom-4 left-4 right-4 z-20 bg-white rounded-xl shadow-2xl border border-gray-200 p-4 max-w-sm mx-auto">
          <div className="relative">
            <img
              src={selectedDeal.dealImage}
              alt={selectedDeal.businessName}
              className="w-full h-32 object-cover rounded-lg mb-3"
            />
            {selectedDeal.discount && (
              <div className="absolute top-2 right-2 bg-accent text-white px-2 py-1 rounded-lg text-xs font-bold">
                {selectedDeal.discount}% OFF
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-2 mb-2">
            <h3 className="font-semibold text-base text-foreground flex-1">
              {selectedDeal.businessName}
            </h3>
            {selectedDeal.verified && (
              <BadgeCheck className="w-4 h-4 text-primary flex-shrink-0" fill="currentColor" />
            )}
          </div>
          
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
            {selectedDeal.dealTitle}
          </p>
          
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground line-through">
                ₨{selectedDeal.originalPrice}
              </span>
              <span className="text-base font-bold text-primary">
                ₨{selectedDeal.dealPrice}
              </span>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin className="w-3 h-3" />
              <span>{selectedDeal.distance}</span>
            </div>
          </div>
          
          {selectedDeal.hours && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
              <Clock className="w-3 h-3" />
              <span>{selectedDeal.hours}</span>
            </div>
          )}
          
          <div className="flex gap-2">
            <button
              onClick={() => handleViewDeal(selectedDeal.id)}
              className="flex-1 px-3 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              View Deal
            </button>
            <button
              onClick={() => handleGetDirections(selectedDeal)}
              className="px-3 py-2 bg-accent text-white rounded-lg hover:bg-accent/90 transition-colors"
              title="Get Directions"
            >
              <Navigation className="w-4 h-4" />
            </button>
          </div>

          {/* Close button */}
          <button
            onClick={() => setSelectedMarker(null)}
            className="absolute top-2 right-2 w-6 h-6 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-gray-100 transition-colors"
            aria-label="Close"
          >
            <span className="text-gray-600 text-sm">×</span>
          </button>
        </div>
      )}

      {/* Map Controls */}
      {showControls && (
        <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
          <button
            onClick={handleOpenInGoogleMaps}
            className="px-3 py-2 bg-white rounded-lg shadow-lg text-sm font-medium hover:bg-gray-50 transition-colors border border-gray-200 flex items-center gap-2"
            title="Open in Google Maps"
          >
            <Maximize2 className="w-4 h-4" />
            <span className="hidden sm:inline">Open Maps</span>
          </button>
        </div>
      )}

      {/* Deal Count Badge */}
      <div className="absolute bottom-4 left-4 z-10 px-3 py-2 bg-white rounded-lg shadow-lg border border-gray-200">
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-primary" />
          <span className="text-sm font-semibold text-foreground">
            {dealsWithCoords.length} {dealsWithCoords.length === 1 ? "Deal" : "Deals"}
          </span>
        </div>
      </div>
    </div>
  );
}
