import { useState } from "react";
import { DesktopHeader } from "../components/desktop-header";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Progress } from "../components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import {
  Instagram,
  Globe,
  MessageCircle,
  CheckCircle2,
  XCircle,
  Loader2,
  Shield,
  TrendingUp,
  Info,
  AlertCircle,
  MapPin,
  Locate,
  UtensilsCrossed,
} from "lucide-react";
import { useNavigate } from "react-router";

type ConnectionStatus = "not_connected" | "verifying" | "connected" | "failed";

interface SocialConnection {
  platform: "instagram" | "website" | "whatsapp";
  status: ConnectionStatus;
  value: string;
  error?: string;
}

// Component with all hooks properly ordered
export function VerifyBusinessPage() {
  const navigate = useNavigate();

  // Connection states - ALL hooks must be declared at the top level
  const [instagram, setInstagram] = useState<SocialConnection>({
    platform: "instagram",
    status: "not_connected",
    value: "",
  });

  const [website, setWebsite] = useState<SocialConnection>({
    platform: "website",
    status: "not_connected",
    value: "",
  });

  const [whatsapp, setWhatsapp] = useState<SocialConnection>({
    platform: "whatsapp",
    status: "not_connected",
    value: "",
  });

  const [foodpanda, setFoodpanda] = useState({
    status: "not_connected" as ConnectionStatus,
    value: "",
    error: undefined as string | undefined,
  });

  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");

  // Business Location state
  const [locationSector, setLocationSector] = useState("");
  const [businessAddress, setBusinessAddress] = useState("");
  const [businessLatitude, setBusinessLatitude] = useState("");
  const [businessLongitude, setBusinessLongitude] = useState("");
  const [locationStatus, setLocationStatus] = useState<"not_set" | "set">("not_set");

  // Calculate trust score
  const baseTrustScore = 45;
  const instagramBonus = instagram.status === "connected" ? 20 : 0;
  const websiteBonus = website.status === "connected" ? 15 : 0;
  const whatsappBonus = whatsapp.status === "connected" ? 15 : 0;
  const foodpandaBonus = foodpanda.status === "connected" ? 10 : 0;
  const currentScore =
    baseTrustScore + instagramBonus + websiteBonus + whatsappBonus + foodpandaBonus;
  const potentialScore = 95;

  const handleVerifyInstagram = async () => {
    if (!instagram.value.trim()) {
      setInstagram({ ...instagram, error: "Please enter your Instagram username or profile link" });
      return;
    }

    setInstagram({ ...instagram, status: "verifying", error: undefined });

    // Simulate API call
    setTimeout(() => {
      // Mock successful verification
      if (instagram.value.length > 3) {
        setInstagram({ ...instagram, status: "connected" });
      } else {
        setInstagram({
          ...instagram,
          status: "failed",
          error: "Could not verify this Instagram account",
        });
      }
    }, 2000);
  };

  const handleVerifyWebsite = async () => {
    if (!website.value.trim()) {
      setWebsite({ ...website, error: "Please enter your website URL" });
      return;
    }

    // Basic URL validation
    if (!website.value.includes(".")) {
      setWebsite({ ...website, error: "Please enter a valid URL" });
      return;
    }

    setWebsite({ ...website, status: "verifying", error: undefined });

    // Simulate API call
    setTimeout(() => {
      setWebsite({ ...website, status: "connected" });
    }, 2000);
  };

  const handleSendOTP = async () => {
    if (!whatsapp.value.trim()) {
      setWhatsapp({ ...whatsapp, error: "Please enter your WhatsApp number" });
      return;
    }

    setWhatsapp({ ...whatsapp, status: "verifying", error: undefined });

    // Simulate sending OTP
    setTimeout(() => {
      setOtpSent(true);
      setWhatsapp({ ...whatsapp, status: "not_connected" });
    }, 1500);
  };

  const handleVerifyWhatsApp = async () => {
    if (!otp.trim() || otp.length < 4) {
      setWhatsapp({ ...whatsapp, error: "Please enter a valid OTP" });
      return;
    }

    setWhatsapp({ ...whatsapp, status: "verifying", error: undefined });

    // Simulate OTP verification
    setTimeout(() => {
      if (otp === "1234" || otp.length >= 4) {
        setWhatsapp({ ...whatsapp, status: "connected" });
        setOtpSent(false);
      } else {
        setWhatsapp({ ...whatsapp, status: "failed", error: "Invalid OTP" });
      }
    }, 1500);
  };

  const handleVerifyFoodpanda = async () => {
    if (!foodpanda.value.trim()) {
      setFoodpanda({ ...foodpanda, error: "Please enter your Foodpanda restaurant ID" });
      return;
    }

    setFoodpanda({ ...foodpanda, status: "verifying", error: undefined });

    // Simulate API call
    setTimeout(() => {
      if (foodpanda.value.length > 3) {
        setFoodpanda({ ...foodpanda, status: "connected" });
      } else {
        setFoodpanda({
          ...foodpanda,
          status: "failed",
          error: "Could not verify this Foodpanda account",
        });
      }
    }, 2000);
  };

  const handleSetLocation = () => {
    if (!locationSector || !businessLatitude || !businessLongitude) {
      return;
    }
    setLocationStatus("set");
  };

  const handleUseCurrentLocation = () => {
    // Mock geolocation
    setBusinessAddress("F-7 Markaz, Islamabad");
    setBusinessLatitude("33.7215");
    setBusinessLongitude("73.0433");
    setLocationSector("F-7");
  };

  const hasAtLeastOneConnection =
    instagram.status === "connected" ||
    website.status === "connected" ||
    whatsapp.status === "connected";

  const handleContinue = () => {
    // Navigate to next step or back to profile
    navigate("/profile");
  };

  const handleSkip = () => {
    navigate("/profile");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <DesktopHeader />

      <div className="max-w-5xl mx-auto px-6 py-8">
        {/* Header Section */}
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-3xl">Verify Your Business</h1>
          </div>
          <p className="text-muted-foreground text-lg">
            Connect your accounts to build trust • Step 2 of 3
          </p>
        </div>

        {/* Progress Steps Indicator */}
        <div className="mb-10">
          <div className="flex items-center justify-center gap-2 max-w-md mx-auto">
            <div className="flex items-center gap-2 flex-1">
              <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div className="h-1 flex-1 bg-primary rounded" />
            </div>
            <div className="flex items-center gap-2 flex-1">
              <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center font-semibold">
                2
              </div>
              <div className="h-1 flex-1 bg-gray-300 rounded" />
            </div>
            <div className="w-10 h-10 rounded-full bg-gray-300 text-gray-500 flex items-center justify-center font-semibold">
              3
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content - Connection Cards */}
          <div className="lg:col-span-2 space-y-6">
            {/* Instagram Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 flex items-center justify-center">
                    <Instagram className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Instagram</h3>
                    <div className="flex items-center gap-2 mt-1">
                      {instagram.status === "connected" ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span className="text-sm text-green-600 font-medium">
                            Connected
                          </span>
                        </>
                      ) : instagram.status === "failed" ? (
                        <>
                          <XCircle className="w-4 h-4 text-red-600" />
                          <span className="text-sm text-red-600 font-medium">
                            Failed
                          </span>
                        </>
                      ) : (
                        <span className="text-sm text-muted-foreground">
                          Not Connected
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-primary font-semibold">+20 pts</div>
                  <div className="text-xs text-muted-foreground">Trust Score</div>
                </div>
              </div>

              {instagram.status !== "connected" && (
                <>
                  <div className="space-y-2 mb-4">
                    <Label htmlFor="instagram">
                      Instagram Username or Profile Link
                    </Label>
                    <Input
                      id="instagram"
                      placeholder="@yourbusiness or instagram.com/yourbusiness"
                      value={instagram.value}
                      onChange={(e) =>
                        setInstagram({ ...instagram, value: e.target.value })
                      }
                      disabled={instagram.status === "verifying"}
                      className={instagram.error ? "border-red-500" : ""}
                    />
                    {instagram.error && (
                      <p className="text-xs text-red-600 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {instagram.error}
                      </p>
                    )}
                  </div>

                  <Button
                    onClick={handleVerifyInstagram}
                    disabled={instagram.status === "verifying"}
                    className="w-full bg-accent hover:bg-accent/90"
                  >
                    {instagram.status === "verifying" ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      "Verify Instagram"
                    )}
                  </Button>

                  <p className="text-xs text-muted-foreground mt-3 flex items-start gap-1">
                    <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
                    We'll check your account age and consistency with your business
                    info
                  </p>
                </>
              )}

              {instagram.status === "connected" && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-medium text-green-900">
                      Successfully verified @{instagram.value}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      setInstagram({ ...instagram, status: "not_connected" })
                    }
                    className="text-green-700 hover:text-green-900"
                  >
                    Change
                  </Button>
                </div>
              )}
            </div>

            {/* Website Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-blue-500 flex items-center justify-center">
                    <Globe className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Website</h3>
                    <div className="flex items-center gap-2 mt-1">
                      {website.status === "connected" ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span className="text-sm text-green-600 font-medium">
                            Connected
                          </span>
                        </>
                      ) : (
                        <span className="text-sm text-muted-foreground">
                          Not Connected • Optional
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-primary font-semibold">+15 pts</div>
                  <div className="text-xs text-muted-foreground">Trust Score</div>
                </div>
              </div>

              {website.status !== "connected" && (
                <>
                  <div className="space-y-2 mb-4">
                    <Label htmlFor="website">Website URL (if any)</Label>
                    <Input
                      id="website"
                      type="url"
                      placeholder="https://yourbusiness.com"
                      value={website.value}
                      onChange={(e) =>
                        setWebsite({ ...website, value: e.target.value })
                      }
                      disabled={website.status === "verifying"}
                      className={website.error ? "border-red-500" : ""}
                    />
                    {website.error && (
                      <p className="text-xs text-red-600 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {website.error}
                      </p>
                    )}
                  </div>

                  <Button
                    onClick={handleVerifyWebsite}
                    disabled={website.status === "verifying"}
                    className="w-full bg-accent hover:bg-accent/90"
                  >
                    {website.status === "verifying" ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      "Verify Website"
                    )}
                  </Button>

                  <p className="text-xs text-muted-foreground mt-3 flex items-start gap-1">
                    <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
                    Optional but significantly increases your trust score and customer
                    confidence
                  </p>
                </>
              )}

              {website.status === "connected" && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-medium text-green-900">
                      {website.value}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      setWebsite({ ...website, status: "not_connected" })
                    }
                    className="text-green-700 hover:text-green-900"
                  >
                    Change
                  </Button>
                </div>
              )}
            </div>

            {/* WhatsApp Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-green-500 flex items-center justify-center">
                    <MessageCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">WhatsApp Business</h3>
                    <div className="flex items-center gap-2 mt-1">
                      {whatsapp.status === "connected" ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span className="text-sm text-green-600 font-medium">
                            Connected
                          </span>
                        </>
                      ) : whatsapp.status === "failed" ? (
                        <>
                          <XCircle className="w-4 h-4 text-red-600" />
                          <span className="text-sm text-red-600 font-medium">
                            Failed
                          </span>
                        </>
                      ) : (
                        <span className="text-sm text-muted-foreground">
                          Not Connected
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-primary font-semibold">+15 pts</div>
                  <div className="text-xs text-muted-foreground">Trust Score</div>
                </div>
              </div>

              {whatsapp.status !== "connected" && (
                <>
                  <div className="space-y-2 mb-4">
                    <Label htmlFor="whatsapp">WhatsApp Business Number</Label>
                    <Input
                      id="whatsapp"
                      type="tel"
                      placeholder="+92 300 1234567"
                      value={whatsapp.value}
                      onChange={(e) =>
                        setWhatsapp({ ...whatsapp, value: e.target.value })
                      }
                      disabled={whatsapp.status === "verifying" || otpSent}
                      className={whatsapp.error ? "border-red-500" : ""}
                    />
                    {whatsapp.error && (
                      <p className="text-xs text-red-600 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {whatsapp.error}
                      </p>
                    )}
                  </div>

                  {!otpSent ? (
                    <Button
                      onClick={handleSendOTP}
                      disabled={whatsapp.status === "verifying"}
                      className="w-full bg-accent hover:bg-accent/90"
                    >
                      {whatsapp.status === "verifying" ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Sending OTP...
                        </>
                      ) : (
                        "Send OTP"
                      )}
                    </Button>
                  ) : (
                    <>
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                        <p className="text-sm text-blue-900">
                          OTP sent to {whatsapp.value}. Please enter the code below.
                        </p>
                      </div>
                      <div className="space-y-2 mb-3">
                        <Label htmlFor="otp">Enter OTP Code</Label>
                        <Input
                          id="otp"
                          placeholder="Enter 4-digit code"
                          value={otp}
                          onChange={(e) => setOtp(e.target.value)}
                          maxLength={6}
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={handleVerifyWhatsApp}
                          disabled={whatsapp.status === "verifying"}
                          className="flex-1 bg-accent hover:bg-accent/90"
                        >
                          {whatsapp.status === "verifying" ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Verifying...
                            </>
                          ) : (
                            "Verify OTP"
                          )}
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setOtpSent(false);
                            setOtp("");
                          }}
                        >
                          Resend
                        </Button>
                      </div>
                    </>
                  )}

                  <p className="text-xs text-muted-foreground mt-3 flex items-start gap-1">
                    <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
                    We'll send a verification code to confirm your number
                  </p>
                </>
              )}

              {whatsapp.status === "connected" && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-medium text-green-900">
                      {whatsapp.value}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      setWhatsapp({ ...whatsapp, status: "not_connected" })
                    }
                    className="text-green-700 hover:text-green-900"
                  >
                    Change
                  </Button>
                </div>
              )}
            </div>

            {/* foodpanda Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-600 to-pink-400 flex items-center justify-center">
                    <UtensilsCrossed className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">foodpanda Partner</h3>
                    <div className="flex items-center gap-2 mt-1">
                      {foodpanda.status === "connected" ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span className="text-sm text-green-600 font-medium">
                            Connected
                          </span>
                        </>
                      ) : foodpanda.status === "failed" ? (
                        <>
                          <XCircle className="w-4 h-4 text-red-600" />
                          <span className="text-sm text-red-600 font-medium">
                            Failed
                          </span>
                        </>
                      ) : (
                        <span className="text-sm text-muted-foreground">
                          Not Connected • Optional
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-primary font-semibold">+10 pts</div>
                  <div className="text-xs text-muted-foreground">Trust Score</div>
                </div>
              </div>

              {foodpanda.status !== "connected" && (
                <>
                  <div className="space-y-2 mb-4">
                    <Label htmlFor="foodpanda">foodpanda Restaurant ID</Label>
                    <Input
                      id="foodpanda"
                      placeholder="Enter your restaurant ID or profile link"
                      value={foodpanda.value}
                      onChange={(e) =>
                        setFoodpanda({ ...foodpanda, value: e.target.value })
                      }
                      disabled={foodpanda.status === "verifying"}
                      className={foodpanda.error ? "border-red-500" : ""}
                    />
                    {foodpanda.error && (
                      <p className="text-xs text-red-600 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {foodpanda.error}
                      </p>
                    )}
                  </div>

                  <Button
                    onClick={handleVerifyFoodpanda}
                    disabled={foodpanda.status === "verifying"}
                    className="w-full bg-accent hover:bg-accent/90"
                  >
                    {foodpanda.status === "verifying" ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      "Verify foodpanda"
                    )}
                  </Button>

                  <p className="text-xs text-muted-foreground mt-3 flex items-start gap-1">
                    <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
                    Linking your foodpanda profile shows you're an established restaurant partner
                  </p>
                </>
              )}

              {foodpanda.status === "connected" && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-medium text-green-900">
                      Successfully verified {foodpanda.value}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      setFoodpanda({ ...foodpanda, status: "not_connected" })
                    }
                    className="text-green-700 hover:text-green-900"
                  >
                    Change
                  </Button>
                </div>
              )}
            </div>

            {/* Business Location Card - REQUIRED */}
            <div className="bg-white rounded-xl shadow-sm border-2 border-primary/30 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-primary flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg flex items-center gap-2">
                      Business Location
                      <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-semibold">
                        REQUIRED
                      </span>
                    </h3>
                    <div className="flex items-center gap-2 mt-1">
                      {locationStatus === "set" ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span className="text-sm text-green-600 font-medium">
                            Location Set
                          </span>
                        </>
                      ) : (
                        <span className="text-sm text-muted-foreground">
                          Required for map visibility
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {locationStatus !== "set" && (
                <>
                  <div className="space-y-4 mb-4">
                    {/* Sector Selector */}
                    <div className="space-y-2">
                      <Label htmlFor="sector">Islamabad Sector/Area *</Label>
                      <Select value={locationSector} onValueChange={setLocationSector}>
                        <SelectTrigger className="border-gray-300">
                          <SelectValue placeholder="Select your sector" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="F-6">F-6 (Blue Area)</SelectItem>
                          <SelectItem value="F-7">F-7 (Jinnah Super)</SelectItem>
                          <SelectItem value="F-8">F-8 (Markaz)</SelectItem>
                          <SelectItem value="F-10">F-10 (Markaz)</SelectItem>
                          <SelectItem value="F-11">F-11 (Markaz)</SelectItem>
                          <SelectItem value="G-6">G-6</SelectItem>
                          <SelectItem value="G-7">G-7 (Aabpara)</SelectItem>
                          <SelectItem value="G-8">G-8 (Kachnar Park)</SelectItem>
                          <SelectItem value="G-9">G-9 (Karachi Company)</SelectItem>
                          <SelectItem value="G-10">G-10 (Markaz)</SelectItem>
                          <SelectItem value="G-11">G-11 (Markaz)</SelectItem>
                          <SelectItem value="I-8">I-8 (Markaz)</SelectItem>
                          <SelectItem value="I-9">I-9</SelectItem>
                          <SelectItem value="I-10">I-10 (Markaz)</SelectItem>
                          <SelectItem value="Saddar">Saddar</SelectItem>
                          <SelectItem value="Blue Area">Blue Area</SelectItem>
                          <SelectItem value="Centaurus">Centaurus Mall</SelectItem>
                          <SelectItem value="Kohsar">Kohsar Market</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Business Address */}
                    <div className="space-y-2">
                      <Label htmlFor="businessAddress">Complete Business Address</Label>
                      <Input
                        id="businessAddress"
                        placeholder="Shop/Building name, Street, etc."
                        value={businessAddress}
                        onChange={(e) => setBusinessAddress(e.target.value)}
                        className="border-gray-300"
                      />
                    </div>

                    {/* GPS Coordinates */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="latitude">Latitude *</Label>
                        <Input
                          id="latitude"
                          type="number"
                          step="0.000001"
                          placeholder="33.6844"
                          value={businessLatitude}
                          onChange={(e) => setBusinessLatitude(e.target.value)}
                          className="border-gray-300"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="longitude">Longitude *</Label>
                        <Input
                          id="longitude"
                          type="number"
                          step="0.000001"
                          placeholder="73.0479"
                          value={businessLongitude}
                          onChange={(e) => setBusinessLongitude(e.target.value)}
                          className="border-gray-300"
                        />
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={handleUseCurrentLocation}
                    variant="outline"
                    className="w-full mb-3 border-primary text-primary hover:bg-secondary"
                  >
                    <Locate className="mr-2 h-4 w-4" />
                    Auto-Fill My Current Location
                  </Button>

                  <Button
                    onClick={handleSetLocation}
                    disabled={!locationSector || !businessLatitude || !businessLongitude}
                    className="w-full bg-accent hover:bg-accent/90"
                  >
                    Set Business Location
                  </Button>

                  <p className="text-xs text-muted-foreground mt-3 flex items-start gap-1">
                    <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
                    Your location helps customers find you on the map. Get coordinates from Google Maps by right-clicking your location.
                  </p>
                </>
              )}

              {locationStatus === "set" && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                      <span className="text-sm font-medium text-green-900">
                        Location Confirmed
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setLocationStatus("not_set")}
                      className="text-green-700 hover:text-green-900"
                    >
                      Change
                    </Button>
                  </div>
                  <div className="text-sm text-green-800 space-y-1">
                    <p><strong>Sector:</strong> {locationSector}</p>
                    {businessAddress && <p><strong>Address:</strong> {businessAddress}</p>}
                    <p><strong>Coordinates:</strong> {businessLatitude}, {businessLongitude}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar - Trust Score Preview */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-5 h-5 text-primary" />
                <h4 className="font-semibold">Trust Score Preview</h4>
              </div>

              {/* Current Score */}
              <div className="mb-6">
                <div className="flex items-end justify-between mb-2">
                  <span className="text-sm text-muted-foreground">
                    Current Score
                  </span>
                  <span className="text-3xl font-bold text-primary">
                    {currentScore}
                    <span className="text-lg text-muted-foreground">/100</span>
                  </span>
                </div>
                <Progress value={currentScore} className="h-3" />
              </div>

              <div className="mb-6">
                <p className="text-sm text-muted-foreground mb-4">
                  Connect accounts to increase your score:
                </p>

                {/* Score Breakdown */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {instagram.status === "connected" ? (
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border-2 border-gray-300" />
                      )}
                      <span className="text-sm">Instagram</span>
                    </div>
                    <span
                      className={`text-sm font-semibold ${
                        instagram.status === "connected"
                          ? "text-green-600"
                          : "text-muted-foreground"
                      }`}
                    >
                      +20 pts
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {website.status === "connected" ? (
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border-2 border-gray-300" />
                      )}
                      <span className="text-sm">Website</span>
                    </div>
                    <span
                      className={`text-sm font-semibold ${
                        website.status === "connected"
                          ? "text-green-600"
                          : "text-muted-foreground"
                      }`}
                    >
                      +15 pts
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {whatsapp.status === "connected" ? (
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border-2 border-gray-300" />
                      )}
                      <span className="text-sm">WhatsApp</span>
                    </div>
                    <span
                      className={`text-sm font-semibold ${
                        whatsapp.status === "connected"
                          ? "text-green-600"
                          : "text-muted-foreground"
                      }`}
                    >
                      +15 pts
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {foodpanda.status === "connected" ? (
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border-2 border-gray-300" />
                      )}
                      <span className="text-sm">foodpanda</span>
                    </div>
                    <span
                      className={`text-sm font-semibold ${
                        foodpanda.status === "connected"
                          ? "text-green-600"
                          : "text-muted-foreground"
                      }`}
                    >
                      +10 pts
                    </span>
                  </div>
                </div>
              </div>

              {/* Potential Score */}
              <div className="bg-gradient-to-br from-primary/10 to-secondary border border-primary/20 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Potential Score</span>
                  <span className="text-2xl font-bold text-primary">
                    {potentialScore}
                    <span className="text-sm text-muted-foreground">/100</span>
                  </span>
                </div>
                <Progress value={potentialScore} className="h-2 mb-2" />
                <p className="text-xs text-muted-foreground">
                  Complete all verifications to maximize customer trust
                </p>
              </div>

              {/* Benefits */}
              <div className="mt-6 pt-6 border-t">
                <h5 className="text-sm font-semibold mb-3">Benefits</h5>
                <ul className="space-y-2 text-xs text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-primary mt-0.5 flex-shrink-0" />
                    <span>Higher visibility in search results</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-primary mt-0.5 flex-shrink-0" />
                    <span>Verified badge on your business profile</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-primary mt-0.5 flex-shrink-0" />
                    <span>Increased customer confidence</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3 h-3 text-primary mt-0.5 flex-shrink-0" />
                    <span>Priority in AI Shopping Planner recommendations</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="flex justify-between items-center mt-8 pt-6 border-t max-w-3xl mx-auto">
          <Button
            variant="outline"
            onClick={handleSkip}
            className="border-gray-300"
          >
            Skip for Now
          </Button>

          <Button
            onClick={handleContinue}
            disabled={!hasAtLeastOneConnection}
            className="bg-primary hover:bg-primary/90"
          >
            Continue to Next Step
          </Button>
        </div>

        {/* Help Text */}
        {!hasAtLeastOneConnection && (
          <p className="text-center text-sm text-muted-foreground mt-4">
            Connect at least one account to continue
          </p>
        )}
      </div>
    </div>
  );
}