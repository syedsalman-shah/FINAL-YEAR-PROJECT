import { MapPin, BadgeCheck, Bookmark, CalendarPlus } from "lucide-react";
import { useNavigate } from "react-router";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Deal } from "../data/mockDeals";
import { useApp } from "../context/AppContext";

export function DealListItem(props: Deal) {
  const navigate = useNavigate();
  const { isSaved, toggleSaveDeal, isInPlan, addToPlan, removeFromPlan } = useApp();
  
  const discountPercent = props.originalPrice && props.dealPrice
    ? Math.round(((props.originalPrice - props.dealPrice) / props.originalPrice) * 100)
    : 0;

  const saved = isSaved(props.id);
  const inPlan = isInPlan(props.id);

  const handleClick = () => {
    navigate(`/deal/${props.id}`);
  };

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleSaveDeal(props);
  };

  const handlePlan = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (inPlan) {
      removeFromPlan(props.id);
    } else {
      addToPlan(props);
    }
  };

  return (
    <div
      className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden flex gap-3 sm:gap-4 p-3 sm:p-4 w-full hover:shadow-lg active:shadow-md transition-all relative"
    >
      <div 
        className="relative w-20 h-20 sm:w-24 sm:h-24 flex-shrink-0 rounded-xl overflow-hidden cursor-pointer"
        onClick={handleClick}
      >
        <ImageWithFallback
          src={props.dealImage}
          alt={props.businessName}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-1.5 right-1.5 bg-accent text-white px-2 py-0.5 sm:py-1 rounded-md text-[10px] sm:text-xs font-bold shadow-md">
          {discountPercent}%
        </div>
      </div>
      <div className="flex-1 min-w-0 flex flex-col justify-between cursor-pointer" onClick={handleClick}>
        <div>
          <div className="flex items-center gap-1.5 mb-1">
            <h4 className="text-sm sm:text-base font-semibold text-foreground truncate flex-1">
              {props.businessName}
            </h4>
            {props.verified && (
              <BadgeCheck className="w-4 h-4 sm:w-5 sm:h-5 text-primary flex-shrink-0" fill="currentColor" />
            )}
          </div>
          <p className="text-xs sm:text-sm text-muted-foreground mb-2 line-clamp-2">
            {props.description}
          </p>
        </div>
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm text-muted-foreground line-through">
              ₨{props.originalPrice}
            </span>
            <span className="text-sm sm:text-base font-bold text-primary">
              ₨{props.dealPrice}
            </span>
          </div>
          <div className="flex items-center gap-1 text-xs sm:text-sm text-muted-foreground">
            <MapPin className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">{props.distance}</span>
          </div>
        </div>
      </div>
      <div className="flex flex-col gap-2 justify-center">
        <button
          onClick={handleSave}
          className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center transition-all ${
            saved
              ? "bg-accent text-white"
              : "bg-gray-100 hover:bg-gray-200 text-gray-700"
          }`}
        >
          <Bookmark className={`w-4 h-4 ${saved ? "fill-current" : ""}`} />
        </button>
        <button
          onClick={handlePlan}
          className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center transition-all ${
            inPlan
              ? "bg-primary text-white"
              : "bg-gray-100 hover:bg-gray-200 text-gray-700"
          }`}
        >
          <CalendarPlus className={`w-4 h-4 ${inPlan ? "fill-current" : ""}`} />
        </button>
      </div>
    </div>
  );
}
