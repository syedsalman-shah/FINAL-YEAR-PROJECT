import { useState } from "react";
import { DesktopHeader } from "../components/desktop-header";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  ArrowLeft,
  MapPin,
  Home,
  Briefcase,
  Star,
  Plus,
  Trash2,
  Edit2,
  Navigation,
} from "lucide-react";
import { useNavigate } from "react-router";

interface SavedLocation {
  id: string;
  name: string;
  address: string;
  type: "home" | "work" | "favorite";
  icon: any;
}

export function SavedLocationsPage() {
  const navigate = useNavigate();
  const [locations, setLocations] = useState<SavedLocation[]>([
    {
      id: "1",
      name: "Home",
      address: "F-7 Markaz, Islamabad",
      type: "home",
      icon: Home,
    },
    {
      id: "2",
      name: "Office",
      address: "Blue Area, Islamabad",
      type: "work",
      icon: Briefcase,
    },
    {
      id: "3",
      name: "Centaurus Mall",
      address: "Jinnah Avenue, Islamabad",
      type: "favorite",
      icon: Star,
    },
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [newLocationName, setNewLocationName] = useState("");
  const [newLocationAddress, setNewLocationAddress] = useState("");
  const [selectedType, setSelectedType] = useState<"home" | "work" | "favorite">("favorite");

  const handleAddLocation = () => {
    if (!newLocationName.trim() || !newLocationAddress.trim()) return;

    const iconMap = {
      home: Home,
      work: Briefcase,
      favorite: Star,
    };

    const newLocation: SavedLocation = {
      id: Date.now().toString(),
      name: newLocationName,
      address: newLocationAddress,
      type: selectedType,
      icon: iconMap[selectedType],
    };

    setLocations([...locations, newLocation]);
    setNewLocationName("");
    setNewLocationAddress("");
    setShowAddForm(false);
  };

  const handleDeleteLocation = (id: string) => {
    setLocations(locations.filter((loc) => loc.id !== id));
  };

  const handleUseCurrentLocation = () => {
    // Mock geolocation
    setNewLocationAddress("Current Location, Islamabad");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <DesktopHeader />

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => navigate("/profile")}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-3xl mb-1">Saved Locations</h1>
              <p className="text-muted-foreground">
                Manage your frequently visited locations
              </p>
            </div>
          </div>
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            className="bg-primary hover:bg-primary/90"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Location
          </Button>
        </div>

        {/* Add Location Form */}
        {showAddForm && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
            <h2 className="text-xl font-semibold mb-4">Add New Location</h2>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="locationName">Location Name</Label>
                <Input
                  id="locationName"
                  value={newLocationName}
                  onChange={(e) => setNewLocationName(e.target.value)}
                  placeholder="e.g., My Gym, Favorite Restaurant"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="locationAddress">Address</Label>
                <div className="flex gap-2">
                  <Input
                    id="locationAddress"
                    value={newLocationAddress}
                    onChange={(e) => setNewLocationAddress(e.target.value)}
                    placeholder="Enter full address"
                    className="flex-1"
                  />
                  <Button
                    variant="outline"
                    onClick={handleUseCurrentLocation}
                    className="whitespace-nowrap"
                  >
                    <Navigation className="w-4 h-4 mr-2" />
                    Use Current
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Location Type</Label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => setSelectedType("home")}
                    className={`p-4 border-2 rounded-lg flex flex-col items-center gap-2 transition-colors ${
                      selectedType === "home"
                        ? "border-primary bg-primary/5"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <Home className={`w-6 h-6 ${selectedType === "home" ? "text-primary" : "text-muted-foreground"}`} />
                    <span className="text-sm font-medium">Home</span>
                  </button>
                  <button
                    onClick={() => setSelectedType("work")}
                    className={`p-4 border-2 rounded-lg flex flex-col items-center gap-2 transition-colors ${
                      selectedType === "work"
                        ? "border-primary bg-primary/5"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <Briefcase className={`w-6 h-6 ${selectedType === "work" ? "text-primary" : "text-muted-foreground"}`} />
                    <span className="text-sm font-medium">Work</span>
                  </button>
                  <button
                    onClick={() => setSelectedType("favorite")}
                    className={`p-4 border-2 rounded-lg flex flex-col items-center gap-2 transition-colors ${
                      selectedType === "favorite"
                        ? "border-primary bg-primary/5"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <Star className={`w-6 h-6 ${selectedType === "favorite" ? "text-primary" : "text-muted-foreground"}`} />
                    <span className="text-sm font-medium">Favorite</span>
                  </button>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <Button
                  variant="outline"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleAddLocation}
                  className="flex-1 bg-primary hover:bg-primary/90"
                >
                  Save Location
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Saved Locations List */}
        <div className="space-y-4">
          {locations.map((location) => {
            const Icon = location.icon;
            return (
              <div
                key={location.id}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="text-lg font-semibold">{location.name}</h3>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                          <MapPin className="w-4 h-4" />
                          <span>{location.address}</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteLocation(location.id)}
                          className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-3">
                      <Button variant="outline" size="sm">
                        <Navigation className="w-4 h-4 mr-2" />
                        Get Directions
                      </Button>
                      <Button variant="outline" size="sm">
                        Find Nearby Deals
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Empty State */}
        {locations.length === 0 && !showAddForm && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Saved Locations</h3>
            <p className="text-muted-foreground mb-6">
              Add your frequently visited locations for quick access to nearby deals
            </p>
            <Button
              onClick={() => setShowAddForm(true)}
              className="bg-primary hover:bg-primary/90"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Location
            </Button>
          </div>
        )}

        {/* Info Box */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
          <p className="text-sm text-blue-900">
            <strong>Tip:</strong> Save your frequently visited locations to quickly
            discover deals near places you visit often. We'll use these locations to
            personalize your deal recommendations.
          </p>
        </div>
      </div>
    </div>
  );
}
