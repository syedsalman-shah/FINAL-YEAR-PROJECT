import { BadgeCheck, Navigation, Eye, Plus } from "lucide-react";

interface RouteStopProps {
  number: number;
  icon: string;
  shopName: string;
  deal: string;
  location?: string;
  walkingTime: string;
  verified?: boolean;
  suggestion?: boolean;
  suggestionNote?: string;
  onGetDirections?: () => void;
  onViewDeal?: () => void;
  onAddToPlan?: () => void;
}

export function RouteStop({
  number,
  icon,
  shopName,
  deal,
  location,
  walkingTime,
  verified = false,
  suggestion = false,
  suggestionNote,
  onGetDirections,
  onViewDeal,
  onAddToPlan,
}: RouteStopProps) {
  return (
    <div className="relative">
      {/* Connector Line */}
      {number > 1 && (
        <div className="absolute left-[18px] -top-4 w-0.5 h-4 bg-primary/30"></div>
      )}
      
      <div className={`bg-white rounded-xl shadow-sm border ${suggestion ? 'border-accent/30 bg-accent/5' : 'border-gray-100'} p-4`}>
        <div className="flex gap-3">
          {/* Number Badge */}
          <div className="flex-shrink-0">
            <div className="w-9 h-9 rounded-full bg-primary text-white flex items-center justify-center font-semibold">
              {number}
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            {/* Shop Name & Emoji */}
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xl">{icon}</span>
              <h4 className="text-sm font-semibold text-foreground">{shopName}</h4>
              {verified && (
                <BadgeCheck className="w-4 h-4 text-primary flex-shrink-0" fill="currentColor" />
              )}
            </div>

            {/* Deal */}
            <p className="text-sm text-primary mb-1">{deal}</p>

            {/* Location */}
            {location && (
              <p className="text-xs text-muted-foreground mb-2">{location}</p>
            )}

            {/* Suggestion Note */}
            {suggestion && suggestionNote && (
              <div className="bg-accent/10 border border-accent/20 rounded-lg p-2 mb-2">
                <p className="text-xs text-accent-foreground">💡 {suggestionNote}</p>
              </div>
            )}

            {/* Walking Time */}
            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-3">
              <span>🚶</span>
              <span>{walkingTime}</span>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              {suggestion ? (
                <button
                  onClick={onAddToPlan}
                  className="flex items-center justify-center gap-1 px-3 py-1.5 bg-accent text-white rounded-lg text-xs hover:bg-accent/90 transition-colors"
                >
                  <Plus className="w-3 h-3" />
                  Add to Plan
                </button>
              ) : (
                <>
                  <button
                    onClick={onGetDirections}
                    className="flex items-center justify-center gap-1 px-3 py-1.5 bg-primary text-white rounded-lg text-xs hover:bg-primary/90 transition-colors flex-1"
                  >
                    <Navigation className="w-3 h-3" />
                    Directions
                  </button>
                  <button
                    onClick={onViewDeal}
                    className="flex items-center justify-center gap-1 px-3 py-1.5 border border-primary text-primary rounded-lg text-xs hover:bg-secondary transition-colors flex-1"
                  >
                    <Eye className="w-3 h-3" />
                    View Deal
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
