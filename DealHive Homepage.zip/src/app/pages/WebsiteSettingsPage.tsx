import { useState } from "react";
import { DesktopHeader } from "../components/desktop-header";
import { Button } from "../components/ui/button";
import { Label } from "../components/ui/label";
import { Switch } from "../components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Separator } from "../components/ui/separator";
import { 
  ArrowLeft,
  Moon,
  Sun,
  Globe,
  Palette,
  Zap,
  Volume2,
  Eye,
  Download,
  Trash2,
  Monitor
} from "lucide-react";
import { useNavigate } from "react-router";

export function WebsiteSettingsPage() {
  const navigate = useNavigate();

  // State for various settings
  const [theme, setTheme] = useState<"light" | "dark" | "system">("light");
  const [language, setLanguage] = useState("en");
  const [fontSize, setFontSize] = useState("medium");
  const [animations, setAnimations] = useState(true);
  const [autoplay, setAutoplay] = useState(true);
  const [soundEffects, setSoundEffects] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [compactMode, setCompactMode] = useState(false);

  const handleClearCache = () => {
    // In a real website, this would clear browser cache
    console.log("Clearing cache...");
    alert("Cache cleared successfully!");
  };

  const handleResetSettings = () => {
    if (confirm("Are you sure you want to reset all settings to default?")) {
      setTheme("light");
      setLanguage("en");
      setFontSize("medium");
      setAnimations(true);
      setAutoplay(true);
      setSoundEffects(false);
      setReducedMotion(false);
      setHighContrast(false);
      setCompactMode(false);
      alert("Settings reset to default!");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <DesktopHeader />

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate("/profile")}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl mb-1">Website Settings</h1>
            <p className="text-muted-foreground">
              Customize your browsing experience
            </p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          {/* Appearance Section */}
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Palette className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="font-semibold text-lg">Appearance</h2>
                <p className="text-sm text-muted-foreground">
                  Customize the look and feel
                </p>
              </div>
            </div>

            <div className="space-y-6">
              {/* Theme */}
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <Label htmlFor="theme" className="text-base font-medium">
                    Theme
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Choose your preferred color scheme
                  </p>
                </div>
                <Select value={theme} onValueChange={(value: any) => setTheme(value)}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">
                      <div className="flex items-center gap-2">
                        <Sun className="w-4 h-4" />
                        Light
                      </div>
                    </SelectItem>
                    <SelectItem value="dark">
                      <div className="flex items-center gap-2">
                        <Moon className="w-4 h-4" />
                        Dark
                      </div>
                    </SelectItem>
                    <SelectItem value="system">
                      <div className="flex items-center gap-2">
                        <Monitor className="w-4 h-4" />
                        System
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Font Size */}
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <Label htmlFor="fontSize" className="text-base font-medium">
                    Font Size
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Adjust text size for better readability
                  </p>
                </div>
                <Select value={fontSize} onValueChange={setFontSize}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Small</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="large">Large</SelectItem>
                    <SelectItem value="xlarge">Extra Large</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Compact Mode */}
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <Label htmlFor="compact" className="text-base font-medium">
                    Compact Mode
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Show more content with reduced spacing
                  </p>
                </div>
                <Switch
                  id="compact"
                  checked={compactMode}
                  onCheckedChange={setCompactMode}
                />
              </div>

              {/* High Contrast */}
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <Label htmlFor="contrast" className="text-base font-medium">
                    High Contrast
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Increase contrast for better visibility
                  </p>
                </div>
                <Switch
                  id="contrast"
                  checked={highContrast}
                  onCheckedChange={setHighContrast}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Language & Region */}
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Globe className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="font-semibold text-lg">Language & Region</h2>
                <p className="text-sm text-muted-foreground">
                  Set your preferred language
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label htmlFor="language" className="text-base font-medium">
                  Display Language
                </Label>
                <p className="text-sm text-muted-foreground mt-1">
                  Choose your preferred language
                </p>
              </div>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="ur">اردو (Urdu)</SelectItem>
                  <SelectItem value="pa">پنجابی (Punjabi)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Separator />

          {/* Performance & Media */}
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="font-semibold text-lg">Performance & Media</h2>
                <p className="text-sm text-muted-foreground">
                  Control animations and media playback
                </p>
              </div>
            </div>

            <div className="space-y-6">
              {/* Animations */}
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <Label htmlFor="animations" className="text-base font-medium">
                    Enable Animations
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Show smooth transitions and effects
                  </p>
                </div>
                <Switch
                  id="animations"
                  checked={animations}
                  onCheckedChange={setAnimations}
                />
              </div>

              {/* Reduced Motion */}
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <Label htmlFor="motion" className="text-base font-medium">
                    Reduce Motion
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Minimize animations for accessibility
                  </p>
                </div>
                <Switch
                  id="motion"
                  checked={reducedMotion}
                  onCheckedChange={setReducedMotion}
                />
              </div>

              {/* Autoplay Videos */}
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <Label htmlFor="autoplay" className="text-base font-medium">
                    Autoplay Videos
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Automatically play videos and media
                  </p>
                </div>
                <Switch
                  id="autoplay"
                  checked={autoplay}
                  onCheckedChange={setAutoplay}
                />
              </div>

              {/* Sound Effects */}
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <Label htmlFor="sound" className="text-base font-medium">
                    Sound Effects
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Play sound effects for interactions
                  </p>
                </div>
                <Switch
                  id="sound"
                  checked={soundEffects}
                  onCheckedChange={setSoundEffects}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Data & Storage */}
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Download className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="font-semibold text-lg">Data & Storage</h2>
                <p className="text-sm text-muted-foreground">
                  Manage cached data and storage
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-secondary rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="font-medium">Cached Data</p>
                    <p className="text-sm text-muted-foreground">
                      Clear temporary files and images
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    onClick={handleClearCache}
                    className="gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    Clear Cache
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Estimated cache size: ~12.5 MB
                </p>
              </div>
            </div>
          </div>

          <Separator />

          {/* Reset Settings */}
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium mb-1">Reset All Settings</h3>
                <p className="text-sm text-muted-foreground">
                  Restore all settings to their default values
                </p>
              </div>
              <Button
                variant="outline"
                onClick={handleResetSettings}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                Reset Settings
              </Button>
            </div>
          </div>
        </div>

        {/* Info Footer */}
        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-900">
            💡 <strong>Tip:</strong> Most settings take effect immediately. Some changes may require refreshing the page.
          </p>
        </div>
      </div>
    </div>
  );
}
