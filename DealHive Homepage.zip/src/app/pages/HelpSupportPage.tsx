import { useState } from "react";
import { DesktopHeader } from "../components/desktop-header";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { 
  ArrowLeft,
  HelpCircle,
  MessageSquare,
  Mail,
  Phone,
  Search,
  Send,
  Book,
  Video,
  FileText,
  ExternalLink,
  CheckCircle2,
  MessageCircle
} from "lucide-react";
import { useNavigate } from "react-router";

export function HelpSupportPage() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [contactName, setContactName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactSubject, setContactSubject] = useState("");
  const [contactMessage, setContactMessage] = useState("");

  const faqs = [
    {
      category: "Getting Started",
      questions: [
        {
          q: "How do I find deals near me?",
          a: "Use the search feature on the home page to find deals by location, category, or business name. You can also use our AI-powered route planner to optimize your shopping trips and discover deals along your route."
        },
        {
          q: "How does the AI route planner work?",
          a: "Our AI route planner analyzes your saved deals and current location to create the most efficient shopping route. It considers factors like distance, deal expiry times, and opening hours to save you time and maximize your savings."
        },
        {
          q: "What are the food categories available?",
          a: "Deal Hive focuses exclusively on food deals across 8 categories: Fast Food, Pizza, Coffee, Sushi, Healthy Food, Desserts, Asian Cuisine, and Desi Food."
        }
      ]
    },
    {
      category: "Deals & Savings",
      questions: [
        {
          q: "How do I save a deal?",
          a: "Click the heart icon on any deal card to save it to your favorites. You can access all your saved deals from the Saved page in the main navigation."
        },
        {
          q: "How long are deals valid?",
          a: "Each deal has its own validity period set by the business. You can see the expiry date and time remaining on each deal card. We recommend claiming deals as soon as possible to avoid missing out."
        },
        {
          q: "Can I share deals with friends?",
          a: "Yes! Each deal has a share button that lets you send it via WhatsApp, social media, or copy the link to share however you like."
        },
        {
          q: "How do I redeem a deal?",
          a: "Visit the business during the deal's valid hours and show the deal page on your device. The business will verify and apply the discount to your order."
        }
      ]
    },
    {
      category: "Business Verification",
      questions: [
        {
          q: "What is the Trust Score?",
          a: "The Trust Score is our AI-powered verification system that rates businesses based on factors like authenticity, deal reliability, customer feedback, and business verification status. Higher scores indicate more trustworthy businesses."
        },
        {
          q: "How can I verify my business?",
          a: "Business owners can verify their business through the 'Verify Your Business' option in the Profile menu. You'll need to provide business documents, contact information, and complete our verification process."
        },
        {
          q: "What are the benefits of business verification?",
          a: "Verified businesses get a verified badge, higher Trust Scores, better visibility in search results, and increased customer trust."
        }
      ]
    },
    {
      category: "Account & Settings",
      questions: [
        {
          q: "How do I edit my profile?",
          a: "Go to Profile > Edit Profile to update your personal information, profile photo, and bio."
        },
        {
          q: "Can I change my notification preferences?",
          a: "Yes, visit Profile > Notifications to customize which notifications you receive and how you receive them (push, email, SMS)."
        },
        {
          q: "How do I manage saved locations?",
          a: "Go to Profile > Saved Locations to add, edit, or remove your favorite addresses like Home, Work, or custom locations."
        },
        {
          q: "Is my data secure?",
          a: "Yes, we take data security seriously. Visit Profile > Privacy & Security to review our security measures and control your privacy settings."
        }
      ]
    },
    {
      category: "Technical Issues",
      questions: [
        {
          q: "The website is running slow. What should I do?",
          a: "Try clearing your browser cache, closing other tabs, or refreshing the page. You can also clear cache from Website Settings > Data & Storage."
        },
        {
          q: "I can't see some images or maps.",
          a: "This could be due to slow internet connection or browser settings. Try refreshing the page or check your internet connection."
        },
        {
          q: "The search isn't working properly.",
          a: "Make sure you've entered valid search terms and selected appropriate filters. If the issue persists, try clearing your browser cache or contact support."
        }
      ]
    }
  ];

  const filteredFaqs = faqs.map(category => ({
    ...category,
    questions: category.questions.filter(
      q => 
        searchQuery === "" ||
        q.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.a.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  const handleSubmitContact = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real website, this would send the contact form
    console.log("Submitting contact form...", {
      name: contactName,
      email: contactEmail,
      subject: contactSubject,
      message: contactMessage
    });
    alert("Thank you for contacting us! We'll get back to you within 24 hours.");
    setContactName("");
    setContactEmail("");
    setContactSubject("");
    setContactMessage("");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <DesktopHeader />

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate("/profile")}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl mb-1">Help & Support</h1>
            <p className="text-muted-foreground">
              Get help and contact our support team
            </p>
          </div>
        </div>

        {/* Quick Contact Cards */}
        <div className="grid grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Mail className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Email Support</h3>
            <p className="text-sm text-muted-foreground mb-3">
              Get help via email
            </p>
            <a href="mailto:support@dealhive.pk" className="text-primary text-sm font-medium hover:underline">
              support@dealhive.pk
            </a>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Phone className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Phone Support</h3>
            <p className="text-sm text-muted-foreground mb-3">
              Call us during business hours
            </p>
            <a href="tel:+92512345678" className="text-primary text-sm font-medium hover:underline">
              +92 51 234 5678
            </a>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <MessageCircle className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">WhatsApp</h3>
            <p className="text-sm text-muted-foreground mb-3">
              Chat with us on WhatsApp
            </p>
            <a href="https://wa.me/923001234567" className="text-primary text-sm font-medium hover:underline">
              +92 300 123 4567
            </a>
          </div>
        </div>

        <Tabs defaultValue="faq" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="faq">
              <Book className="w-4 h-4 mr-2" />
              FAQ
            </TabsTrigger>
            <TabsTrigger value="contact">
              <MessageSquare className="w-4 h-4 mr-2" />
              Contact Us
            </TabsTrigger>
            <TabsTrigger value="resources">
              <Video className="w-4 h-4 mr-2" />
              Resources
            </TabsTrigger>
          </TabsList>

          {/* FAQ Tab */}
          <TabsContent value="faq">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              {/* Search */}
              <div className="mb-8">
                <Label htmlFor="search" className="text-lg font-semibold mb-3 block">
                  Search for answers
                </Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                  <Input
                    id="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                    placeholder="Search FAQs..."
                  />
                </div>
              </div>

              {/* FAQs */}
              {filteredFaqs.length > 0 ? (
                <div className="space-y-6">
                  {filteredFaqs.map((category, idx) => (
                    <div key={idx}>
                      <h3 className="font-semibold text-lg mb-4 text-primary">
                        {category.category}
                      </h3>
                      <Accordion type="single" collapsible className="space-y-2">
                        {category.questions.map((faq, faqIdx) => (
                          <AccordionItem
                            key={faqIdx}
                            value={`${idx}-${faqIdx}`}
                            className="border border-gray-200 rounded-lg px-4"
                          >
                            <AccordionTrigger className="text-left hover:no-underline">
                              <div className="flex items-start gap-3">
                                <HelpCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                                <span className="font-medium">{faq.q}</span>
                              </div>
                            </AccordionTrigger>
                            <AccordionContent className="text-muted-foreground pl-8">
                              {faq.a}
                            </AccordionContent>
                          </AccordionItem>
                        ))}
                      </Accordion>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    No results found for "{searchQuery}"
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Try different keywords or contact support
                  </p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Contact Tab */}
          <TabsContent value="contact">
            <div className="grid grid-cols-2 gap-6">
              {/* Contact Form */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h2 className="text-xl font-semibold mb-4">Send us a message</h2>
                <p className="text-sm text-muted-foreground mb-6">
                  Fill out the form below and we'll get back to you within 24 hours
                </p>

                <form onSubmit={handleSubmitContact} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Your Name</Label>
                    <Input
                      id="name"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      placeholder="Ahmed Khan"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      placeholder="your.email@example.com"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input
                      id="subject"
                      value={contactSubject}
                      onChange={(e) => setContactSubject(e.target.value)}
                      placeholder="How can we help you?"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      value={contactMessage}
                      onChange={(e) => setContactMessage(e.target.value)}
                      placeholder="Describe your issue or question..."
                      rows={6}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                    <Send className="w-4 h-4 mr-2" />
                    Send Message
                  </Button>
                </form>
              </div>

              {/* Contact Info & Hours */}
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h3 className="font-semibold mb-4">Support Hours</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Monday - Friday</span>
                      <span className="text-sm font-medium">9:00 AM - 6:00 PM</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Saturday</span>
                      <span className="text-sm font-medium">10:00 AM - 4:00 PM</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Sunday</span>
                      <span className="text-sm font-medium">Closed</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-4">
                    * All times are in Pakistan Standard Time (PKT)
                  </p>
                </div>

                <div className="bg-primary/5 border border-primary/20 rounded-xl p-6">
                  <CheckCircle2 className="w-10 h-10 text-primary mb-3" />
                  <h3 className="font-semibold mb-2">Average Response Time</h3>
                  <p className="text-sm text-muted-foreground">
                    We typically respond to all inquiries within 24 hours during business days
                  </p>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h3 className="font-semibold mb-3">Visit Our Office</h3>
                  <p className="text-sm text-muted-foreground mb-2">
                    Blue Area, Islamabad
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Islamabad Capital Territory, Pakistan
                  </p>
                  <a 
                    href="https://maps.google.com/?q=Islamabad+Blue+Area" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <Button variant="outline" className="w-full mt-4 gap-2">
                      <ExternalLink className="w-4 h-4" />
                      View on Maps
                    </Button>
                  </a>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Resources Tab */}
          <TabsContent value="resources">
            <div className="grid grid-cols-2 gap-6">
              {/* Video Tutorials */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Video className="w-5 h-5 text-primary" />
                  </div>
                  <h2 className="text-xl font-semibold">Video Tutorials</h2>
                </div>
                <p className="text-sm text-muted-foreground mb-6">
                  Watch step-by-step guides to get the most out of Deal Hive
                </p>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-start gap-3">
                    <div className="w-8 h-8 bg-red-100 rounded flex items-center justify-center">
                      <Video className="w-4 h-4 text-red-600" />
                    </div>
                    <div className="text-left flex-1">
                      <p className="font-medium text-sm">Getting Started with Deal Hive</p>
                      <p className="text-xs text-muted-foreground">5 min tutorial</p>
                    </div>
                  </Button>
                  <Button variant="outline" className="w-full justify-start gap-3">
                    <div className="w-8 h-8 bg-red-100 rounded flex items-center justify-center">
                      <Video className="w-4 h-4 text-red-600" />
                    </div>
                    <div className="text-left flex-1">
                      <p className="font-medium text-sm">Using the AI Route Planner</p>
                      <p className="text-xs text-muted-foreground">8 min tutorial</p>
                    </div>
                  </Button>
                  <Button variant="outline" className="w-full justify-start gap-3">
                    <div className="w-8 h-8 bg-red-100 rounded flex items-center justify-center">
                      <Video className="w-4 h-4 text-red-600" />
                    </div>
                    <div className="text-left flex-1">
                      <p className="font-medium text-sm">Business Verification Guide</p>
                      <p className="text-xs text-muted-foreground">12 min tutorial</p>
                    </div>
                  </Button>
                </div>
              </div>

              {/* Documentation */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <FileText className="w-5 h-5 text-primary" />
                  </div>
                  <h2 className="text-xl font-semibold">Documentation</h2>
                </div>
                <p className="text-sm text-muted-foreground mb-6">
                  Read detailed guides and documentation
                </p>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-between">
                    User Guide
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" className="w-full justify-between">
                    Business Owner Guide
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" className="w-full justify-between">
                    Privacy Policy
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" className="w-full justify-between">
                    Terms of Service
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Community */}
              <div className="bg-gradient-to-br from-primary to-primary/80 rounded-xl shadow-sm p-6 text-white col-span-2">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-xl font-semibold mb-2">Join Our Community</h2>
                    <p className="text-sm opacity-90 mb-4">
                      Connect with other users, share tips, and stay updated with the latest deals
                    </p>
                    <div className="flex gap-3">
                      <Button variant="secondary" size="sm">
                        Facebook Group
                      </Button>
                      <Button variant="secondary" size="sm">
                        WhatsApp Community
                      </Button>
                      <Button variant="secondary" size="sm">
                        Instagram
                      </Button>
                    </div>
                  </div>
                  <MessageSquare className="w-16 h-16 opacity-20" />
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}