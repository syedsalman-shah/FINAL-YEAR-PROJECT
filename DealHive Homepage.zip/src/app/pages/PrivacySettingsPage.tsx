import { useState } from "react";
import { DesktopHeader } from "../components/desktop-header";
import { Button } from "../components/ui/button";
import { Label } from "../components/ui/label";
import { Switch } from "../components/ui/switch";
import {
  ArrowLeft,
  Shield,
  Eye,
  Lock,
  Download,
  Trash2,
  AlertTriangle,
} from "lucide-react";
import { useNavigate } from "react-router";

export function PrivacySettingsPage() {
  const navigate = useNavigate();
  const [profilePublic, setProfilePublic] = useState(true);
  const [showSavedDeals, setShowSavedDeals] = useState(false);
  const [showActivity, setShowActivity] = useState(true);
  const [locationTracking, setLocationTracking] = useState(true);
  const [dataCollection, setDataCollection] = useState(true);
  const [thirdPartySharing, setThirdPartySharing] = useState(false);

  const handleDownloadData = () => {
    console.log("Downloading user data...");
  };

  const handleDeleteAccount = () => {
    console.log("Delete account requested...");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <DesktopHeader />

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate("/profile")}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl mb-1">Privacy & Security</h1>
            <p className="text-muted-foreground">
              Manage your privacy and data settings
            </p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Privacy Settings */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <Eye className="w-5 h-5 text-primary" />
              <h2 className="text-xl">Privacy Settings</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Public Profile</p>
                  <p className="text-sm text-muted-foreground">
                    Make your profile visible to other users
                  </p>
                </div>
                <Switch
                  checked={profilePublic}
                  onCheckedChange={setProfilePublic}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Show Saved Deals</p>
                  <p className="text-sm text-muted-foreground">
                    Let others see your saved deals
                  </p>
                </div>
                <Switch
                  checked={showSavedDeals}
                  onCheckedChange={setShowSavedDeals}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Activity Status</p>
                  <p className="text-sm text-muted-foreground">
                    Show when you're active on the platform
                  </p>
                </div>
                <Switch checked={showActivity} onCheckedChange={setShowActivity} />
              </div>
            </div>
          </div>

          {/* Security Settings */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <Lock className="w-5 h-5 text-primary" />
              <h2 className="text-xl">Security</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="font-medium">Password</p>
                  <p className="text-sm text-muted-foreground">
                    Last changed 3 months ago
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  Change Password
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="font-medium">Two-Factor Authentication</p>
                  <p className="text-sm text-muted-foreground">
                    Add an extra layer of security
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  Enable
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="font-medium">Active Sessions</p>
                  <p className="text-sm text-muted-foreground">
                    Manage devices logged into your account
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  View All
                </Button>
              </div>
            </div>
          </div>

          {/* Data & Location */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-5 h-5 text-primary" />
              <h2 className="text-xl">Data & Location</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Location Tracking</p>
                  <p className="text-sm text-muted-foreground">
                    Allow us to use your location for nearby deals
                  </p>
                </div>
                <Switch
                  checked={locationTracking}
                  onCheckedChange={setLocationTracking}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Analytics & Personalization</p>
                  <p className="text-sm text-muted-foreground">
                    Help us improve your experience with usage data
                  </p>
                </div>
                <Switch
                  checked={dataCollection}
                  onCheckedChange={setDataCollection}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Third-Party Data Sharing</p>
                  <p className="text-sm text-muted-foreground">
                    Share anonymized data with partners
                  </p>
                </div>
                <Switch
                  checked={thirdPartySharing}
                  onCheckedChange={setThirdPartySharing}
                />
              </div>
            </div>
          </div>

          {/* Data Management */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl mb-4">Data Management</h2>

            <div className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={handleDownloadData}
              >
                <Download className="w-4 h-4 mr-2" />
                Download My Data
              </Button>
              <p className="text-xs text-muted-foreground px-4">
                Get a copy of all your data including profile, saved deals, and
                activity history
              </p>
            </div>
          </div>

          {/* Legal Links */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl mb-4">Legal</h2>

            <div className="space-y-3">
              <Button variant="ghost" className="w-full justify-start">
                Privacy Policy
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                Terms of Service
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                Cookie Policy
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                Data Processing Agreement
              </Button>
            </div>
          </div>

          {/* Danger Zone */}
          <div className="bg-red-50 border border-red-200 rounded-xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <h2 className="text-xl text-red-900">Danger Zone</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-red-900">Delete Account</p>
                  <p className="text-sm text-red-700">
                    Permanently delete your account and all associated data
                  </p>
                </div>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleDeleteAccount}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => navigate("/profile")}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={() => navigate("/profile")}
              className="flex-1 bg-primary hover:bg-primary/90"
            >
              Save Settings
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
