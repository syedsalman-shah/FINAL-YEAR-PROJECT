import { useState, useRef, useEffect } from "react";
import { MapPin, ChevronDown, Search, Check, X } from "lucide-react";

interface LocationSelectorProps {
  value?: string;
  onChange?: (location: string) => void;
  className?: string;
}

interface Sector {
  id: string;
  name: string;
}

interface SectorGroup {
  title: string;
  sectors: Sector[];
}

const sectorGroups: SectorGroup[] = [
  {
    title: "F Sectors",
    sectors: [
      { id: "f-5", name: "F-5" },
      { id: "f-6", name: "F-6" },
      { id: "f-7", name: "F-7" },
      { id: "f-8", name: "F-8" },
      { id: "f-9", name: "F-9" },
      { id: "f-10", name: "F-10" },
      { id: "f-11", name: "F-11" },
    ],
  },
  {
    title: "G Sectors",
    sectors: [
      { id: "g-5", name: "G-5" },
      { id: "g-6", name: "G-6" },
      { id: "g-7", name: "G-7" },
      { id: "g-8", name: "G-8" },
      { id: "g-9", name: "G-9" },
      { id: "g-10", name: "G-10" },
      { id: "g-11", name: "G-11" },
      { id: "g-12", name: "G-12" },
      { id: "g-13", name: "G-13" },
      { id: "g-14", name: "G-14" },
      { id: "g-15", name: "G-15" },
      { id: "g-16", name: "G-16" },
    ],
  },
  {
    title: "H Sectors",
    sectors: [
      { id: "h-8", name: "H-8" },
      { id: "h-9", name: "H-9" },
      { id: "h-10", name: "H-10" },
      { id: "h-11", name: "H-11" },
      { id: "h-12", name: "H-12" },
      { id: "h-13", name: "H-13" },
    ],
  },
  {
    title: "I Sectors",
    sectors: [
      { id: "i-8", name: "I-8" },
      { id: "i-9", name: "I-9" },
      { id: "i-10", name: "I-10" },
      { id: "i-11", name: "I-11" },
      { id: "i-12", name: "I-12" },
      { id: "i-13", name: "I-13" },
      { id: "i-14", name: "I-14" },
      { id: "i-15", name: "I-15" },
      { id: "i-16", name: "I-16" },
      { id: "i-17", name: "I-17" },
    ],
  },
  {
    title: "E Sectors",
    sectors: [
      { id: "e-7", name: "E-7" },
      { id: "e-8", name: "E-8" },
      { id: "e-9", name: "E-9" },
      { id: "e-10", name: "E-10" },
      { id: "e-11", name: "E-11" },
    ],
  },
  {
    title: "D Sectors",
    sectors: [
      { id: "d-12", name: "D-12" },
      { id: "d-13", name: "D-13" },
      { id: "d-14", name: "D-14" },
      { id: "d-15", name: "D-15" },
      { id: "d-16", name: "D-16" },
      { id: "d-17", name: "D-17" },
    ],
  },
  {
    title: "B & C Sectors",
    sectors: [
      { id: "b-17", name: "B-17" },
      { id: "b-18", name: "B-18" },
      { id: "c-14", name: "C-14" },
      { id: "c-15", name: "C-15" },
      { id: "c-16", name: "C-16" },
      { id: "c-17", name: "C-17" },
      { id: "c-18", name: "C-18" },
    ],
  },
];

const popularAreas: Sector[] = [
  { id: "dha", name: "DHA Islamabad" },
  { id: "bahria", name: "Bahria Town" },
  { id: "gulberg", name: "Gulberg Greens" },
  { id: "naval", name: "Naval Anchorage" },
  { id: "parkview", name: "Park View City" },
];

export function LocationSelector({ 
  value = "Islamabad", 
  onChange,
  className = ""
}: LocationSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLocation, setSelectedLocation] = useState(value);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen]);

  const handleSelect = (location: string) => {
    setSelectedLocation(location);
    onChange?.(location);
    setIsOpen(false);
    setSearchQuery("");
  };

  const handleReset = () => {
    setSelectedLocation("Islamabad");
    onChange?.("Islamabad");
    setSearchQuery("");
  };

  // Filter sectors based on search query
  const filteredGroups = sectorGroups
    .map((group) => ({
      ...group,
      sectors: group.sectors.filter((sector) =>
        sector.name.toLowerCase().includes(searchQuery.toLowerCase())
      ),
    }))
    .filter((group) => group.sectors.length > 0);

  const filteredPopularAreas = popularAreas.filter((area) =>
    area.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const hasResults = filteredGroups.length > 0 || filteredPopularAreas.length > 0;

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 sm:px-4 py-2 sm:py-2.5 bg-secondary rounded-lg sm:rounded-xl hover:bg-secondary/80 active:bg-secondary/70 transition-colors w-full sm:w-auto"
      >
        <MapPin className="w-4 h-4 sm:w-5 sm:h-5 text-primary flex-shrink-0" />
        <span className="text-xs sm:text-sm font-medium text-foreground truncate max-w-[120px] sm:max-w-none">
          {selectedLocation}
        </span>
        <ChevronDown
          className={`w-4 h-4 text-muted-foreground flex-shrink-0 transition-transform ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>

      {/* Dropdown Panel */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 sm:left-auto sm:right-auto sm:min-w-[380px] mt-2 bg-white rounded-2xl shadow-2xl border border-gray-200 z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
          {/* Search Bar */}
          <div className="p-4 border-b border-gray-200 bg-gray-50/50">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search sectors or areas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-10 py-2.5 bg-white rounded-xl text-sm text-foreground placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-primary/20 border border-gray-200 transition-all"
                autoFocus
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-200 rounded-full transition-colors"
                >
                  <X className="w-3 h-3 text-gray-500" />
                </button>
              )}
            </div>
          </div>

          {/* Scrollable Content */}
          <div className="max-h-[60vh] sm:max-h-[400px] overflow-y-auto overscroll-contain">
            {hasResults ? (
              <div className="p-3">
                {/* All Islamabad Option */}
                {!searchQuery && (
                  <div className="mb-3">
                    <button
                      onClick={() => handleSelect("Islamabad")}
                      className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                        selectedLocation === "Islamabad"
                          ? "bg-primary text-white"
                          : "hover:bg-gray-50 active:bg-gray-100 text-foreground"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <MapPin className="w-5 h-5" />
                        <span className="font-semibold">All Islamabad</span>
                      </div>
                      {selectedLocation === "Islamabad" && (
                        <Check className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                )}

                {/* Sector Groups */}
                {filteredGroups.map((group, groupIndex) => (
                  <div key={groupIndex} className="mb-4 last:mb-2">
                    <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-4 py-2">
                      {group.title}
                    </h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {group.sectors.map((sector) => (
                        <button
                          key={sector.id}
                          onClick={() => handleSelect(sector.name)}
                          className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                            selectedLocation === sector.name
                              ? "bg-primary text-white shadow-sm"
                              : "bg-gray-50 hover:bg-gray-100 active:bg-gray-200 text-foreground"
                          }`}
                        >
                          <span>{sector.name}</span>
                          {selectedLocation === sector.name && (
                            <Check className="w-4 h-4" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}

                {/* Popular Areas */}
                {filteredPopularAreas.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-4 py-2">
                      Popular Areas
                    </h3>
                    <div className="space-y-1">
                      {filteredPopularAreas.map((area) => (
                        <button
                          key={area.id}
                          onClick={() => handleSelect(area.name)}
                          className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                            selectedLocation === area.name
                              ? "bg-primary text-white"
                              : "hover:bg-gray-50 active:bg-gray-100 text-foreground"
                          }`}
                        >
                          <span>{area.name}</span>
                          {selectedLocation === area.name && (
                            <Check className="w-4 h-4" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 text-center">
                <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">
                  No locations found for "{searchQuery}"
                </p>
              </div>
            )}
          </div>

          {/* Footer */}
          {selectedLocation !== "Islamabad" && !searchQuery && (
            <div className="p-3 border-t border-gray-200 bg-gray-50">
              <button
                onClick={handleReset}
                className="w-full px-4 py-2.5 text-sm font-medium text-primary hover:bg-primary/10 rounded-xl transition-colors"
              >
                Reset to All Islamabad
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}