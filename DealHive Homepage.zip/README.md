
  # DealHive Homepage

  This is a code bundle for DealHive Homepage. The original project is available at https://www.figma.com/design/0sQtBpBfQYAKWi4sSJ8N9o/DealHive-Homepage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  