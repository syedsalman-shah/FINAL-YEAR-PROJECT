import { ArrowLeft, MapPin, BadgeCheck, Info, Star, AlertCircle, Flag, Calendar, FileText, ChevronRight, Phone, Clock, Globe } from "lucide-react";
import { TrustMeter } from "./trust-meter";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { DesktopHeader } from "./desktop-header";

interface BusinessProfileProps {
  onBack?: () => void;
}

export function BusinessProfile({ onBack }: BusinessProfileProps) {
  const trustFactors = [
    { icon: "✅", label: "Instagram account age: 3+ years", status: "verified" },
    { icon: "✅", label: "Phone number verified", status: "verified" },
    { icon: "✅", label: "Website present", status: "verified" },
    { icon: "✅", label: "Consistent posting history", status: "verified" },
    { icon: "✅", label: "No duplicate deals detected", status: "verified" },
    { icon: "✅", label: "5 user reports (resolved)", status: "verified" },
    { icon: "🟡", label: "Limited reviews (new business)", status: "warning" },
  ];

  const activeDeals = [
    {
      description: "Buy 1 Get 1 Free on All Burgers",
      validity: "Valid until March 15, 2026",
      terms: "Dine-in only. Not valid with other offers.",
      discount: "50% OFF",
    },
    {
      description: "20% Off on Family Meal Combo",
      validity: "Valid until March 20, 2026",
      terms: "Minimum order Rs. 2000. Takeaway & delivery.",
      discount: "20% OFF",
    },
    {
      description: "Free Drink with Every Pizza Order",
      validity: "Valid until March 31, 2026",
      terms: "All pizza sizes. Dine-in & takeaway.",
      discount: "FREE ITEM",
    },
  ];

  const reviews = [
    {
      name: "Ahmed Khan",
      rating: 5,
      date: "2 days ago",
      comment: "Great food and excellent service! The BOGO burger deal was amazing. Highly recommend!",
      verified: true,
    },
    {
      name: "Sara Ali",
      rating: 4,
      date: "1 week ago",
      comment: "Good quality food. Slightly crowded during peak hours but worth the wait.",
      verified: true,
    },
    {
      name: "Hassan Raza",
      rating: 5,
      date: "2 weeks ago",
      comment: "Authentic taste and reasonable prices. The family meal combo is a great deal!",
      verified: false,
    },
  ];

  const businessHours = [
    { day: "Monday - Friday", hours: "11:00 AM - 11:00 PM" },
    { day: "Saturday - Sunday", hours: "10:00 AM - 12:00 AM" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <DesktopHeader />

      {/* Cover Image */}
      <div className="relative h-80 bg-gradient-to-br from-primary/20 to-primary/40 overflow-hidden">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1600"
          alt="Restaurant cover"
          className="w-full h-full object-cover opacity-60"
        />
        
        {/* Back Button */}
        <button 
          onClick={onBack}
          className="absolute top-8 left-8 p-3 bg-white/90 backdrop-blur-sm rounded-full shadow-md hover:bg-white transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-foreground" />
        </button>
      </div>

      <div className="max-w-7xl mx-auto px-6 -mt-20 pb-12">
        <div className="grid grid-cols-3 gap-8">
          {/* Left Column - Business Info & Trust Score */}
          <div className="col-span-1">
            {/* Business Logo */}
            <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
              <div className="flex flex-col items-center text-center mb-6">
                <div className="w-32 h-32 bg-white rounded-2xl shadow-lg border-4 border-white overflow-hidden mb-4">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1562259949-e8e7689d7828?w=400"
                    alt="Cafe logo"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h1 className="text-3xl font-bold text-foreground mb-2">Cafe Islamabad</h1>
                <p className="text-sm text-muted-foreground mb-3">Restaurant • Fast Food</p>
                <div className="flex items-center justify-center gap-1 text-sm text-muted-foreground mb-4">
                  <MapPin className="w-4 h-4" />
                  <span>F-7 Markaz, Islamabad (0.8 km away)</span>
                </div>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className="w-5 h-5"
                        fill="#ff9800"
                        stroke="#ff9800"
                        strokeWidth={2}
                      />
                    ))}
                  </div>
                  <span className="font-semibold">4.8</span>
                  <span className="text-sm text-muted-foreground">(124 reviews)</span>
                </div>

                {/* Contact Buttons */}
                <div className="flex gap-2 w-full">
                  <button className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">
                    <Phone className="w-4 h-4" />
                    <span className="text-sm font-semibold">Call</span>
                  </button>
                  <button className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-secondary text-primary rounded-lg hover:bg-secondary/80 transition-colors">
                    <Globe className="w-4 h-4" />
                    <span className="text-sm font-semibold">Website</span>
                  </button>
                </div>
              </div>

              {/* Business Hours */}
              <div className="border-t border-gray-200 pt-4">
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="w-5 h-5 text-primary" />
                  <h3 className="font-semibold text-foreground">Business Hours</h3>
                </div>
                <div className="space-y-2">
                  {businessHours.map((schedule, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{schedule.day}</span>
                      <span className="font-medium text-foreground">{schedule.hours}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Trust Score */}
            <div className="bg-gradient-to-br from-primary to-primary/80 text-white rounded-2xl p-6 shadow-lg sticky top-24">
              <div className="flex flex-col items-center text-center">
                <TrustMeter score={92} size={160} />
                <div className="mt-4">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <h3 className="text-xl font-semibold">Trust Score</h3>
                    <Info className="w-5 h-5 text-white/80" />
                  </div>
                  <div className="flex items-center justify-center gap-2 bg-white/20 rounded-full px-4 py-2 mb-2">
                    <BadgeCheck className="w-5 h-5" fill="currentColor" />
                    <span className="font-semibold">Verified Business</span>
                  </div>
                  <p className="text-sm text-white/90">Highly trusted based on AI verification</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Deals, Trust Factors, Reviews */}
          <div className="col-span-2 space-y-6">
            {/* Active Deals */}
            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Active Deals (3)</h2>
              <div className="grid grid-cols-1 gap-4">
                {activeDeals.map((deal, index) => (
                  <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <div className="flex items-start justify-between mb-3">
                      <h4 className="text-lg font-semibold text-foreground flex-1">{deal.description}</h4>
                      <span className="text-sm font-semibold text-accent bg-accent/10 px-3 py-1 rounded-md ml-3">
                        {deal.discount}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                      <Calendar className="w-4 h-4" />
                      <span>{deal.validity}</span>
                    </div>
                    <div className="flex items-start gap-2 text-sm text-muted-foreground mb-4">
                      <FileText className="w-4 h-4 mt-0.5 flex-shrink-0" />
                      <span>{deal.terms}</span>
                    </div>
                    <button className="w-full bg-primary text-white py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors">
                      Get Deal
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Trust Factors */}
            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <BadgeCheck className="w-6 h-6 text-primary" />
                Trust Factors
              </h2>
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <div className="grid grid-cols-2 gap-3">
                  {trustFactors.map((factor, index) => (
                    <div
                      key={index}
                      className={`flex items-start gap-3 p-3 rounded-lg ${
                        factor.status === "warning" ? "bg-yellow-50 border border-yellow-200" : "bg-secondary/50 border border-primary/10"
                      }`}
                    >
                      <span className="text-xl flex-shrink-0">{factor.icon}</span>
                      <span className="text-sm text-foreground flex-1">{factor.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* User Reviews */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-semibold text-foreground">Recent Reviews</h2>
                <button className="text-sm text-primary hover:underline flex items-center gap-1">
                  View All Reviews
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-4">
                {reviews.map((review, index) => (
                  <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold text-foreground">{review.name}</h4>
                          {review.verified && (
                            <BadgeCheck className="w-5 h-5 text-primary" fill="currentColor" />
                          )}
                        </div>
                        <div className="flex items-center gap-3 mb-3">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className="w-4 h-4"
                                fill={i < review.rating ? "#ff9800" : "none"}
                                stroke={i < review.rating ? "#ff9800" : "#d1d5db"}
                                strokeWidth={2}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-muted-foreground">{review.date}</span>
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-foreground mb-3">{review.comment}</p>
                    <button className="flex items-center gap-2 text-sm text-red-500 hover:underline">
                      <Flag className="w-4 h-4" />
                      Report Fake Review
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Report Business */}
            <div className="text-center pt-4">
              <button className="flex items-center justify-center gap-2 px-4 py-2 text-sm text-muted-foreground hover:text-red-500 transition-colors">
                <AlertCircle className="w-4 h-4" />
                Report this Business
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
