import { useState } from "react";
import { DesktopHeader } from "../components/desktop-header";
import { Button } from "../components/ui/button";
import { Progress } from "../components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { 
  Trophy, 
  Award, 
  Star, 
  TrendingUp, 
  ShoppingBag, 
  MapPin, 
  Calendar, 
  Target,
  ArrowLeft,
  Lock,
  CheckCircle2
} from "lucide-react";
import { useNavigate } from "react-router";

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: typeof Trophy;
  progress: number;
  total: number;
  unlocked: boolean;
  unlockedDate?: string;
  reward?: string;
  category: "savings" | "exploration" | "social" | "special";
}

function AchievementCard({ achievement }: { achievement: Achievement }) {
  const Icon = achievement.icon;
  const progressPercentage = Math.min(
    (achievement.progress / achievement.total) * 100,
    100
  );

  return (
    <div
      className={`bg-white rounded-xl shadow-sm border p-6 transition-all ${
        achievement.unlocked
          ? "border-primary/30 bg-primary/5"
          : "border-gray-200"
      }`}
    >
      <div className="flex items-start gap-4">
        <div
          className={`w-16 h-16 rounded-full flex items-center justify-center flex-shrink-0 ${
            achievement.unlocked
              ? "bg-primary text-white"
              : "bg-gray-100 text-gray-400"
          }`}
        >
          {achievement.unlocked ? (
            <Icon className="w-8 h-8" />
          ) : (
            <Lock className="w-8 h-8" />
          )}
        </div>

        <div className="flex-1">
          <div className="flex items-start justify-between mb-2">
            <div>
              <h3 className="font-semibold text-lg mb-1">
                {achievement.title}
              </h3>
              <p className="text-sm text-muted-foreground">
                {achievement.description}
              </p>
            </div>
            {achievement.unlocked && (
              <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0 ml-2" />
            )}
          </div>

          {achievement.unlocked ? (
            <div className="mt-4 p-3 bg-white rounded-lg border border-primary/20">
              <p className="text-sm text-primary font-medium mb-1">
                🎉 Unlocked on {achievement.unlockedDate}
              </p>
              {achievement.reward && (
                <p className="text-xs text-muted-foreground">
                  Reward: {achievement.reward}
                </p>
              )}
            </div>
          ) : (
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">
                  Progress
                </span>
                <span className="text-sm font-medium">
                  {achievement.progress.toLocaleString()} /{" "}
                  {achievement.total.toLocaleString()}
                </span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
              <p className="text-xs text-right text-muted-foreground mt-1">
                {Math.round(progressPercentage)}% Complete
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function AchievementsPage() {
  const navigate = useNavigate();

  const achievements: Achievement[] = [
    {
      id: "saver-bronze",
      title: "Smart Saver",
      description: "Save ₨1,000 through deals",
      icon: Trophy,
      progress: 8450,
      total: 1000,
      unlocked: true,
      unlockedDate: "March 10, 2026",
      reward: "Bronze Badge",
      category: "savings"
    },
    {
      id: "saver-silver",
      title: "Deal Master",
      description: "Save ₨5,000 through deals",
      icon: Trophy,
      progress: 8450,
      total: 5000,
      unlocked: true,
      unlockedDate: "March 15, 2026",
      reward: "Silver Badge",
      category: "savings"
    },
    {
      id: "saver-gold",
      title: "Savings Champion",
      description: "Save ₨10,000 through deals",
      icon: Trophy,
      progress: 8450,
      total: 10000,
      unlocked: false,
      category: "savings"
    },
    {
      id: "saver-platinum",
      title: "Ultimate Bargain Hunter",
      description: "Save ₨25,000 through deals",
      icon: Trophy,
      progress: 8450,
      total: 25000,
      unlocked: false,
      category: "savings"
    },
    {
      id: "explorer-newbie",
      title: "First Steps",
      description: "Visit 5 different businesses",
      icon: MapPin,
      progress: 12,
      total: 5,
      unlocked: true,
      unlockedDate: "March 8, 2026",
      reward: "Explorer Badge",
      category: "exploration"
    },
    {
      id: "explorer-intermediate",
      title: "City Explorer",
      description: "Visit 20 different businesses",
      icon: MapPin,
      progress: 12,
      total: 20,
      unlocked: false,
      category: "exploration"
    },
    {
      id: "route-planner",
      title: "Route Master",
      description: "Complete 10 AI-planned shopping routes",
      icon: Target,
      progress: 5,
      total: 10,
      unlocked: false,
      category: "exploration"
    },
    {
      id: "deal-collector",
      title: "Deal Collector",
      description: "Save 50 deals to favorites",
      icon: ShoppingBag,
      progress: 12,
      total: 50,
      unlocked: false,
      category: "social"
    },
    {
      id: "early-bird",
      title: "Early Bird",
      description: "Claim a deal within 1 hour of posting",
      icon: Calendar,
      progress: 0,
      total: 1,
      unlocked: false,
      category: "social"
    },
    {
      id: "beta-tester",
      title: "Beta Tester",
      description: "Join Deal Hive during beta period",
      icon: Star,
      progress: 1,
      total: 1,
      unlocked: true,
      unlockedDate: "March 1, 2026",
      reward: "Exclusive Beta Badge",
      category: "special"
    },
    {
      id: "food-explorer",
      title: "Food Explorer",
      description: "Try deals from all 8 food categories",
      icon: Award,
      progress: 6,
      total: 8,
      unlocked: false,
      category: "special"
    },
  ];

  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const totalAchievements = achievements.length;
  const totalSavings = 8450;

  return (
    <div className="min-h-screen bg-gray-50">
      <DesktopHeader />

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" onClick={() => navigate("/profile")} className="p-2">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl mb-1">Achievements</h1>
            <p className="text-muted-foreground">Track your savings and milestones</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-8">
          <div className="col-span-1 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Overall Progress</h3>
                  <p className="text-sm text-muted-foreground">
                    {unlockedCount} of {totalAchievements} unlocked
                  </p>
                </div>
              </div>
              <Progress value={(unlockedCount / totalAchievements) * 100} className="h-2 mb-2" />
              <p className="text-xs text-right text-muted-foreground">
                {Math.round((unlockedCount / totalAchievements) * 100)}% Complete
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="font-semibold mb-4">Your Stats</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-accent" />
                    <span className="text-sm">Total Saved</span>
                  </div>
                  <span className="font-bold text-accent">₨{totalSavings.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-primary" />
                    <span className="text-sm">Businesses Visited</span>
                  </div>
                  <span className="font-bold text-primary">12</span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-primary to-primary/80 rounded-xl shadow-sm p-6 text-white">
              <Award className="w-10 h-10 mb-3 opacity-90" />
              <h3 className="font-semibold mb-2">Keep Going!</h3>
              <p className="text-sm opacity-90">
                You're just ₨{(10000 - totalSavings).toLocaleString()} away from becoming a Savings Champion!
              </p>
            </div>
          </div>

          <div className="col-span-2">
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="savings">Savings</TabsTrigger>
                <TabsTrigger value="exploration">Exploration</TabsTrigger>
                <TabsTrigger value="social">Social</TabsTrigger>
                <TabsTrigger value="special">Special</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="space-y-4">
                {achievements.map((achievement) => (
                  <AchievementCard key={achievement.id} achievement={achievement} />
                ))}
              </TabsContent>

              <TabsContent value="savings" className="space-y-4">
                {achievements.filter(a => a.category === "savings").map((achievement) => (
                  <AchievementCard key={achievement.id} achievement={achievement} />
                ))}
              </TabsContent>

              <TabsContent value="exploration" className="space-y-4">
                {achievements.filter(a => a.category === "exploration").map((achievement) => (
                  <AchievementCard key={achievement.id} achievement={achievement} />
                ))}
              </TabsContent>

              <TabsContent value="social" className="space-y-4">
                {achievements.filter(a => a.category === "social").map((achievement) => (
                  <AchievementCard key={achievement.id} achievement={achievement} />
                ))}
              </TabsContent>

              <TabsContent value="special" className="space-y-4">
                {achievements.filter(a => a.category === "special").map((achievement) => (
                  <AchievementCard key={achievement.id} achievement={achievement} />
                ))}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
