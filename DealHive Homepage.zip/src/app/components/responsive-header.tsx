import { MobileHeader } from "./mobile-header";
import { DesktopHeader } from "./desktop-header";

interface ResponsiveHeaderProps {
  title?: string;
  showBack?: boolean;
  showSearch?: boolean;
  showNotifications?: boolean;
  showMenu?: boolean;
  onSearchClick?: () => void;
}

export function ResponsiveHeader(props: ResponsiveHeaderProps) {
  return (
    <>
      {/* Mobile Header - hidden on lg and up */}
      <div className="lg:hidden">
        <MobileHeader {...props} />
      </div>
      
      {/* Desktop Header - hidden on mobile */}
      <div className="hidden lg:block">
        <DesktopHeader />
      </div>
    </>
  );
}
