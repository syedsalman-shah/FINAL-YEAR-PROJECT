import { MapPin, BadgeCheck, Bookmark, CalendarPlus } from "lucide-react";
import { useNavigate } from "react-router";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Deal } from "../data/mockDeals";
import { useApp } from "../context/AppContext";

export function DealCard(props: Deal) {
  const navigate = useNavigate();
  const { isSaved, toggleSaveDeal, isInPlan, addToPlan, removeFromPlan } = useApp();
  
  const discountPercent = props.originalPrice && props.dealPrice
    ? Math.round(((props.originalPrice - props.dealPrice) / props.originalPrice) * 100)
    : 0;

  const saved = isSaved(props.id);
  const inPlan = isInPlan(props.id);

  const handleClick = () => {
    navigate(`/deal/${props.id}`);
  };

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleSaveDeal(props);
  };

  const handlePlan = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (inPlan) {
      removeFromPlan(props.id);
    } else {
      addToPlan(props);
    }
  };

  return (
    <div
      className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden w-full hover:shadow-lg active:shadow-md transition-all relative"
    >
      <div className="relative h-40 sm:h-44 lg:h-32 overflow-hidden cursor-pointer" onClick={handleClick}>
        <ImageWithFallback
          src={props.dealImage}
          alt={props.businessName}
          className="w-full h-full object-cover"
        />
        {/* Discount Badge */}
        <div className="absolute top-3 right-3 bg-accent text-white px-3 py-1.5 rounded-lg text-xs sm:text-sm font-bold shadow-lg">
          {discountPercent}% OFF
        </div>
        {/* Action Buttons */}
        <div className="absolute top-3 left-3 flex gap-2">
          <button
            onClick={handleSave}
            className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
              saved
                ? "bg-accent text-white"
                : "bg-white/90 hover:bg-white text-gray-700"
            }`}
          >
            <Bookmark className={`w-4 h-4 ${saved ? "fill-current" : ""}`} />
          </button>
          <button
            onClick={handlePlan}
            className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
              inPlan
                ? "bg-primary text-white"
                : "bg-white/90 hover:bg-white text-gray-700"
            }`}
          >
            <CalendarPlus className={`w-4 h-4 ${inPlan ? "fill-current" : ""}`} />
          </button>
        </div>
      </div>
      <div className="p-3 sm:p-4">
        <div className="flex items-center gap-1.5 mb-1.5">
          <h4 className="text-sm sm:text-base font-semibold text-foreground line-clamp-1 flex-1">
            {props.businessName}
          </h4>
          {props.verified && (
            <BadgeCheck className="w-4 h-4 sm:w-5 sm:h-5 text-primary flex-shrink-0" fill="currentColor" />
          )}
        </div>
        <p className="text-xs sm:text-sm text-muted-foreground mb-3 line-clamp-2">
          {props.description}
        </p>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm text-muted-foreground line-through">
              ₨{props.originalPrice}
            </span>
            <span className="text-base sm:text-lg font-bold text-primary">
              ₨{props.dealPrice}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1 text-xs sm:text-sm text-muted-foreground">
          <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          <span>{props.distance}</span>
        </div>
      </div>
    </div>
  );
}