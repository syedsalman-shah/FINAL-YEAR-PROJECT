interface CategoryCardProps {
  icon: string;
  label: string;
  onClick?: () => void;
}

export function CategoryCard({ icon, label, onClick }: CategoryCardProps) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center justify-center bg-white rounded-2xl p-3 sm:p-4 min-h-[80px] sm:min-h-[90px] transition-all hover:bg-primary/10 active:bg-primary/20 active:scale-95 shadow-sm border border-gray-100 hover:border-primary/30 hover:shadow-md"
    >
      <span className="text-2xl sm:text-3xl mb-1.5 sm:mb-2">{icon}</span>
      <span className="text-[10px] sm:text-xs font-medium text-foreground text-center leading-tight">
        {label}
      </span>
    </button>
  );
}