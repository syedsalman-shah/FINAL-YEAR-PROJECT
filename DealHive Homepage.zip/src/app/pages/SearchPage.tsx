import { Search, X, TrendingUp, Clock, MapPin, Filter, SlidersHorizontal } from "lucide-react";
import { useState, useEffect } from "react";
import { DealCard } from "../components/deal-card";
import { DealListItem } from "../components/deal-list-item";
import { ResponsiveHeader } from "../components/responsive-header";
import { BottomNav } from "../components/bottom-nav";
import { LocationSelector } from "../components/location-selector";
import { useNavigate } from "react-router";
import { getAllDeals } from "../data/mockDeals";
import { useApp } from "../context/AppContext";

type ViewMode = "grid" | "list";
type SortOption = "relevance" | "discount" | "price" | "distance" | "rating";
type CategoryFilter = "all" | "fast-food" | "pizza" | "coffee" | "sushi" | "healthy" | "desserts" | "asian" | "desi";

export function SearchPage() {
  const navigate = useNavigate();
  const { 
    searchQuery, 
    setSearchQuery,
    searchHistory,
    addToSearchHistory,
    clearSearchHistory,
    selectedLocation,
    setSelectedLocation
  } = useApp();
  
  const [localQuery, setLocalQuery] = useState(searchQuery);
  const [viewMode, setViewMode] = useState<ViewMode>("list");
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>("relevance");
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>("all");
  const [showVerifiedOnly, setShowVerifiedOnly] = useState(false);
  const [minDiscount, setMinDiscount] = useState(0);

  const allDeals = getAllDeals();

  // Search and filter logic
  const searchResults = allDeals
    .filter((deal) => {
      // Search query filter
      if (localQuery.trim()) {
        const query = localQuery.toLowerCase();
        const matchesTitle = deal.dealTitle.toLowerCase().includes(query);
        const matchesBusiness = deal.businessName.toLowerCase().includes(query);
        const matchesCategory = deal.category?.toLowerCase().includes(query);
        const matchesDescription = deal.dealTitle.toLowerCase().includes(query);
        
        if (!matchesTitle && !matchesBusiness && !matchesCategory && !matchesDescription) {
          return false;
        }
      }

      // Category filter
      if (categoryFilter !== "all") {
        const categoryMap: Record<CategoryFilter, string> = {
          "all": "",
          "fast-food": "Fast Food",
          "pizza": "Pizza",
          "coffee": "Coffee",
          "sushi": "Sushi",
          "healthy": "Healthy",
          "desserts": "Desserts",
          "asian": "Asian",
          "desi": "Desi Food",
        };
        if (deal.category !== categoryMap[categoryFilter]) return false;
      }

      // Verified filter
      if (showVerifiedOnly && !deal.verified) return false;

      // Minimum discount filter
      if (minDiscount > 0) {
        const discount = deal.originalPrice && deal.dealPrice
          ? ((deal.originalPrice - deal.dealPrice) / deal.originalPrice) * 100
          : 0;
        if (discount < minDiscount) return false;
      }

      return true;
    })
    .sort((a, b) => {
      if (sortBy === "discount") {
        const discountA = a.originalPrice && a.dealPrice
          ? ((a.originalPrice - a.dealPrice) / a.originalPrice) * 100
          : 0;
        const discountB = b.originalPrice && b.dealPrice
          ? ((b.originalPrice - b.dealPrice) / b.originalPrice) * 100
          : 0;
        return discountB - discountA;
      }
      if (sortBy === "price") {
        return (a.dealPrice || 0) - (b.dealPrice || 0);
      }
      if (sortBy === "distance") {
        const distA = parseFloat(a.distance?.replace(" km", "") || "999");
        const distB = parseFloat(b.distance?.replace(" km", "") || "999");
        return distA - distB;
      }
      if (sortBy === "rating") {
        return (b.rating || 0) - (a.rating || 0);
      }
      return 0; // "relevance"
    });

  const handleSearch = () => {
    if (localQuery.trim()) {
      addToSearchHistory(localQuery);
      setSearchQuery(localQuery);
    }
  };

  const handleSearchFromHistory = (query: string) => {
    setLocalQuery(query);
    setSearchQuery(query);
  };

  const handleClearSearch = () => {
    setLocalQuery("");
    setSearchQuery("");
  };

  const activeFilterCount = [
    categoryFilter !== "all",
    showVerifiedOnly,
    minDiscount > 0,
    selectedLocation !== "Islamabad",
  ].filter(Boolean).length;

  const resetFilters = () => {
    setCategoryFilter("all");
    setSortBy("relevance");
    setShowVerifiedOnly(false);
    setMinDiscount(0);
    setSelectedLocation("Islamabad");
  };

  const trendingSearches = ["Burger", "Pizza", "Coffee", "Sushi", "Biryani", "Ice Cream"];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      <ResponsiveHeader title="Search" showBack />

      <div className="max-w-7xl mx-auto">
        {/* Search Bar Section */}
        <div className="bg-white border-b border-gray-200 sticky top-0 z-40 lg:top-[73px]">
          <div className="px-4 sm:px-6 py-4">
            <div className="flex items-center gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={localQuery}
                  onChange={(e) => setLocalQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder="Search deals, shops, categories..."
                  className="w-full pl-12 pr-12 py-3 bg-gray-50 rounded-xl text-foreground placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-primary/20 focus:bg-white transition-all"
                  autoFocus
                />
                {localQuery && (
                  <button
                    onClick={handleClearSearch}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-200 rounded-full transition-colors"
                  >
                    <X className="w-4 h-4 text-gray-500" />
                  </button>
                )}
              </div>
              <button
                onClick={handleSearch}
                className="px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 active:bg-primary/80 transition-colors"
              >
                Search
              </button>
            </div>
          </div>
        </div>

        <div className="px-4 sm:px-6 py-6">
          {/* Show search history and trending when no query */}
          {!localQuery && searchResults.length === allDeals.length && (
            <div className="space-y-8">
              {/* Search History */}
              {searchHistory.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-muted-foreground" />
                      <h2 className="text-lg font-semibold text-foreground">Recent Searches</h2>
                    </div>
                    <button
                      onClick={clearSearchHistory}
                      className="text-sm text-primary hover:underline"
                    >
                      Clear All
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {searchHistory.map((query, index) => (
                      <button
                        key={index}
                        onClick={() => handleSearchFromHistory(query)}
                        className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm text-foreground hover:border-primary hover:bg-primary/5 transition-all"
                      >
                        {query}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Trending Searches */}
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="w-5 h-5 text-accent" />
                  <h2 className="text-lg font-semibold text-foreground">Trending Searches</h2>
                </div>
                <div className="flex flex-wrap gap-2">
                  {trendingSearches.map((term, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        setLocalQuery(term);
                        handleSearchFromHistory(term);
                      }}
                      className="px-4 py-2 bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 rounded-xl text-sm text-foreground font-medium hover:from-primary/20 hover:to-accent/20 transition-all"
                    >
                      🔥 {term}
                    </button>
                  ))}
                </div>
              </div>

              {/* Popular Categories */}
              <div>
                <h2 className="text-lg font-semibold text-foreground mb-4">Browse by Category</h2>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { icon: "🍔", label: "Fast Food", key: "fast-food" },
                    { icon: "🍕", label: "Pizza", key: "pizza" },
                    { icon: "☕", label: "Coffee", key: "coffee" },
                    { icon: "🍣", label: "Sushi", key: "sushi" },
                    { icon: "🥗", label: "Healthy", key: "healthy" },
                    { icon: "🍰", label: "Desserts", key: "desserts" },
                    { icon: "🍜", label: "Asian", key: "asian" },
                    { icon: "🥘", label: "Desi Food", key: "desi" },
                  ].map((cat) => (
                    <button
                      key={cat.key}
                      onClick={() => {
                        setCategoryFilter(cat.key as CategoryFilter);
                      }}
                      className="p-4 bg-white border border-gray-200 rounded-xl hover:border-primary hover:shadow-sm transition-all text-center"
                    >
                      <div className="text-3xl mb-2">{cat.icon}</div>
                      <div className="text-sm font-medium text-foreground">{cat.label}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Search Results */}
          {(localQuery || searchResults.length < allDeals.length) && (
            <div>
              {/* Results Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-foreground mb-1">
                    {searchResults.length} {searchResults.length === 1 ? "Result" : "Results"}
                    {localQuery && (
                      <span className="text-muted-foreground font-normal">
                        {" "}for "{localQuery}"
                      </span>
                    )}
                  </h2>
                  <p className="text-sm text-muted-foreground">in {selectedLocation}</p>
                </div>

                {/* Desktop Controls */}
                <div className="hidden sm:flex items-center gap-3">
                  <button
                    onClick={() => setIsFilterOpen(!isFilterOpen)}
                    className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors relative"
                  >
                    <Filter className="w-4 h-4" />
                    <span className="text-sm font-medium">Filter</span>
                    {activeFilterCount > 0 && (
                      <span className="absolute -top-1 -right-1 w-5 h-5 bg-accent text-white text-xs rounded-full flex items-center justify-center font-semibold">
                        {activeFilterCount}
                      </span>
                    )}
                  </button>
                  <select
                    value={viewMode}
                    onChange={(e) => setViewMode(e.target.value as ViewMode)}
                    className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm outline-none"
                  >
                    <option value="list">List View</option>
                    <option value="grid">Grid View</option>
                  </select>
                </div>
              </div>

              {/* Mobile Filter Toggle */}
              <div className="sm:hidden flex items-center gap-3 mb-4">
                <button
                  onClick={() => setIsFilterOpen(!isFilterOpen)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white border border-gray-200 rounded-xl active:bg-gray-50 transition-colors relative"
                >
                  <SlidersHorizontal className="w-5 h-5" />
                  <span className="text-sm font-medium">Filters & Sort</span>
                  {activeFilterCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-6 h-6 bg-accent text-white text-xs rounded-full flex items-center justify-center font-semibold">
                      {activeFilterCount}
                    </span>
                  )}
                </button>
                <select
                  value={viewMode}
                  onChange={(e) => setViewMode(e.target.value as ViewMode)}
                  className="px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm outline-none"
                >
                  <option value="list">List</option>
                  <option value="grid">Grid</option>
                </select>
              </div>

              {/* Filter Panel */}
              {isFilterOpen && (
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4 sm:p-6 mb-6 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-foreground">Filters & Sorting</h3>
                    <button
                      onClick={() => setIsFilterOpen(false)}
                      className="p-2 hover:bg-gray-100 rounded-full transition-colors lg:hidden"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {/* Location */}
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-3">
                        Location
                      </label>
                      <LocationSelector value={selectedLocation} onChange={setSelectedLocation} />
                    </div>

                    {/* Sort By */}
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-3">
                        Sort By
                      </label>
                      <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value as SortOption)}
                        className="w-full px-4 py-2.5 bg-secondary border border-gray-200 rounded-xl text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/20"
                      >
                        <option value="relevance">Most Relevant</option>
                        <option value="discount">Highest Discount</option>
                        <option value="price">Lowest Price</option>
                        <option value="distance">Nearest First</option>
                        <option value="rating">Highest Rated</option>
                      </select>
                    </div>

                    {/* Category */}
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-3">
                        Category
                      </label>
                      <select
                        value={categoryFilter}
                        onChange={(e) => setCategoryFilter(e.target.value as CategoryFilter)}
                        className="w-full px-4 py-2.5 bg-secondary border border-gray-200 rounded-xl text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/20"
                      >
                        <option value="all">All Categories</option>
                        <option value="fast-food">🍔 Fast Food</option>
                        <option value="pizza">🍕 Pizza</option>
                        <option value="coffee">☕ Coffee</option>
                        <option value="sushi">🍣 Sushi</option>
                        <option value="healthy">🥗 Healthy</option>
                        <option value="desserts">🍰 Desserts</option>
                        <option value="asian">🍜 Asian</option>
                        <option value="desi">🥘 Desi Food</option>
                      </select>
                    </div>

                    {/* Min Discount */}
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-3">
                        Minimum Discount
                      </label>
                      <select
                        value={minDiscount}
                        onChange={(e) => setMinDiscount(Number(e.target.value))}
                        className="w-full px-4 py-2.5 bg-secondary border border-gray-200 rounded-xl text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/20"
                      >
                        <option value={0}>Any Discount</option>
                        <option value={10}>10% or more</option>
                        <option value={20}>20% or more</option>
                        <option value={30}>30% or more</option>
                        <option value={50}>50% or more</option>
                      </select>
                    </div>
                  </div>

                  {/* Verified Only */}
                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={showVerifiedOnly}
                        onChange={(e) => setShowVerifiedOnly(e.target.checked)}
                        className="w-5 h-5 rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <div>
                        <span className="text-sm font-medium text-foreground">Verified Businesses Only</span>
                        <p className="text-xs text-muted-foreground">Show only deals from verified sellers</p>
                      </div>
                    </label>
                  </div>

                  {/* Reset */}
                  {activeFilterCount > 0 && (
                    <div className="mt-6 pt-6 border-t border-gray-200">
                      <button
                        onClick={resetFilters}
                        className="w-full sm:w-auto px-6 py-2.5 text-sm font-medium text-primary hover:bg-primary/10 rounded-xl transition-colors"
                      >
                        Reset All Filters ({activeFilterCount})
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Results Grid/List */}
              {searchResults.length > 0 ? (
                <div
                  className={
                    viewMode === "grid"
                      ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4"
                      : "space-y-3 sm:space-y-4"
                  }
                >
                  {searchResults.map((deal) =>
                    viewMode === "grid" ? (
                      <DealCard key={deal.id} {...deal} />
                    ) : (
                      <DealListItem key={deal.id} {...deal} />
                    )
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-16">
                  <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mb-6">
                    <Search className="w-10 h-10 text-gray-400" />
                  </div>
                  <h2 className="text-xl font-semibold text-foreground mb-3">No Results Found</h2>
                  <p className="text-sm text-muted-foreground text-center max-w-md mb-6 px-4">
                    We couldn't find any deals matching your search.
                    <br />
                    Try different keywords or adjust your filters.
                  </p>
                  <button
                    onClick={() => {
                      handleClearSearch();
                      resetFilters();
                    }}
                    className="px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 transition-colors"
                  >
                    Clear Search & Filters
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
