import { useState } from "react";
import { useNavigate, useParams } from "react-router";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { DesktopHeader } from "../components/desktop-header";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import {
  MapPin,
  Clock,
  Calendar,
  Phone,
  Globe,
  Share2,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  CheckCircle,
  Star,
  Navigation,
  Heart,
  Tag,
  Info,
  Shield,
  Instagram,
  Plus,
  Check,
  X,
} from "lucide-react";

// Mock data helper
function getDealById(id: string) {
  const deals: any = {
    "1": {
      id: "1",
      title: "50% Off on All Pizzas",
      shopName: "Pizza Palace",
      location: "F-7 Markaz, Islamabad",
      category: "Pizza",
      discount: "50",
      originalPrice: 2000,
      discountedPrice: 1000,
      description: "Get amazing discounts on all our signature pizzas! Enjoy authentic Italian flavors with premium toppings. Valid for dine-in and takeaway.",
      terms: "Valid until December 31, 2024. Cannot be combined with other offers. Applicable on all pizza sizes. Not valid on public holidays.",
      validUntil: "Dec 31, 2024",
      hours: "11:00 AM - 11:00 PM",
      phone: "+92 51 1234567",
      instagram: "@pizzapalace",
      website: "www.pizzapalace.pk",
      verified: true,
      trustScore: 4.8,
      distance: "0.8 km",
      walkTime: "10 mins walk",
      images: [
        "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800",
        "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800",
        "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=800",
      ],
    },
  };
  return deals[id];
}

// Mock similar deals
const SIMILAR_DEALS = [
  {
    id: "2",
    title: "Buy 2 Get 1 Free on Clothing",
    shopName: "Fashion Hub",
    location: "F-7 Markaz",
    discount: "33% Off",
    image: "https://images.unsplash.com/photo-1770362804478-86f1ccc60e7c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbG90aGluZyUyMHN0b3JlJTIwc2FsZSUyMGRpc2NvdW50fGVufDF8fHx8MTc3MjgzMTIwM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    distance: "1.2 km",
  },
  {
    id: "3",
    title: "20% Off on All Electronics",
    shopName: "Tech Zone",
    location: "Blue Area",
    discount: "20% Off",
    image: "https://images.unsplash.com/photo-1761207850745-d41a776ef897?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljcyUyMGdhZGdldHMlMjBzaG9wfGVufDF8fHx8MTc3MjgzMTIwM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    distance: "2.1 km",
  },
  {
    id: "4",
    title: "50% Off on Dine-In",
    shopName: "Food Paradise",
    location: "Centaurus Mall",
    discount: "50% Off",
    image: "https://images.unsplash.com/photo-1762417420714-f15910736033?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcmVzdGF1cmFudCUyMGRlYWx8ZW58MXx8fHwxNzcyODMxMjAzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    distance: "3.0 km",
  },
];

export function DealDetailPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isInPlan, setIsInPlan] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  // Get deal data
  const deal = getDealById(id as string) || getDealById("1");

  const nextImage = () => {
    setCurrentImageIndex((prev) => 
      prev === deal.images.length - 1 ? 0 : prev + 1
    );
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => 
      prev === 0 ? deal.images.length - 1 : prev - 1
    );
  };

  const handleAddToPlan = () => {
    setIsInPlan(true);
    // In a real website, would add to planner state
  };

  const handleRemoveFromPlan = () => {
    setIsInPlan(false);
  };

  const handleGetDeal = () => {
    // In a real website, would navigate to planner or show confirmation
    navigate("/plan");
  };

  const handleShare = () => {
    // In a real website, would trigger share functionality
    alert("Share functionality would be implemented here");
  };

  const toggleSave = () => {
    setIsSaved(!isSaved);
  };

  const savings = deal.originalPrice - deal.discountedPrice;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <DesktopHeader />

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Carousel */}
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="relative aspect-video bg-gray-100">
                <ImageWithFallback
                  src={deal.images[currentImageIndex]}
                  alt={deal.title}
                  className="w-full h-full object-cover"
                  query="store deal product"
                />
                
                {/* Carousel Controls */}
                {deal.images.length > 1 && (
                  <>
                    <button
                      onClick={prevImage}
                      className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center transition"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </button>
                    <button
                      onClick={nextImage}
                      className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center transition"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </button>
                  </>
                )}

                {/* Discount Badge */}
                <div className="absolute top-4 left-4 bg-red-500 text-white px-4 py-2 rounded-lg font-bold text-lg">
                  {deal.discount}% OFF
                </div>

                {/* Action Buttons */}
                <div className="absolute top-4 right-4 flex gap-2">
                  <button
                    onClick={handleShare}
                    className="w-10 h-10 bg-white/90 hover:bg-white rounded-full flex items-center justify-center transition"
                  >
                    <Share2 className="w-5 h-5 text-gray-700" />
                  </button>
                  <button
                    onClick={toggleSave}
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition ${
                      isSaved
                        ? "bg-accent text-white"
                        : "bg-white/90 hover:bg-white text-gray-700"
                    }`}
                  >
                    <Bookmark className={`w-5 h-5 ${isSaved ? "fill-current" : ""}`} />
                  </button>
                </div>

                {/* Image Indicators */}
                {deal.images.length > 1 && (
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                    {deal.images.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentImageIndex(index)}
                        className={`w-2 h-2 rounded-full transition ${
                          index === currentImageIndex
                            ? "bg-white w-8"
                            : "bg-white/50"
                        }`}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Deal Header */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h1 className="text-3xl font-bold mb-3">{deal.title}</h1>
              
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-muted-foreground" />
                  <span className="font-medium">{deal.shopName}</span>
                  <span className="text-muted-foreground">•</span>
                  <span className="text-muted-foreground">{deal.location}</span>
                </div>
              </div>

              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Navigation className="w-4 h-4" />
                  <span>{deal.distance} • {deal.walkTime}</span>
                </div>
                
                <div className="flex items-center gap-2 px-3 py-1 bg-primary/10 border border-primary/20 rounded-full">
                  <Shield className="w-4 h-4 text-primary" />
                  <span className="text-sm font-semibold text-primary">
                    Trust Score {deal.trustScore}
                  </span>
                </div>
              </div>

              <p className="text-muted-foreground">{deal.description}</p>
            </div>

            {/* Deal Details */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold mb-4">Deal Details</h2>
              
              <div className="space-y-4">
                {/* Pricing */}
                <div className="flex items-center gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Original Price</div>
                    <div className="text-lg text-gray-400 line-through">
                      Rs. {deal.originalPrice.toLocaleString()}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="text-sm text-muted-foreground mb-1">Deal Price</div>
                    <div className="text-3xl font-bold text-primary">
                      Rs. {deal.discountedPrice.toLocaleString()}
                    </div>
                  </div>
                </div>

                {/* Savings */}
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-green-700 font-semibold">
                    <Tag className="w-5 h-5" />
                    <span>You save Rs. {savings.toLocaleString()} ({deal.discount}%)</span>
                  </div>
                </div>

                {/* Validity */}
                <div className="flex items-start gap-3 py-3 border-t">
                  <Calendar className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <div className="text-sm text-muted-foreground">Valid Until</div>
                    <div className="font-medium">{deal.validUntil}</div>
                  </div>
                </div>

                {/* Terms */}
                <div className="pt-3 border-t">
                  <div className="text-sm font-semibold mb-2">Terms & Conditions</div>
                  <p className="text-sm text-muted-foreground">{deal.terms}</p>
                </div>
              </div>
            </div>

            {/* Business Information */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold mb-4">Business Information</h2>
              
              <div className="space-y-4">
                {/* Phone */}
                <div className="flex items-center justify-between py-3 border-b">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <Phone className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Phone</div>
                      <div className="font-medium">{deal.phone}</div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(`tel:${deal.phone}`)}
                  >
                    Call
                  </Button>
                </div>

                {/* Instagram */}
                <div className="flex items-center justify-between py-3 border-b">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 rounded-full flex items-center justify-center">
                      <Instagram className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Instagram</div>
                      <div className="font-medium">{deal.instagram}</div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(`https://instagram.com/${deal.instagram.replace('@', '')}`)}
                  >
                    Visit
                  </Button>
                </div>

                {/* Website */}
                <div className="flex items-center justify-between py-3 border-b">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                      <Globe className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Website</div>
                      <div className="font-medium">{deal.website}</div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(`https://${deal.website}`)}
                  >
                    Visit
                  </Button>
                </div>

                {/* Hours */}
                <div className="flex items-center gap-3 py-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <Clock className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Hours</div>
                    <div className="font-medium">{deal.hours}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Similar Deals */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-semibold mb-4">Similar Deals Nearby</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {SIMILAR_DEALS.map((similarDeal) => (
                  <div
                    key={similarDeal.id}
                    onClick={() => navigate(`/deal/${similarDeal.id}`)}
                    className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition cursor-pointer"
                  >
                    <div className="aspect-video bg-gray-100 relative">
                      <ImageWithFallback
                        src={similarDeal.image}
                        alt={similarDeal.title}
                        className="w-full h-full object-cover"
                        query="store product"
                      />
                      <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-bold">
                        {similarDeal.discount}
                      </div>
                    </div>
                    <div className="p-3">
                      <h3 className="font-semibold text-sm mb-1 line-clamp-2">
                        {similarDeal.title}
                      </h3>
                      <p className="text-xs text-muted-foreground mb-1">
                        {similarDeal.shopName}
                      </p>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Navigation className="w-3 h-3" />
                        <span>{similarDeal.distance}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar - Location & Action */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-4">
              {/* Location & Route Section */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="font-semibold mb-4">Location</h3>
                
                {/* Mini Map Placeholder */}
                <div className="aspect-square bg-gray-100 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20" />
                  <div className="relative z-10 text-center">
                    <MapPin className="w-12 h-12 text-primary mx-auto mb-2" />
                    <p className="text-sm font-medium">{deal.shopName}</p>
                    <p className="text-xs text-muted-foreground">{deal.location}</p>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Distance</span>
                    <span className="font-medium">{deal.distance}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Walk Time</span>
                    <span className="font-medium">{deal.walkTime}</span>
                  </div>
                </div>

                {/* Add to Plan Button */}
                {!isInPlan ? (
                  <Button
                    onClick={handleAddToPlan}
                    className="w-full bg-accent hover:bg-accent/90"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add to My Day Plan
                  </Button>
                ) : (
                  <div className="space-y-2">
                    <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-2">
                      <Check className="w-5 h-5 text-green-600" />
                      <span className="text-sm font-medium text-green-900">
                        In Your Current Plan
                      </span>
                    </div>
                    <Button
                      onClick={handleRemoveFromPlan}
                      variant="outline"
                      className="w-full"
                    >
                      <X className="w-4 h-4 mr-2" />
                      Remove from Plan
                    </Button>
                  </div>
                )}

                <Button
                  variant="outline"
                  className="w-full mt-2"
                  onClick={() => navigate("/plan")}
                >
                  <Navigation className="w-4 h-4 mr-2" />
                  View Full Route
                </Button>
              </div>

              {/* Quick Stats */}
              <div className="bg-gradient-to-br from-primary/10 to-secondary border border-primary/20 rounded-xl p-6">
                <h3 className="font-semibold mb-3">Why This Deal?</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>High trust score ({deal.trustScore}/100)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Close to your location</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Verified business details</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>Save Rs. {savings.toLocaleString()}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-lg z-40">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="hidden md:block">
            <div className="text-sm text-muted-foreground">Deal Price</div>
            <div className="text-2xl font-bold text-primary">
              Rs. {deal.discountedPrice.toLocaleString()}
            </div>
          </div>
          <Button
            onClick={handleGetDeal}
            className="bg-primary hover:bg-primary/90 flex-1 md:flex-none md:px-12 h-12 text-lg"
          >
            Get This Deal
          </Button>
        </div>
      </div>
    </div>
  );
}