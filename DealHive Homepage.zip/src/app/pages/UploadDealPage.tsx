import { useState } from "react";
import { DesktopHeader } from "../components/desktop-header";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Checkbox } from "../components/ui/checkbox";
import { Calendar } from "../components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "../components/ui/popover";
import { format } from "date-fns";
import {
  CalendarIcon,
  MapPin,
  Locate,
  Upload,
  CheckCircle2,
  Info,
  Lightbulb,
} from "lucide-react";
import { useNavigate } from "react-router";

type DealType = "percentage" | "flat" | "bundle" | "bogo";

export function UploadDealPage() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);

  // Step 1 - Deal Details
  const [dealTitle, setDealTitle] = useState("");
  const [category, setCategory] = useState("");
  const [subcategory, setSubcategory] = useState("");
  const [originalPrice, setOriginalPrice] = useState("");
  const [discountedPrice, setDiscountedPrice] = useState("");
  const [isFree, setIsFree] = useState(false);
  const [dealType, setDealType] = useState<DealType>("percentage");
  const [validFrom, setValidFrom] = useState<Date>();
  const [validUntil, setValidUntil] = useState<Date>();
  const [description, setDescription] = useState("");
  const [businessAddress, setBusinessAddress] = useState("");
  const [businessLatitude, setBusinessLatitude] = useState("");
  const [businessLongitude, setBusinessLongitude] = useState("");
  const [locationSector, setLocationSector] = useState("");

  // Step 2 - Media (placeholder for future implementation)
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);

  // Categories and subcategories
  const categories = [
    {
      name: "Food & Dining",
      subcategories: ["Fast Food", "Restaurant", "Café", "Bakery", "Street Food"],
    },
    {
      name: "Shoes & Footwear",
      subcategories: ["Sneakers", "Sandals", "Formal Shoes", "Sports Shoes"],
    },
    {
      name: "Electronics",
      subcategories: ["Mobile Phones", "Laptops", "Accessories", "Home Appliances"],
    },
    {
      name: "Fashion & Clothing",
      subcategories: ["Men's Wear", "Women's Wear", "Kids Wear", "Accessories"],
    },
    {
      name: "Health & Beauty",
      subcategories: ["Salon", "Spa", "Gym", "Cosmetics"],
    },
    {
      name: "Home & Living",
      subcategories: ["Furniture", "Decor", "Kitchen", "Bedding"],
    },
  ];

  const selectedCategory = categories.find((c) => c.name === category);

  const handleSaveDraft = () => {
    console.log("Saving draft...");
    // In a real website, this would save to backend
  };

  const handleNextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleUseCurrentLocation = () => {
    // Mock geolocation - in a real website would use navigator.geolocation
    setBusinessAddress("Saddar, Islamabad, Pakistan");
    setBusinessLatitude("33.6844");
    setBusinessLongitude("73.0479");
    setLocationSector("Saddar");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <DesktopHeader />

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header Section */}
        <div className="mb-8">
          <h1 className="text-3xl mb-2">Add New Deal</h1>
          <p className="text-muted-foreground">
            Share your special offers with local customers
          </p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center gap-4">
            {[
              { step: 1, label: "Details" },
              { step: 2, label: "Media" },
              { step: 3, label: "Verify" },
            ].map((item, index) => (
              <div key={item.step} className="flex items-center">
                <div className="flex items-center gap-2">
                  <div
                    className={`flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all ${
                      currentStep === item.step
                        ? "bg-primary border-primary text-white"
                        : currentStep > item.step
                        ? "bg-primary border-primary text-white"
                        : "bg-white border-gray-300 text-gray-400"
                    }`}
                  >
                    {currentStep > item.step ? (
                      <CheckCircle2 className="w-5 h-5" />
                    ) : (
                      <span>{item.step}</span>
                    )}
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">
                      {item.step}/3
                    </div>
                    <div
                      className={`text-sm ${
                        currentStep >= item.step
                          ? "text-foreground font-semibold"
                          : "text-muted-foreground"
                      }`}
                    >
                      {item.label}
                    </div>
                  </div>
                </div>
                {index < 2 && (
                  <div
                    className={`w-16 h-0.5 mx-4 ${
                      currentStep > item.step ? "bg-primary" : "bg-gray-300"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form Area */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
              {/* Step 1: Deal Details */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl mb-6">Deal Details</h3>

                    {/* Deal Title */}
                    <div className="space-y-2 mb-4">
                      <Label htmlFor="dealTitle">Deal Title *</Label>
                      <Input
                        id="dealTitle"
                        placeholder="e.g., Buy 1 Get 1 Free Burgers"
                        value={dealTitle}
                        onChange={(e) => setDealTitle(e.target.value)}
                        className="border-gray-300"
                      />
                    </div>

                    {/* Category */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="space-y-2">
                        <Label htmlFor="category">Category *</Label>
                        <Select value={category} onValueChange={setCategory}>
                          <SelectTrigger className="border-gray-300">
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((cat) => (
                              <SelectItem key={cat.name} value={cat.name}>
                                {cat.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Subcategory */}
                      <div className="space-y-2">
                        <Label htmlFor="subcategory">
                          Subcategory (Optional)
                        </Label>
                        <Select
                          value={subcategory}
                          onValueChange={setSubcategory}
                          disabled={!category}
                        >
                          <SelectTrigger className="border-gray-300">
                            <SelectValue placeholder="Select subcategory" />
                          </SelectTrigger>
                          <SelectContent>
                            {selectedCategory?.subcategories.map((sub) => (
                              <SelectItem key={sub} value={sub}>
                                {sub}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Pricing */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="space-y-2">
                        <Label htmlFor="originalPrice">
                          Original Price (Rs.) *
                        </Label>
                        <Input
                          id="originalPrice"
                          type="number"
                          placeholder="1500"
                          value={originalPrice}
                          onChange={(e) => setOriginalPrice(e.target.value)}
                          className="border-gray-300"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="discountedPrice">
                          Discounted Price (Rs.) *
                        </Label>
                        <div className="flex gap-2">
                          <Input
                            id="discountedPrice"
                            type="number"
                            placeholder="999"
                            value={discountedPrice}
                            onChange={(e) => setDiscountedPrice(e.target.value)}
                            disabled={isFree}
                            className="border-gray-300"
                          />
                          <div className="flex items-center gap-2 whitespace-nowrap">
                            <Checkbox
                              id="isFree"
                              checked={isFree}
                              onCheckedChange={(checked) =>
                                setIsFree(checked as boolean)
                              }
                            />
                            <Label htmlFor="isFree" className="cursor-pointer">
                              Free
                            </Label>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Deal Type */}
                    <div className="space-y-2 mb-4">
                      <Label>Deal Type *</Label>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {[
                          { value: "percentage", label: "Percentage" },
                          { value: "flat", label: "Flat Discount" },
                          { value: "bundle", label: "Bundle" },
                          { value: "bogo", label: "BOGO" },
                        ].map((type) => (
                          <button
                            key={type.value}
                            type="button"
                            onClick={() => setDealType(type.value as DealType)}
                            className={`px-4 py-3 rounded-lg border-2 transition-all ${
                              dealType === type.value
                                ? "border-primary bg-secondary text-primary font-semibold"
                                : "border-gray-200 hover:border-gray-300"
                            }`}
                          >
                            {type.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Date Range */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="space-y-2">
                        <Label>Valid From *</Label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className="w-full justify-start text-left border-gray-300"
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {validFrom ? (
                                format(validFrom, "PPP")
                              ) : (
                                <span className="text-muted-foreground">
                                  Pick a date
                                </span>
                              )}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={validFrom}
                              onSelect={setValidFrom}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>

                      <div className="space-y-2">
                        <Label>Valid Until *</Label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className="w-full justify-start text-left border-gray-300"
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {validUntil ? (
                                format(validUntil, "PPP")
                              ) : (
                                <span className="text-muted-foreground">
                                  Pick a date
                                </span>
                              )}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={validUntil}
                              onSelect={setValidUntil}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>

                    {/* Description */}
                    <div className="space-y-2 mb-6">
                      <Label htmlFor="description">Description *</Label>
                      <Textarea
                        id="description"
                        placeholder="Describe your deal in detail. Include any terms and conditions..."
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        rows={4}
                        className="border-gray-300"
                      />
                      <p className="text-xs text-muted-foreground">
                        {description.length}/500 characters
                      </p>
                    </div>

                    {/* Location Section */}
                    <div className="border-t pt-6">
                      <h4 className="text-lg mb-4">Business Location</h4>

                      <div className="space-y-4">
                        {/* Islamabad Sector Selector */}
                        <div className="space-y-2">
                          <Label htmlFor="sector">Islamabad Sector/Area *</Label>
                          <Select value={locationSector} onValueChange={setLocationSector}>
                            <SelectTrigger className="border-gray-300">
                              <SelectValue placeholder="Select your sector" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="F-6">F-6 (Blue Area)</SelectItem>
                              <SelectItem value="F-7">F-7 (Jinnah Super)</SelectItem>
                              <SelectItem value="F-8">F-8 (Markaz)</SelectItem>
                              <SelectItem value="F-10">F-10 (Markaz)</SelectItem>
                              <SelectItem value="F-11">F-11 (Markaz)</SelectItem>
                              <SelectItem value="G-6">G-6</SelectItem>
                              <SelectItem value="G-7">G-7 (Aabpara)</SelectItem>
                              <SelectItem value="G-8">G-8 (Kachnar Park)</SelectItem>
                              <SelectItem value="G-9">G-9 (Karachi Company)</SelectItem>
                              <SelectItem value="G-10">G-10 (Markaz)</SelectItem>
                              <SelectItem value="G-11">G-11 (Markaz)</SelectItem>
                              <SelectItem value="I-8">I-8 (Markaz)</SelectItem>
                              <SelectItem value="I-9">I-9</SelectItem>
                              <SelectItem value="I-10">I-10 (Markaz)</SelectItem>
                              <SelectItem value="Saddar">Saddar</SelectItem>
                              <SelectItem value="Blue Area">Blue Area</SelectItem>
                              <SelectItem value="Centaurus">Centaurus Mall</SelectItem>
                              <SelectItem value="Kohsar">Kohsar Market</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="address">Complete Business Address *</Label>
                          <div className="relative">
                            <MapPin className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                            <Input
                              id="address"
                              placeholder="Shop/Building name, Street, etc."
                              value={businessAddress}
                              onChange={(e) =>
                                setBusinessAddress(e.target.value)
                              }
                              className="pl-10 border-gray-300"
                            />
                          </div>
                        </div>

                        {/* GPS Coordinates */}
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="latitude">Latitude *</Label>
                            <Input
                              id="latitude"
                              type="number"
                              step="0.000001"
                              placeholder="33.6844"
                              value={businessLatitude}
                              onChange={(e) => setBusinessLatitude(e.target.value)}
                              className="border-gray-300"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="longitude">Longitude *</Label>
                            <Input
                              id="longitude"
                              type="number"
                              step="0.000001"
                              placeholder="73.0479"
                              value={businessLongitude}
                              onChange={(e) => setBusinessLongitude(e.target.value)}
                              className="border-gray-300"
                            />
                          </div>
                        </div>

                        <Button
                          type="button"
                          variant="outline"
                          onClick={handleUseCurrentLocation}
                          className="w-full border-primary text-primary hover:bg-secondary"
                        >
                          <Locate className="mr-2 h-4 w-4" />
                          Auto-Fill My Current Location
                        </Button>

                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <p className="text-xs text-blue-800 flex items-start gap-1">
                            <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
                            <span>
                              GPS coordinates help customers find you on the map. You can get your coordinates from Google Maps by right-clicking your business location.
                            </span>
                          </p>
                        </div>

                        {/* Map Preview */}
                        {(businessLatitude && businessLongitude) && (
                          <div className="w-full h-48 bg-gradient-to-br from-green-50 via-white to-blue-50 rounded-lg border-2 border-gray-300 flex items-center justify-center relative overflow-hidden">
                            {/* Simple map visualization */}
                            <div className="absolute inset-0 opacity-10">
                              <svg width="100%" height="100%">
                                <defs>
                                  <pattern id="grid-upload" width="40" height="40" patternUnits="userSpaceOnUse">
                                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="gray" strokeWidth="0.5"/>
                                  </pattern>
                                </defs>
                                <rect width="100%" height="100%" fill="url(#grid-upload)" />
                              </svg>
                            </div>
                            <div className="relative text-center z-10">
                              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-2 shadow-lg">
                                <MapPin className="w-6 h-6 text-white" />
                              </div>
                              <p className="text-sm font-semibold text-foreground">
                                {locationSector || "Your Business"}
                              </p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {businessLatitude}, {businessLongitude}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Media Upload */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl mb-6">Upload Photos</h3>

                    {/* Upload Area */}
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-primary transition-colors cursor-pointer">
                      <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <h4 className="text-lg mb-2">
                        Drop your images here, or click to browse
                      </h4>
                      <p className="text-sm text-muted-foreground mb-4">
                        Upload up to 5 photos (JPG, PNG - Max 5MB each)
                      </p>
                      <Button className="bg-accent hover:bg-accent/90">
                        Select Files
                      </Button>
                    </div>

                    {/* Photo Guidelines */}
                    <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h5 className="font-semibold text-blue-900 mb-2">
                        Photo Tips for Better Visibility
                      </h5>
                      <ul className="text-sm text-blue-800 space-y-1">
                        <li>• Use clear, well-lit photos of your products</li>
                        <li>• Show the actual items included in the deal</li>
                        <li>• Avoid blurry or dark images</li>
                        <li>• First photo will be used as the main thumbnail</li>
                      </ul>
                    </div>

                    {/* Preview Grid (if images uploaded) */}
                    {uploadedImages.length > 0 && (
                      <div className="mt-6 grid grid-cols-3 gap-4">
                        {uploadedImages.map((img, index) => (
                          <div
                            key={index}
                            className="aspect-square bg-gray-200 rounded-lg"
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Step 3: Review & Verify */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl mb-6">Review & Verify</h3>

                    {/* Summary Card */}
                    <div className="border border-gray-200 rounded-lg p-6 mb-6">
                      <h4 className="font-semibold mb-4">Deal Summary</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Title:</span>
                          <span className="font-medium">
                            {dealTitle || "Not set"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            Category:
                          </span>
                          <span className="font-medium">
                            {category || "Not set"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Price:</span>
                          <span className="font-medium">
                            {isFree ? (
                              "Free"
                            ) : (
                              <>
                                <span className="line-through text-muted-foreground mr-2">
                                  Rs. {originalPrice || "0"}
                                </span>
                                <span className="text-accent">
                                  Rs. {discountedPrice || "0"}
                                </span>
                              </>
                            )}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Type:</span>
                          <span className="font-medium capitalize">
                            {dealType}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            Valid Period:
                          </span>
                          <span className="font-medium">
                            {validFrom && validUntil
                              ? `${format(validFrom, "MMM d")} - ${format(
                                  validUntil,
                                  "MMM d, yyyy"
                                )}`
                              : "Not set"}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Terms Agreement */}
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                      <h5 className="font-semibold text-yellow-900 mb-2">
                        Before Publishing
                      </h5>
                      <div className="space-y-2">
                        <div className="flex items-start gap-2">
                          <Checkbox id="terms1" />
                          <Label
                            htmlFor="terms1"
                            className="text-sm text-yellow-800 cursor-pointer"
                          >
                            I confirm that this deal is currently active and
                            available
                          </Label>
                        </div>
                        <div className="flex items-start gap-2">
                          <Checkbox id="terms2" />
                          <Label
                            htmlFor="terms2"
                            className="text-sm text-yellow-800 cursor-pointer"
                          >
                            All information provided is accurate and up-to-date
                          </Label>
                        </div>
                        <div className="flex items-start gap-2">
                          <Checkbox id="terms3" />
                          <Label
                            htmlFor="terms3"
                            className="text-sm text-yellow-800 cursor-pointer"
                          >
                            I agree to DealWise's terms of service and merchant
                            guidelines
                          </Label>
                        </div>
                      </div>
                    </div>

                    {/* Success Message Preview */}
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                      <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-2" />
                      <h5 className="font-semibold text-green-900 mb-1">
                        Ready to Publish!
                      </h5>
                      <p className="text-sm text-green-800">
                        Your deal will be visible to thousands of local
                        customers in the Islamabad area
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation Buttons */}
              <div className="flex justify-between items-center mt-8 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={handleSaveDraft}
                  className="border-gray-300"
                >
                  Save Draft
                </Button>

                <div className="flex gap-3">
                  {currentStep > 1 && (
                    <Button
                      variant="outline"
                      onClick={handlePreviousStep}
                      className="border-gray-300"
                    >
                      Back
                    </Button>
                  )}

                  {currentStep < 3 ? (
                    <Button
                      onClick={handleNextStep}
                      className="bg-accent hover:bg-accent/90"
                    >
                      Next: {currentStep === 1 ? "Add Photos" : "Review"}
                    </Button>
                  ) : (
                    <Button className="bg-primary hover:bg-primary/90">
                      Publish Deal
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Tips & Info */}
          <div className="lg:col-span-1">
            <div className="bg-gradient-to-br from-primary/5 to-secondary border border-primary/20 rounded-xl p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-4">
                <Lightbulb className="w-5 h-5 text-primary" />
                <h4 className="font-semibold text-primary">Pro Tips</h4>
              </div>

              <div className="space-y-4">
                <div className="bg-white rounded-lg p-4 border border-gray-200">
                  <h5 className="font-semibold text-sm mb-2">
                    Boost Your Visibility
                  </h5>
                  <p className="text-xs text-muted-foreground">
                    Deals with clear photos get 40% more views and engagement
                    from customers
                  </p>
                </div>

                <div className="bg-white rounded-lg p-4 border border-gray-200">
                  <h5 className="font-semibold text-sm mb-2">
                    Best Posting Times
                  </h5>
                  <p className="text-xs text-muted-foreground">
                    Thursday & Friday evenings see the highest deal traffic in
                    your area
                  </p>
                </div>

                <div className="bg-white rounded-lg p-4 border border-gray-200">
                  <h5 className="font-semibold text-sm mb-2">
                    Accurate Pricing
                  </h5>
                  <p className="text-xs text-muted-foreground">
                    Verified pricing helps build trust and improves your
                    business trust score
                  </p>
                </div>

                <div className="bg-white rounded-lg p-4 border border-gray-200">
                  <h5 className="font-semibold text-sm mb-2">
                    Customer Engagement
                  </h5>
                  <p className="text-xs text-muted-foreground">
                    Respond to reviews and questions quickly to maintain a high
                    trust rating
                  </p>
                </div>
              </div>

              {/* Stats Preview */}
              <div className="mt-6 pt-6 border-t border-primary/20">
                <h5 className="text-sm font-semibold mb-3">
                  Your Dashboard Stats
                </h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Active Deals:</span>
                    <span className="font-semibold">3</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Views:</span>
                    <span className="font-semibold">1,247</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Trust Score:</span>
                    <span className="font-semibold text-primary">87/100</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}