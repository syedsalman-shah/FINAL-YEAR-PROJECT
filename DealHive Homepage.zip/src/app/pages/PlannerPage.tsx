import { useState } from "react";
import { MapPin, Navigation, Clock, DollarSign, Trash2, Plus, Route as RouteIcon, Sparkles, X, Map } from "lucide-react";
import { ResponsiveHeader } from "../components/responsive-header";
import { BottomNav } from "../components/bottom-nav";
import { DealMap } from "../components/deal-map";
import { useNavigate } from "react-router";
import { useApp } from "../context/AppContext";
import { getAllDeals } from "../data/mockDeals";

export function PlannerPage() {
  const navigate = useNavigate();
  const { plannerDeals, removeFromPlan, clearPlan, addToPlan } = useApp();
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [isOptimized, setIsOptimized] = useState(false);
  const [showAddDeals, setShowAddDeals] = useState(false);
  const [showMap, setShowMap] = useState(false);

  const allDeals = getAllDeals();
  const availableDeals = allDeals.filter(deal => 
    !plannerDeals.some(pd => pd.id === deal.id)
  );

  // Calculate totals
  const totalOriginalPrice = plannerDeals.reduce((sum, deal) => 
    sum + (deal.originalPrice || 0), 0
  );
  const totalDealPrice = plannerDeals.reduce((sum, deal) => 
    sum + (deal.dealPrice || 0), 0
  );
  const totalSavings = totalOriginalPrice - totalDealPrice;
  const totalDistance = plannerDeals.reduce((sum, deal) => 
    sum + parseFloat(deal.distance?.replace(" km", "") || "0"), 0
  );
  const estimatedTime = Math.ceil(plannerDeals.length * 15 + totalDistance * 3); // 15 min per stop + 3 min per km

  const handleOptimize = () => {
    setIsOptimizing(true);
    // Simulate AI optimization
    setTimeout(() => {
      setIsOptimizing(false);
      setIsOptimized(true);
      // In real app, this would reorder based on location optimization
    }, 2000);
  };

  const handleStartRoute = () => {
    if (plannerDeals.length === 0) return;
    // In real app, would open Google Maps with waypoints
    const firstDeal = plannerDeals[0];
    alert(`Opening navigation to ${firstDeal.businessName}...\n\nIn a real app, this would launch Google Maps with your optimized route!`);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      <ResponsiveHeader title="Shopping Planner" showBack showSearch />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* AI Banner */}
        <div className="bg-gradient-to-r from-primary via-primary/95 to-accent/90 text-white rounded-2xl p-6 mb-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
          <div className="relative flex items-start gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-6 h-6 text-yellow-300" />
            </div>
            <div className="flex-1">
              <h2 className="text-lg sm:text-xl font-bold mb-2">AI-Powered Route Optimization</h2>
              <p className="text-sm sm:text-base text-white/90 mb-4">
                Add deals to your plan and let our AI optimize your shopping route to save time and money.
              </p>
              <div className="flex flex-wrap gap-2">
                <div className="px-3 py-1 bg-white/20 rounded-full text-xs sm:text-sm font-medium">
                  Smart Routes
                </div>
                <div className="px-3 py-1 bg-white/20 rounded-full text-xs sm:text-sm font-medium">
                  Time Saver
                </div>
                <div className="px-3 py-1 bg-white/20 rounded-full text-xs sm:text-sm font-medium">
                  Fuel Efficient
                </div>
              </div>
            </div>
          </div>
        </div>

        {plannerDeals.length === 0 ? (
          /* Empty State */
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-12 text-center">
            <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <RouteIcon className="w-12 h-12 text-primary" />
            </div>
            <h2 className="text-2xl font-semibold text-foreground mb-3">
              Start Planning Your Shopping Trip
            </h2>
            <p className="text-muted-foreground text-center max-w-md mx-auto mb-8">
              Add deals from the homepage or search results to create an optimized shopping route. 
              Our AI will arrange them in the most efficient order.
            </p>
            <button
              onClick={() => navigate("/")}
              className="px-8 py-3 bg-accent text-white rounded-xl hover:bg-accent/90 active:bg-accent/80 transition-colors font-semibold"
            >
              Browse Deals
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Summary Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
              <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
                <div className="flex items-center gap-2 text-primary mb-2">
                  <MapPin className="w-5 h-5" />
                  <span className="text-xs sm:text-sm font-medium">Stops</span>
                </div>
                <div className="text-2xl font-bold text-foreground">{plannerDeals.length}</div>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
                <div className="flex items-center gap-2 text-accent mb-2">
                  <DollarSign className="w-5 h-5" />
                  <span className="text-xs sm:text-sm font-medium">Savings</span>
                </div>
                <div className="text-2xl font-bold text-accent">₨{totalSavings.toLocaleString()}</div>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
                <div className="flex items-center gap-2 text-blue-600 mb-2">
                  <Navigation className="w-5 h-5" />
                  <span className="text-xs sm:text-sm font-medium">Distance</span>
                </div>
                <div className="text-2xl font-bold text-foreground">{totalDistance.toFixed(1)} km</div>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
                <div className="flex items-center gap-2 text-purple-600 mb-2">
                  <Clock className="w-5 h-5" />
                  <span className="text-xs sm:text-sm font-medium">Time</span>
                </div>
                <div className="text-2xl font-bold text-foreground">~{estimatedTime}m</div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleOptimize}
                disabled={isOptimizing || plannerDeals.length < 2}
                className={`flex-1 flex items-center justify-center gap-2 px-6 py-4 rounded-xl font-semibold transition-all ${
                  isOptimizing
                    ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                    : isOptimized
                    ? "bg-green-500 text-white hover:bg-green-600"
                    : "bg-primary text-white hover:bg-primary/90 active:bg-primary/80"
                }`}
              >
                {isOptimizing ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Optimizing Route...</span>
                  </>
                ) : isOptimized ? (
                  <>
                    <Sparkles className="w-5 h-5" />
                    <span>Route Optimized!</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    <span>Optimize with AI</span>
                  </>
                )}
              </button>
              
              <button
                onClick={handleStartRoute}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-4 bg-accent text-white rounded-xl font-semibold hover:bg-accent/90 active:bg-accent/80 transition-all"
              >
                <Navigation className="w-5 h-5" />
                <span>Start Navigation</span>
              </button>
              
              <button
                onClick={() => setShowAddDeals(!showAddDeals)}
                className="sm:w-auto px-6 py-4 bg-white border-2 border-primary text-primary rounded-xl font-semibold hover:bg-primary/5 active:bg-primary/10 transition-all flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" />
                <span className="hidden sm:inline">Add More</span>
              </button>
            </div>

            {/* Add Deals Panel */}
            {showAddDeals && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4 sm:p-6 animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-foreground">Add Deals to Plan</h3>
                  <button
                    onClick={() => setShowAddDeals(false)}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-96 overflow-y-auto">
                  {availableDeals.slice(0, 10).map((deal) => (
                    <button
                      key={deal.id}
                      onClick={() => {
                        addToPlan(deal);
                        setIsOptimized(false);
                      }}
                      className="flex items-start gap-3 p-3 bg-gray-50 hover:bg-gray-100 rounded-xl text-left transition-colors"
                    >
                      <img
                        src={deal.dealImage}
                        alt={deal.businessName}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-foreground text-sm truncate">{deal.businessName}</div>
                        <div className="text-xs text-muted-foreground truncate">{deal.dealTitle}</div>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-sm font-bold text-accent">₨{deal.dealPrice}</span>
                          <span className="text-xs text-muted-foreground line-through">₨{deal.originalPrice}</span>
                        </div>
                      </div>
                      <Plus className="w-5 h-5 text-primary flex-shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Route List */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-gray-200 bg-gray-50">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-foreground">Your Shopping Route</h3>
                  {plannerDeals.length > 0 && (
                    <button
                      onClick={clearPlan}
                      className="text-sm text-red-600 hover:text-red-700 font-medium"
                    >
                      Clear All
                    </button>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  {isOptimized ? "Optimized for shortest route" : "In order of selection"}
                </p>
              </div>

              <div className="divide-y divide-gray-200">
                {plannerDeals.map((deal, index) => (
                  <div key={deal.id} className="p-4 sm:p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start gap-4">
                      {/* Step Number */}
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold flex-shrink-0 ${
                        index === 0
                          ? "bg-accent text-white"
                          : "bg-gray-200 text-gray-700"
                      }`}>
                        {index + 1}
                      </div>

                      {/* Deal Image */}
                      <img
                        src={deal.dealImage}
                        alt={deal.businessName}
                        className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl object-cover flex-shrink-0 cursor-pointer hover:opacity-90 transition-opacity"
                        onClick={() => navigate(`/deal/${deal.id}`)}
                      />

                      {/* Deal Info */}
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-foreground mb-1 cursor-pointer hover:text-primary transition-colors"
                            onClick={() => navigate(`/deal/${deal.id}`)}>
                          {deal.businessName}
                        </h4>
                        <p className="text-sm text-muted-foreground mb-2 line-clamp-1">
                          {deal.dealTitle}
                        </p>
                        <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-xs sm:text-sm">
                          <div className="flex items-center gap-1 text-primary">
                            <MapPin className="w-4 h-4" />
                            <span>{deal.distance}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-accent">₨{deal.dealPrice?.toLocaleString()}</span>
                            <span className="text-muted-foreground line-through">₨{deal.originalPrice?.toLocaleString()}</span>
                          </div>
                          {deal.verified && (
                            <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded text-xs font-medium">
                              Verified
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={() => {
                          removeFromPlan(deal.id);
                          setIsOptimized(false);
                        }}
                        className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-colors flex-shrink-0"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Route Arrow */}
                    {index < plannerDeals.length - 1 && (
                      <div className="flex items-center gap-2 ml-5 mt-3 text-gray-400">
                        <div className="w-0.5 h-8 bg-gray-300"></div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Total Summary */}
              <div className="p-4 sm:p-6 bg-gradient-to-r from-primary/5 to-accent/5 border-t border-gray-200">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-muted-foreground">Total Original Price</span>
                  <span className="text-sm text-muted-foreground line-through">₨{totalOriginalPrice.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-muted-foreground">Total Deal Price</span>
                  <span className="text-lg font-bold text-foreground">₨{totalDealPrice.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-gray-200">
                  <span className="text-base font-semibold text-foreground">You Save</span>
                  <span className="text-2xl font-bold text-accent">₨{totalSavings.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}