import { Search, ChevronRight, Sparkles, TrendingUp, Map } from "lucide-react";
import { DealCard } from "../components/deal-card";
import { CategoryCard } from "../components/category-card";
import { DealListItem } from "../components/deal-list-item";
import { ResponsiveHeader } from "../components/responsive-header";
import { BottomNav } from "../components/bottom-nav";
import { LocationSelector } from "../components/location-selector";
import { OnboardingModal, OnboardingModalMobile } from "../components/OnboardingModal";
import { useNavigate } from "react-router";
import { getAllDeals } from "../data/mockDeals";
import { useApp } from "../context/AppContext";

export function HomePage() {
  const navigate = useNavigate();
  const { selectedLocation, setSelectedLocation } = useApp();
  const allDeals = getAllDeals();
  
  const trendingDeals = allDeals.slice(0, 6);
  const justAddedDeals = allDeals.slice(6);

  const categories = [
    { icon: "🍔", label: "Fast Food" },
    { icon: "🍕", label: "Pizza" },
    { icon: "☕", label: "Coffee" },
    { icon: "🍣", label: "Sushi" },
    { icon: "🥗", label: "Healthy" },
    { icon: "🍰", label: "Desserts" },
    { icon: "🍜", label: "Asian" },
    { icon: "🥘", label: "Desi Food" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      <ResponsiveHeader showMenu showNotifications />

      {/* Hero Section with Search */}
      <div className="bg-gradient-to-br from-primary via-primary to-primary/95 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 lg:py-16">
          <div className="max-w-3xl mx-auto text-center mb-6 sm:mb-8">
            <div className="flex items-center justify-center gap-2 mb-3 sm:mb-4">
              <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-300" />
              <span className="text-xs sm:text-sm font-medium text-white/90">AI-Powered Discovery</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-2 sm:mb-3 leading-tight">
              Discover Amazing Deals Near You
            </h2>
            <p className="text-white/90 text-sm sm:text-base lg:text-lg">
              Verified businesses across {selectedLocation}
            </p>
          </div>

          {/* Location Selector - Mobile Only */}
          <div className="lg:hidden flex justify-center mb-4">
            <LocationSelector value={selectedLocation} onChange={setSelectedLocation} />
          </div>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
            <input
              type="text"
              onClick={() => navigate("/search")}
              readOnly
              placeholder="Search deals, shops, categories..."
              className="w-full pl-12 pr-4 py-3 sm:py-4 rounded-xl sm:rounded-2xl text-foreground placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-accent shadow-lg text-sm sm:text-base"
            />
          </div>

          {/* Quick Actions */}
          <div className="max-w-2xl mx-auto mt-4 flex gap-3">
            <button
              onClick={() => navigate("/map")}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white/20 hover:bg-white/30 active:bg-white/40 backdrop-blur-sm rounded-xl text-white font-semibold transition-all border border-white/30"
            >
              <Map className="w-5 h-5" />
              <span className="text-sm sm:text-base">Map View</span>
            </button>
            <button
              onClick={() => navigate("/plan")}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-accent hover:bg-accent/90 active:bg-accent/80 rounded-xl text-white font-semibold transition-all shadow-lg"
            >
              <Sparkles className="w-5 h-5" />
              <span className="text-sm sm:text-base">AI Planner</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Popular Categories Section */}
        <div className="mb-8 sm:mb-12">
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <h2 className="text-lg sm:text-xl lg:text-2xl font-semibold text-foreground">
              Categories
            </h2>
          </div>
          <div className="grid grid-cols-4 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3 sm:gap-4">
            {categories.map((category, index) => (
              <CategoryCard key={index} {...category} />
            ))}
          </div>
        </div>

        {/* Trending Deals Section */}
        <div className="mb-8 sm:mb-12">
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-accent" />
              <h2 className="text-lg sm:text-xl lg:text-2xl font-semibold text-foreground">
                Trending Now
              </h2>
            </div>
            <button 
              onClick={() => navigate("/search")}
              className="flex items-center gap-1 text-primary text-sm sm:text-base hover:underline active:underline"
            >
              <span className="hidden sm:inline">View All</span>
              <span className="sm:hidden">All</span>
              <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
          
          {/* Mobile: Horizontal Scroll */}
          <div className="lg:hidden overflow-x-auto -mx-4 px-4 pb-2 scrollbar-hide">
            <div className="flex gap-3 sm:gap-4" style={{ width: 'max-content' }}>
              {trendingDeals.map((deal, index) => (
                <div key={index} className="w-[280px] sm:w-[320px] flex-shrink-0">
                  <DealCard {...deal} />
                </div>
              ))}
            </div>
          </div>

          {/* Desktop: Grid */}
          <div className="hidden lg:grid lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {trendingDeals.map((deal, index) => (
              <DealCard key={index} {...deal} />
            ))}
          </div>
        </div>

        {/* Just Added Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <h2 className="text-lg sm:text-xl lg:text-2xl font-semibold text-foreground">
              Just Added
            </h2>
            <button 
              onClick={() => navigate("/search")}
              className="flex items-center gap-1 text-primary text-sm sm:text-base hover:underline active:underline"
            >
              <span className="hidden sm:inline">View All</span>
              <span className="sm:hidden">All</span>
              <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
          
          {/* Mobile & Tablet: List View */}
          <div className="lg:hidden space-y-3">
            {justAddedDeals.slice(0, 5).map((deal, index) => (
              <DealListItem key={index} {...deal} />
            ))}
          </div>

          {/* Desktop: Grid */}
          <div className="hidden lg:grid lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {justAddedDeals.map((deal, index) => (
              <DealCard key={index} {...deal} />
            ))}
          </div>
        </div>

        {/* Bottom CTA - Mobile Only */}
        <div className="lg:hidden mt-8 p-6 bg-gradient-to-br from-primary to-primary/90 rounded-2xl text-white text-center">
          <h3 className="text-lg font-semibold mb-2">Own a Business?</h3>
          <p className="text-sm text-white/90 mb-4">
            List your deals and reach thousands of customers
          </p>
          <button
            onClick={() => navigate("/upload-deal")}
            className="w-full px-6 py-3 bg-white text-primary rounded-xl font-semibold active:bg-gray-100 transition-colors"
          >
            Upload Your Deal
          </button>
        </div>
      </div>

      <BottomNav />

      {/* Onboarding Modals */}
      <div className="hidden md:block">
        <OnboardingModal />
      </div>
      <OnboardingModalMobile />
    </div>
  );
}