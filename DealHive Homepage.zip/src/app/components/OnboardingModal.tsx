import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, User, Store, ArrowRight } from "lucide-react";
import { useApp } from "../context/AppContext";
import { useNavigate } from "react-router";

export function OnboardingModal() {
  const { hasCompletedOnboarding, completeOnboarding, setUserRole } = useApp();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(!hasCompletedOnboarding);

  const handleSelectRole = (role: "user" | "business") => {
    setUserRole(role);
    completeOnboarding();
    setIsOpen(false);

    // If business, redirect to business registration flow
    if (role === "business") {
      navigate("/upload-deal");
    }
  };

  const handleClose = () => {
    // Allow close but don't mark as completed - will show again next time
    setIsOpen(false);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={handleClose}
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ 
            duration: 0.4, 
            ease: [0.34, 1.56, 0.64, 1] // Smooth spring-like easing
          }}
          className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Close button */}
          <button
            onClick={handleClose}
            className="absolute top-6 right-6 z-10 p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors duration-200"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>

          {/* Header */}
          <div className="px-8 pt-12 pb-8 text-center bg-gradient-to-br from-secondary via-primary/10 to-secondary">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              <h1 className="text-4xl mb-3">Welcome to Deal Hive 🍯</h1>
              <p className="text-lg text-muted-foreground max-w-md mx-auto">
                Choose how you want to continue
              </p>
            </motion.div>
          </div>

          {/* Content - Two Options */}
          <div className="px-8 py-10 grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Browse as User Option */}
            <motion.button
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              onClick={() => handleSelectRole("user")}
              className="group relative bg-gradient-to-br from-secondary to-primary/10 border-2 border-primary/30 hover:border-primary rounded-2xl p-8 text-left transition-all duration-300 hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]"
            >
              {/* Icon */}
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary/80 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <User className="w-8 h-8 text-white" />
              </div>

              {/* Text */}
              <h3 className="text-2xl mb-3 text-gray-900">Browse as User</h3>
              <p className="text-sm text-gray-600 leading-relaxed mb-6">
                Explore restaurants, deals, and offers near you in Islamabad
              </p>

              {/* Arrow */}
              <div className="flex items-center gap-2 text-primary font-semibold group-hover:gap-3 transition-all duration-300">
                <span>Get Started</span>
                <ArrowRight className="w-5 h-5" />
              </div>

              {/* Hover Effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/0 to-primary/0 group-hover:from-primary/10 group-hover:to-primary/5 rounded-2xl transition-all duration-300" />
            </motion.button>

            {/* Register as Business Option */}
            <motion.button
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              onClick={() => handleSelectRole("business")}
              className="group relative bg-gradient-to-br from-accent/10 to-accent/5 border-2 border-accent/40 hover:border-accent rounded-2xl p-8 text-left transition-all duration-300 hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]"
            >
              {/* Icon */}
              <div className="w-16 h-16 bg-gradient-to-br from-accent to-accent/90 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Store className="w-8 h-8 text-white" />
              </div>

              {/* Text */}
              <h3 className="text-2xl mb-3 text-gray-900">Register as Business</h3>
              <p className="text-sm text-gray-600 leading-relaxed mb-6">
                List your restaurant or shop and upload deals to reach more customers
              </p>

              {/* Arrow */}
              <div className="flex items-center gap-2 text-accent font-semibold group-hover:gap-3 transition-all duration-300">
                <span>Get Started</span>
                <ArrowRight className="w-5 h-5" />
              </div>

              {/* Hover Effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-accent/0 to-accent/0 group-hover:from-accent/10 group-hover:to-accent/5 rounded-2xl transition-all duration-300" />
            </motion.button>
          </div>

          {/* Footer */}
          <div className="px-8 pb-8 text-center">
            <p className="text-xs text-muted-foreground">
              You can always change your role later in settings
            </p>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

// Mobile-optimized version (Bottom sheet)
export function OnboardingModalMobile() {
  const { hasCompletedOnboarding, completeOnboarding, setUserRole } = useApp();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(!hasCompletedOnboarding);

  const handleSelectRole = (role: "user" | "business") => {
    setUserRole(role);
    completeOnboarding();
    setIsOpen(false);

    if (role === "business") {
      navigate("/upload-deal");
    }
  };

  const handleClose = () => {
    setIsOpen(false);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="md:hidden fixed inset-0 z-50">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={handleClose}
        />

        {/* Bottom Sheet */}
        <motion.div
          initial={{ y: "100%" }}
          animate={{ y: 0 }}
          exit={{ y: "100%" }}
          transition={{ type: "spring", damping: 30, stiffness: 300 }}
          className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl shadow-2xl max-h-[85vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Drag Handle */}
          <div className="py-3 flex justify-center">
            <div className="w-12 h-1.5 bg-gray-300 rounded-full" />
          </div>

          {/* Header */}
          <div className="px-6 pt-6 pb-6 text-center">
            <h1 className="text-3xl mb-2">Welcome to Deal Hive 🍯</h1>
            <p className="text-base text-muted-foreground">
              Choose how you want to continue
            </p>
          </div>

          {/* Options */}
          <div className="px-6 pb-8 space-y-4">
            {/* Browse as User */}
            <button
              onClick={() => handleSelectRole("user")}
              className="w-full bg-gradient-to-br from-secondary to-primary/10 border-2 border-primary/30 active:border-primary rounded-2xl p-6 text-left active:scale-[0.98] transition-all duration-200"
            >
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 bg-gradient-to-br from-primary to-primary/80 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                  <User className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl mb-2 text-gray-900">Browse as User</h3>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    Explore restaurants, deals, and offers near you
                  </p>
                </div>
              </div>
            </button>

            {/* Register as Business */}
            <button
              onClick={() => handleSelectRole("business")}
              className="w-full bg-gradient-to-br from-accent/10 to-accent/5 border-2 border-accent/40 active:border-accent rounded-2xl p-6 text-left active:scale-[0.98] transition-all duration-200"
            >
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 bg-gradient-to-br from-accent to-accent/90 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                  <Store className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl mb-2 text-gray-900">Register as Business</h3>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    List your restaurant and upload deals to reach customers
                  </p>
                </div>
              </div>
            </button>
          </div>

          {/* Footer */}
          <div className="px-6 pb-8 text-center">
            <p className="text-xs text-muted-foreground">
              You can change your role anytime in settings
            </p>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}