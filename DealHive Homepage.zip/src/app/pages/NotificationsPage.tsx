import { Bell, Check, Trash2, X, CheckCheck, Sparkles, TrendingUp, Award, Info } from "lucide-react";
import { ResponsiveHeader } from "../components/responsive-header";
import { BottomNav } from "../components/bottom-nav";
import { useNavigate } from "react-router";
import { useApp } from "../context/AppContext";

export function NotificationsPage() {
  const navigate = useNavigate();
  const { notifications, markAsRead, markAllAsRead, deleteNotification, unreadCount } = useApp();

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "deal":
        return <TrendingUp className="w-5 h-5 text-accent" />;
      case "price_drop":
        return <TrendingUp className="w-5 h-5 text-green-600" />;
      case "expiring":
        return <Bell className="w-5 h-5 text-orange-600" />;
      case "achievement":
        return <Award className="w-5 h-5 text-yellow-600" />;
      case "system":
        return <Sparkles className="w-5 h-5 text-primary" />;
      default:
        return <Info className="w-5 h-5 text-gray-600" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "deal":
        return "bg-accent/10";
      case "price_drop":
        return "bg-green-100";
      case "expiring":
        return "bg-orange-100";
      case "achievement":
        return "bg-yellow-100";
      case "system":
        return "bg-primary/10";
      default:
        return "bg-gray-100";
    }
  };

  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
  };

  const handleNotificationClick = (notification: typeof notifications[0]) => {
    if (!notification.read) {
      markAsRead(notification.id);
    }
    if (notification.dealId) {
      navigate(`/deal/${notification.dealId}`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 lg:pb-0">
      <ResponsiveHeader title="Notifications" showBack />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Header Actions */}
        {notifications.length > 0 && (
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
                Notifications
              </h1>
              <p className="text-sm sm:text-base text-muted-foreground">
                {unreadCount > 0 ? `${unreadCount} unread` : "All caught up!"}
              </p>
            </div>
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-primary hover:bg-primary/10 rounded-xl transition-colors"
              >
                <CheckCheck className="w-4 h-4" />
                <span className="hidden sm:inline">Mark all read</span>
              </button>
            )}
          </div>
        )}

        {/* Notifications List */}
        {notifications.length > 0 ? (
          <div className="space-y-2">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={`bg-white rounded-2xl shadow-sm border transition-all ${
                  notification.read
                    ? "border-gray-200"
                    : "border-primary/30 shadow-md"
                }`}
              >
                <div className="p-4 sm:p-5">
                  <div className="flex items-start gap-3 sm:gap-4">
                    {/* Icon */}
                    <div
                      className={`w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center flex-shrink-0 ${getNotificationColor(
                        notification.type
                      )}`}
                    >
                      {getNotificationIcon(notification.type)}
                    </div>

                    {/* Content */}
                    <div
                      className="flex-1 min-w-0 cursor-pointer"
                      onClick={() => handleNotificationClick(notification)}
                    >
                      <div className="flex items-start gap-2 mb-1">
                        <h3
                          className={`text-sm sm:text-base font-semibold flex-1 ${
                            notification.read
                              ? "text-foreground"
                              : "text-primary"
                          }`}
                        >
                          {notification.title}
                        </h3>
                        {!notification.read && (
                          <div className="w-2 h-2 bg-accent rounded-full flex-shrink-0 mt-2"></div>
                        )}
                      </div>
                      <p className="text-xs sm:text-sm text-muted-foreground mb-2 line-clamp-2">
                        {notification.message}
                      </p>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span>{formatTimestamp(notification.timestamp)}</span>
                        {notification.dealId && (
                          <>
                            <span>•</span>
                            <span className="text-primary font-medium">
                              View Deal
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-2">
                      {!notification.read && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            markAsRead(notification.id);
                          }}
                          className="p-2 hover:bg-green-50 text-green-600 rounded-lg transition-colors"
                          title="Mark as read"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteNotification(notification.id);
                        }}
                        className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-12 text-center">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Bell className="w-10 h-10 sm:w-12 sm:h-12 text-gray-400" />
            </div>
            <h2 className="text-xl sm:text-2xl font-semibold text-foreground mb-3">
              No Notifications Yet
            </h2>
            <p className="text-sm sm:text-base text-muted-foreground text-center max-w-md mx-auto mb-8">
              When you get notifications about deals, price drops, and updates,
              they'll appear here.
            </p>
            <button
              onClick={() => navigate("/")}
              className="px-6 sm:px-8 py-3 bg-accent text-white rounded-xl hover:bg-accent/90 active:bg-accent/80 transition-colors font-semibold"
            >
              Explore Deals
            </button>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
