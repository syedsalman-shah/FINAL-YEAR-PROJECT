import { useNavigate, useParams } from "react-router";
import { BusinessProfile } from "../components/business-profile";

export function BusinessProfilePage() {
  const navigate = useNavigate();
  const { id } = useParams();

  return <BusinessProfile onBack={() => navigate(-1)} />;
}